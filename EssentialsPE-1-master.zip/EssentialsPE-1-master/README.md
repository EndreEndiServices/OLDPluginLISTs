# EssentialsPE
An up to date EssentialsPE plugin, Update API's, coding, and more.
