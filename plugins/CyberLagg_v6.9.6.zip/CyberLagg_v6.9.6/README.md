[=]CyberLagg PocketMine Plugin[=]
    Created By Top Developer Indonesia
                _ZacSora_
alias : Kuruta,Nix1a_latte,
  We Are Teams : 
- My Github : https://github.com/KurutaEvolvy
- My Friend : https://github.com/NightmareCybers
  -=This Languange Plugin Is Indonesian=-

   Command :
  » /cyberlagg check
        • Check All Entities

  » /cyberlagg clear
       • Clear Lagg Entities

  » /cyberlagg killmobs
       • Clear Mobs Entities

  » /cyberlagg clearall
       • Clear All Entities


    Join My Official Server -
    IP : Cyber-Realms.zapto.org
   Port : 19132
By Owner : NightmareCybers And ZacSora
    