# AntiCheat License 2.1 (ACLv2.1)

You are free to:

Share and redistribute the material in any medium or format. The licensor cannot revoke these freedoms as long as you follow the license terms.

Under the following terms:

Attribution — You must give appropriate credit and provide a link to the license.

NonCommercial — You may not use the material for commercial purposes.

NoDerivatives — If you remix, transform, or build upon the material, you may not distribute the modified material.

No Modification — If you modyfy the material, you may not distribute the modified material.

No Copying — If you Copy from the material, you may not distribute the material which includes code that was copyed from this software.

No Copyright — DO NOT UNDER ANY CIRCUMSTANCES COPYRIGHT THIS PLUGIN / SOFTWARE! IF U ARE CAUGHT U WILL BE REPORTED!

No additional restrictions — You may not apply legal terms or technological measures that legally restrict others from doing anything the license permits.
