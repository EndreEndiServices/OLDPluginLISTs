# AntiCheat

## An AntiCheat plugin for PocketMine-MP and Forks.
## This Plugin is inactive - The issue tracker is unavilable

# 0.15.7 only. - [Visit SAC (ShadowAntiCheat) for 0.15/16.X support.](https://github.com/DarkWav/VAC)

## Find The Wiki and Phar Downloads [Here](https://github.com/DarkWav/AntiCheat/wiki).

# Features:<br>
## AntiReach<br>AntiFly<br>AntiSpeed<br>AntiJesus<br>AntiGlide<br>AntiNoKnockBack<br>AntiBadEnchants<br>AntiForceOP<br>AntiNoClip<br>AntiHighJump<br>AntiClimb (May not always work)<br>

### Read the [License](https://github.com/DarkWav/AntiCheat/blob/master/LICENSE.md) before downloading the source.
### With downloading the source or the Plugin, you AGREE to the [License](https://github.com/DarkWav/AntiCheat/blob/master/LICENSE.md)!
