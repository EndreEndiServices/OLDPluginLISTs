<?php

namespace MultiInventory;

use pocketmine\event\entity\EntityLevelChangeEvent;
use pocketmine\event\level\LevelLoadEvent;
use pocketmine\event\Listener;
use pocketmine\level\Level;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;

class Main extends PluginBase implements Listener{

    /** @var  \SQLite3 */
    public $inventories;

    public function onEnable(){
        @mkdir($this->getDataFolder());
        $this->inventories = new \SQLite3($this->getDataFolder()."inventories.db", SQLITE3_OPEN_CREATE | SQLITE3_OPEN_READWRITE);
        $level = strtolower($this->getServer()->getDefaultLevel()->getFolderName());
        $this->inventories->exec("CREATE TABLE IF NOT EXISTS `$level` (name TEXT PRIMARY KEY, slots BLOB, armor BLOB)");
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function onDisable(){
        $this->inventories->close();
    }

    public function onLevelChange(EntityLevelChangeEvent $event){
        $ent = $event->getEntity();
        if($ent instanceof Player and $ent->hasPermission("multiinventory.switch")){
            $this->saveInv($ent, $event->getOrigin());
            $ent->getInventory()->clearAll();
            $this->loadInv($ent, $event->getTarget());
        }
    }

    public function saveInv(Player $player, Level $from){
        $from = strtolower($from->getFolderName());
        $name = strtolower($player->getName());
        $contents = base64_encode(serialize($player->getInventory()->getContents()));
        $armor = base64_encode(serialize($player->getInventory()->getArmorContents()));

        $this->inventories->exec("CREATE TABLE IF NOT EXISTS `$from` (name TEXT PRIMARY KEY, slots BLOB, armor BLOB)");

        $stmt = $this->inventories->prepare("UPDATE `$from` SET slots = :slots, armor = :armor WHERE name = :name");
        $stmt->bindValue(":slots", $contents, SQLITE3_TEXT);
        $stmt->bindValue(":armor", $armor, SQLITE3_BLOB);
        $stmt->bindValue(":name", $name, SQLITE3_BLOB);
        $stmt->execute();
        $stmt->close();

        $stmt = $this->inventories->prepare("INSERT OR IGNORE INTO `$from` (name, slots, armor) VALUES (:name, :slots, :armor)");
        $stmt->bindValue(":name", $name, SQLITE3_TEXT);
        $stmt->bindValue(":slots", $contents, SQLITE3_BLOB);
        $stmt->bindValue(":armor", $armor, SQLITE3_BLOB);
        $stmt->execute();
        $stmt->close();
    }

    public function loadInv(Player $player, Level $to){
        $to = strtolower($to->getFolderName());

        $this->inventories->exec("CREATE TABLE IF NOT EXISTS `$to` (name TEXT PRIMARY KEY, slots BLOB, armor BLOB)");

        $stmt = $this->inventories->prepare("SELECT * FROM `$to` WHERE name = :name");
        $stmt->bindValue(":name", strtolower($player->getName()), SQLITE3_TEXT);
        $query = $stmt->execute();
        if($query instanceof \SQLite3Result){
            $data = $query->fetchArray(SQLITE3_ASSOC);
            if(isset($data["slots"]) and isset($data["armor"])){
                $player->getInventory()->setContents(unserialize(base64_decode($data["slots"])));
                $player->getInventory()->setArmorContents(unserialize(base64_decode($data["armor"])));
            }
        }
        $query->finalize();
        $stmt->close();
    }

}