# MultiInventory
PocketMine plugin for multiworld inventory
