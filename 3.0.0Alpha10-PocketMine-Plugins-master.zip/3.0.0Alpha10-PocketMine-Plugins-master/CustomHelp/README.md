# CustomHelp

With this Custom Help Plugin you can edit the /help command simple :D

You can edit the Messages on the Config!



Kontaktdaten:

Twitter: https://twitter.com/McpeBooster

YouTube: https://youtube.com/McpeBooster

GitHub: https://github.com/McpeBooster

E-Mail: mcpebooster@gmail.com
