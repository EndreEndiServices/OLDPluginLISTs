# FormAuth
An advanced authentication plugin in form for PocketMine-MP

### [Latest builds](https://poggit.pmmp.io/ci/MinecartSquad/FormAuth/FormAuth)
### Required [FormAPI](https://github.com/jojoe77777/FormAPI)

![register](https://preview.ibb.co/dbcjLw/bandicam_2017_11_02_20_56_14_739.jpg)
![login](https://preview.ibb.co/hphvSb/bandicam_2017_11_02_20_56_56_060.jpg)
