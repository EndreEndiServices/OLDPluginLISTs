russian version:

https://vk.com/plugplus?w=wall-121838923_12619



Require Plugin:
- EconomyAPI | https://poggit.pmmp.io/p/EconomyAPI/5.7.1-3

- FormAPI | https://m.vk.com/doc150478583_452707738?hash=e8055f17695b965180&dl=218fa015d05dcd38ca


This Plugin was russian i change it with english.

Commands:
/mask
/maskshop

it same lol

I recommand you to

use source code :p

you cant edit heads aka masks
