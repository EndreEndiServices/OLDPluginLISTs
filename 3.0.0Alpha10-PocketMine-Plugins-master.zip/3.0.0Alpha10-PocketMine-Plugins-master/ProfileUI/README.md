# ProfileUI 
(No Plugin library or Virion required! Easy as pie!)
Get any player's profile on a Modal Form! MCPE v1.2! PMMP support only!

[![Poggit-CI](https://poggit.pmmp.io/ci.shield/Infernus101/ProfileUI/ProfileUI)](https://poggit.pmmp.io/ci/Infernus101/ProfileUI/ProfileUI)
[![](https://poggit.pmmp.io/shield.dl.total/ProfileUI)](https://poggit.pmmp.io/p/ProfileUI)

[Get the latest ProfileUI artifacts (PHAR file) here](https://poggit.pmmp.io/ci/Infernus101/ProfileUI/ProfileUI)

## Ideas
- Submit your ideas in issues or pr it!

## Usage
- /profile <player>

## Features
- Shows player Name
- Shows player Rank
- Shows player Money
- Shows player blocks broken
- Shows player total kills
- Shows player total deaths
- Shows player K/D ratio
- Shows player Faction if there
- Shows player online/offline status
- Shows player first joined date with time
- Shows player Last seen if player is offline

## About
- Made by @Infernus101
- Github - http://github.com/Infernus101
- Twitter - http://twitter.com/Infernus101
- Email - infernusmcpe@gmail.com
- Server - Fallentech.tk 19132 | Countertech.tk 19132
