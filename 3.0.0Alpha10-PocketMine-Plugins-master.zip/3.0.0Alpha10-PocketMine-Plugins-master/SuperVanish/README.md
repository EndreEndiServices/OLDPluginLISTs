# Vanish
/vanish (perm: vanish.use) default: op
