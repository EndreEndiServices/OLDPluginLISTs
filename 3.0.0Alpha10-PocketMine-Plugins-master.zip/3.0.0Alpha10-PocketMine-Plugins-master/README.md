# 3.0.0Alpha9-PocketMine-Plugins
For all plugins compatible with API 3.0.0-Alpha9 for PocketMine-MP.


BoostPad 3.0.0-Alpha9 - BoxOfDevs
https://github.com/BoxOfDevs/BoostPad
>>JumpPad plugin which allows users to create jumpPads out of redstone blocks.


2vs2 3.0.0-Alpha9

>>1vs1 plugin edited for use on PocketMine-MP with API 3.0.0Alpha9.


CrateKeys 3.0.0-Alpha9

>>Simple crates and crate keys plugin for PocketMine-MP. Tap chest with slime ball to open.


SuperVanish 3.0.0-Alpha9

>>Simple vanish plugin for PocketMine-MP. Use command /supervanish to disappear.


Multi-Inv 3.0.0-Alpha9

>>Simple inventory plugin for PocketMine-MP. Allows for players to have seperate inventory's in each world.


PerWorldChat 3.0.0-Alpha9

>>Simple chat plugin for PocketMine-MP. Sets diffrent chat channels in each world.


TimeCommander 3.0.0-Alpha9

>>Timed command plugin for PocketMine-MP. Set commands and intervals in config.yml.


PeacefulSpawn 3.0.0-Alpha9

>>Disable pvp in spawn protected area.


Plugins intended for use on PocketMine-MP servers only.
