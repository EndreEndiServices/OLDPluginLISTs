# Enderchest
EnderChest implemention in PocketMine-MP (PMMP)!

# How to install
Drop the phar file from poggit to your server's plugins folder, reload  or restart and you're done!

## Where EnderChest data is saved
The chest / Inventory data is saved at players/chestdata, it's in serialized format so you can check players items (if you're a dev :p) but do not edit those, else data maybe currupt and items will ne lost

# ToDo
- [ ] Add MySQL and SQL support
- [ ] Fix EnderChest open and close animation
- [ ] Fix bugs if found so

# Support
Twitter: @TheAz928
Feel free to open an issue on github if your issue is too large or can't explain on twitter
