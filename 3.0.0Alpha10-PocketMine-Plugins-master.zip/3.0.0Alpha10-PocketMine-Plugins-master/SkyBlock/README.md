# SkyBlock
SkyBlock for PocketMine-MP servers.
### Contributions
You are free to contribute to this project, any kind of help is accepted.
### Where can I download it?
You can download it [here](https://poggit.pmmp.io/ci/giantquartz-plugin-collection/SkyBlock).
### Can we use this plugin for production servers?
You can use it as you want, but this plugin **is definitely a bad idea** if you want do a public server. This plugin has been think to work for 3 or 4 players, and it may fail if you create a lot of islands.
