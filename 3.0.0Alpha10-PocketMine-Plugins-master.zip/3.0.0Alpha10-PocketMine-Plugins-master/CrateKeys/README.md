# CrateKeys
Bring treasure keys on your Minecraft:PE server.

Mine, Find a key, Unlock treasure chest and collect treasures :)

# Installation

 1. Download .phar file from "Releases" or compile locally from source
 2. Put .phar file into ~/plugins folder
 3. Restart server
 4. Use slim ball to unlock a chest
 
# Disclaimer

This plugin was made a long time ago. Requested by ConflictPE server and may contain bugs. This plugin wasn't fully tested!
