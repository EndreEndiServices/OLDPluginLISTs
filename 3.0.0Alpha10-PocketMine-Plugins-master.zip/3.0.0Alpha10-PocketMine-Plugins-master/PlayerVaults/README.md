# PlayerVaults
Per-player inventory-based vaults plugin for PocketMine-MP

You may download the **phar file** [here](https://github.com/Muqsit/PlayerVaults/releases/tag/v2.0).

If you want to view the wiki, you can visit this pmmp forums page [here](https://forums.pmmp.io/threads/playervaults-privatevaults.2023/).
