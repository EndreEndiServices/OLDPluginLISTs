<H1>Pocketmine SoupFFA Plugin by @McpeBooster</H1>

<br>

<H1>Explanations</H1>

SoupFFA is an endless game mode, which is about to kill your opponents. Every player has his inventory full of soup, which will heal you when you eat it.

<br>

<H1>News:</H1>

Addet AutoUpdater

Addet wiki: https://github.com/McpeBooster/SoupFFA-McpeBooster/wiki

Updatet to Mcpe version 1.2

This Plugin has now a MultiLang System with English, German Arabic, France, Türkce, Spain and Chinese , more comming soon.

<br>

Change the language easily in the config.yml

<br>

<H1>Phar:</H1>

get the latest .phar: http://McpeBooster.tk/plugins

<br>

<H1>How to install:</H1>

<br>

| Step | Description |
| --- | --- |
| 1 | First change the world in the config.yml |
| 2 | Second create a Sign with "SoupFFA" on the FirstLine |
| 3 | Click on the Sign and play with you friends :D |

<br>

<H1>Commands:</H1>

| Command | Description | Permission |
| --- | --- | --- |
| /soupffa join | join SoupFFA | none |
| /soupffa quit | leave SoupFFA | none |

<br>

<H1>How to get the Vip Kit:</H1>

When a player has the Permission "soupffa.vip", the player gets a Vip Kit!

<br>

<br>

<H1>YouTube Video:</H1>

[![Alt text](https://img.youtube.com/vi/iQ-GgxrWYQk/0.jpg)](https://www.youtube.com/watch?v=iQ-GgxrWYQk)

https://youtu.be/iQ-GgxrWYQk

<br>

<br>

<H1>Contact details:</H1>

Twitter: https://twitter.com/McpeBooster

YouTube: https://youtube.com/McpeBooster

GitHub: https://github.com/McpeBooster

E-Mail: mcpebooster@gmail.com
