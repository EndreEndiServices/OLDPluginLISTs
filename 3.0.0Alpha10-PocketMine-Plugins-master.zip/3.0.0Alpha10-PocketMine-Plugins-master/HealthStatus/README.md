Beta - Testing, Displays a players health above their head.

Download HealthStatus_Beta.phar here: https://www.dropbox.com/s/z89c0u6wzu2j2wi/HealthStatus_vBeta.phar?dl=0
