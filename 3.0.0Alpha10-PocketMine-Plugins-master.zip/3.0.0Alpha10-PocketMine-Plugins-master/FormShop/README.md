# FormShop
### Русский

Плагин для PocketMine, который добавляет на ваш сервер магазины в формах.

Создатель: [Telegram](https://t.me/egr7v8) | [VK](https://vk.com/egr7v8)

Сообщество VK: https://vk.com/plugplus

Для работы требуется [EconomyAPI](https://github.com/onebone/EconomyS) и [FormAPI](https://github.com/jojoe77777/FormAPI)

#### Команды

`/shop` открыть магазин

#### Список задач:

+ Добавить поддержку английского языка.
