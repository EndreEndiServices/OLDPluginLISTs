CombatLogger
===================
__PocketMine Plugin__

### About

CombatLogger allows you to punish and control players that try to combat log! You can prevent players from executing,
specific commands in pvp or even kill them when they attempt to log while in pvp. You can easily setup your server with
CombatLogger by installing a phar and simply editing the config! You can edit messages, set the combat timeout time and
ban certain commands from players whilst in pvp.

__The content of this repo is licensed under the GNU Lesser General Public License v2.1. A full copy of the license is
available [here](LICENSE).__
