### JoinSystem

Pocketmine JoinSystem Plugin by @McpeBooster



Tell me what features do you want :D

<br>

### Features:

Custom Join/Quit Messages

/hub Command with Title :D

<br>

<br>

### Kontaktdaten:

Twitter: https://twitter.com/McpeBooster

YouTube: https://youtube.com/McpeBooster

GitHub: https://github.com/McpeBooster

E-Mail: mcpebooster@gmail.com
