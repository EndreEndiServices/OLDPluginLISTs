<?php
/**
 * Created by PhpStorm.
 * User: noahheyl
 * Date: 2017-04-15
 * Time: 8:44 AM
 */

namespace falkirks\minereset\store;


interface Saveable{
    public function save();
}