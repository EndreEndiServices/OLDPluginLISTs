<?php
namespace falkirks\minereset\store;


interface Reloadable{
    public function reload();
}