### 1vs1 plugin by Minifixio

### Description:
You want to make 1vs1s on your MCPE server ? This plugin is for you !

Cool things:
-> Multi arenas system
-> Auto queue management
-> Statistics signs


### How to use:
-> First, you'll need to reference your(s) arena(s) doing /refarena on the middle of your arena. The players will spawn 5 blocks from the middle of the arena (see example below). You can make an unlimited numbers of arenas. All the arenas’s positions are saved in the config.yml file.

-> Then, the players can start a duel doing /match, a countdown before the fight will start (only 2 players per arena) and they will be teleported in an arena and they will get a sword, armor and food and all their effects will be removed for fight. The fight last 3 minutes and at the end of the timer if there is no winners, the duel ends and the players are teleported back to the spawn.

-> You can place a sign and write on the 1st line : « [1vs1] » to have a 1vs1 stats sign with the numbers of active arenas and the number of the players in the queue. The signs refreshes every 5 seconds.

### Technical:
-> After a fight, the players are teleported back to the spawn of the default level server.

-> When a player quit in a fight, his opponent win.

-> The arenas and the 1vs1’s signs positions are stored in the config.yml file.

-> When a player quit during the start match countdown, the match stops.


### Commands:
-> /match : join the 1vs1 queue
-> /refarena : reference a new arena.


### Notes:
-> Maybe you will find some mistakes in my plugin documentation, it’s just because i’m not english (french :c).

-> You can only change the messages in the plugin source but soon you will can change it in a message config file.

-> You will able to change the spawn distance in a arena and the timers for the matches in an update soon.

-> Any remarks ? Tell me it for a better world x) !
