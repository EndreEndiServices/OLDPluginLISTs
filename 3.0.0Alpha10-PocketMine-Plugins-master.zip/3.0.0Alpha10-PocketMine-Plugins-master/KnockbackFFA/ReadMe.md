<H1>Pocketmine KnockbackFFA Plugin by @McpeBooster</H1>

<br>

<H1>Explanations</H1>

KnockbackFFA, also known as KnockIT, is a mini-game, which is about knocking other players into nothingness. And so a possible High Killstreak to reach.

<H1>News:</H1>

Addet AutoUpdater

<br>

Addet wiki: https://github.com/McpeBooster/KnockbackFFA-McpeBooster/wiki

<br>

The plugin is now complete and has been released

<br>

Change the language easily in the config.yml

<br>

<H1>Phar:</H1>

get the latest .phar: http://McpeBooster.tk/plugins

<br>

<H1>How to install:</H1>

<br>

| Step | Description |
| --- | --- |
| 1 | First change the world in the config.yml |
| 2 | Second create a Sign with "KnockbackFFA" on the FirstLine and your Arena on the second! |
| 3 | Click on the Sign and play with you friends :D |

<br>

<br>

<H1>Features:</H1>

- KillStreak

- MultiArena

- MultiLang (English, German, French, Russian)

- JoinSign

- Custom Messages

- Enchantment

- Spawn Protection

<br>

<br>

<H1>Contact details:</H1>

Twitter: https://twitter.com/McpeBooster

YouTube: https://youtube.com/McpeBooster

GitHub: https://github.com/McpeBooster

E-Mail: mcpebooster@gmail.com
