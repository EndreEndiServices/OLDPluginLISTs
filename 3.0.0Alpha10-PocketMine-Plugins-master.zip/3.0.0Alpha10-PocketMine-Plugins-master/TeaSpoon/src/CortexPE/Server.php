<?php

namespace CortexPE;

use pocketmine\Server as PMServer;

class Server extends PMServer {
	/** @var bool */
	public static $loaded = false;
}