# TeaSpoon
A (will be) Massive PocketMine-MP plugin designed and is aiming to extend PMMP's functionalities (Without completely changing it) to Make it more Vanilla-Like.

Contributions are very welcome :smile:<br />You may contribute by opening a Pull Request and if it has been proven to be correct & working, I'll surely merge it.

# Finished & Planned Features
 - [X] End Dimension
 - [X] Nether Dimension
 - [X] EnderChests
 - [X] All vanilla enchants are Registered (not functional yet)
 - [X] EnderPearls & More realistic Projectiles
 - [ ] Implement all vanilla Entities
 - [ ] Weather system
 - [ ] Implement all vanilla Items
 - [ ] Implement all vanilla Blocks
 <br />***More to do...***
