# SkyWars
Simple pocketmine SkyWars plugin for API 3.0.0-ALPHA11
Blabla
