# ProxyChecker
a pocketmine plugin made in PHP to not let players with proxies to join your server.
**CREDITS:** This plugin uses a public api made by [@OGFris](https://twitter.com/OGFris), contact him on twitter to purchase a premium license key.
