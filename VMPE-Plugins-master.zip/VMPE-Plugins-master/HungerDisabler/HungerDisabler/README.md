# HungerDisabler
Disable hunger in a PocketMine server!

Download: https://poggit.pmmp.io/r/6363/HungerDisabler.phar
