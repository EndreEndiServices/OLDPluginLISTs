# CombatLogger
Stop players from logging out during a fight
This is a updated version of combat logger by Lambo. Some bugs which may ocured in it, should be fixed, but not confirm to be.
This plugin is mainly for VM, which is Voidminer server. I will post a download link soon.
Thanks.

UPDATED: We are the Inativeness developing team. What we do, is we make plugins come back to alive, porting to a different developer. When they are active again, we shall give the project back to them. This is so we can make Mini-Games and plugins great again. If you have any questions, feel free to open an issue. We have bumped the API to 3.0.0-ALPHA6. So issues you may well of experienced should be fixed. Let me know if anymore bugs do occur. Remember, we're only trying to get the plugins which are basically dead come back to life.
