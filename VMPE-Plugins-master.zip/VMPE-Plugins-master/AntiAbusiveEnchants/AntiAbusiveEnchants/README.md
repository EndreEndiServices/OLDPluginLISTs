# AntiAbusiveEnchants
Say bye to those enchants abusers.
