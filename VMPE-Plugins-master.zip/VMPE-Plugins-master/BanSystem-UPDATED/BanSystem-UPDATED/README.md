# BanSystem-UPDATED
Plugin which was updated by the VMPE Development Team.
