# VMPE-Plugins
The plugins I've worked on and being updated as of now. You can however, download our plugins, but don't give yourself credit. Give the user who updated the plugins credit.
