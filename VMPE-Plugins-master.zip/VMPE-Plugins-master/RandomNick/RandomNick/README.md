# RandomNick plugin

## How to use?
/nick on (Nick yourself with a Random Nick!)

/nick off (Deactivate your nick)
