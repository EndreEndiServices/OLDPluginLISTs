# am_PlayerSize

Comands:

/size <0.5-5>

/size reset

/size help
