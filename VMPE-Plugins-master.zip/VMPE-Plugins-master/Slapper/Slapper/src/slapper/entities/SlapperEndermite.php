<?php
namespace slapper\entities;

class SlapperEndermite extends SlapperEntity {

	const TYPE_ID = 55;
	const HEIGHT = 0.3;

}
