<?php
namespace slapper\entities;

class SlapperVillager extends SlapperEntity {

	const TYPE_ID = 15;
	const HEIGHT = 1.95;

}
