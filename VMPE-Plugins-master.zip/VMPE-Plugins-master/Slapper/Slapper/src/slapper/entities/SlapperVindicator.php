<?php
namespace slapper\entities;

class SlapperVindicator extends SlapperEntity {

	const TYPE_ID = 57;
	const HEIGHT = 1.95;

}
