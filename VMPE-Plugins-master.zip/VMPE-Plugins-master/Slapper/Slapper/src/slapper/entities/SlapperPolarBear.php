<?php
namespace slapper\entities;

class SlapperPolarBear extends SlapperEntity {

	const TYPE_ID = 28;
	const HEIGHT = 1.4;

}
