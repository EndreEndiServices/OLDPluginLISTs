<?php
namespace slapper\entities;

class SlapperSpider extends SlapperEntity {

	const TYPE_ID = 35;
	const HEIGHT = 0.9;

}
