<?php
namespace slapper\entities;

class SlapperVex extends SlapperEntity {

	const TYPE_ID = 105;
	const HEIGHT = 0.8;

}
