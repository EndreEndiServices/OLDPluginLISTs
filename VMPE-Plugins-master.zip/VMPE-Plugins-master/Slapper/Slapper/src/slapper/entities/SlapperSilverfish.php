<?php
namespace slapper\entities;

class SlapperSilverfish extends SlapperEntity {

	const TYPE_ID = 39;
	const HEIGHT = 0.3;

}
