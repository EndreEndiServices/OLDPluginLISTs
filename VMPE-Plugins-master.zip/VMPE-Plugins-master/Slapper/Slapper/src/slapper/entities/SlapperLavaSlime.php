<?php
namespace slapper\entities;

class SlapperLavaSlime extends SlapperEntity {

	const TYPE_ID = 42;
	const HEIGHT = 0.51;

}
