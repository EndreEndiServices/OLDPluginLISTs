<?php
namespace slapper\entities;

class SlapperMule extends SlapperEntity {

	const TYPE_ID = 25;
	const HEIGHT = 1.6;

}
