<?php
namespace slapper\entities;

class SlapperWitherSkeleton extends SlapperEntity {

	const TYPE_ID = 48;
	const HEIGHT = 2;

}
