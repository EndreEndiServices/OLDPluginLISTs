<?php
namespace slapper\entities;

class SlapperBat extends SlapperEntity {

	const TYPE_ID = 19;
	const HEIGHT = 0.9;

}
