# Slapper
The new home of Slapper, the NPC plugin for PocketMine-MP.

## NOTE
This plugin is designed for **[PocketMine-MP](https://github.com/pmmp/PocketMine-MP)** only and we do not support any other variations, forks or spoons.
Compatibility with unofficial variants can occasionally be found, but **do not expect support if you are using anything other than PocketMine-MP**.

## Addons

Official addons:
- [SlapBack](https://github.com/jojoe77777/SlapBack)
- [SlapperRotation](https://github.com/jojoe77777/SlapperRotation)
- [SlapperCache](https://github.com/jojoe77777/SlapperCache)
