# AdminFunPE-2.0
A originally plugin for Pocketmine, but is no longer updating. This plugin is updated to the latest PMMP builds, so you can start trolling for your needs.
