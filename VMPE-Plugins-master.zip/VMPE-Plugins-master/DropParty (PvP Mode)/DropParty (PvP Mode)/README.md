# DropParty
Schedule DropParties on your server with this PocketMine Plugin!
Simply setup the config.yml and enjoy automatic DropParties on your server!
