# WorldGuard  [![Poggit-CI](https://poggit.pmmp.io/ci.badge/Muqsit/WorldGuard/WorldGuard)](https://poggit.pmmp.io/ci/Muqsit/WorldGuard/WorldGuard)
A World Management plugin for PocketMine-MP and forks.
Read the [tutorial](https://github.com/Muqsit/WorldGuard/wiki/Tutorial).

Download a compiled .phar file [here](https://github.com/Muqsit/WorldGuard/releases/tag/v1.0).
