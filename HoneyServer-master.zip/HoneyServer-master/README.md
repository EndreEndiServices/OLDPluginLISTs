# HoneyServer
__Open source [HoneyServer](https://honey-mc.net)'s plugin for PocketMine-MP.__

### Stats

| Info |  |
|:---|:---:|
| MCBE Version | 1.2.10 |
| Version | 1.0.0 |
| CodeName | Glass Rabbit |
| Supported API Version | - 1.13.0 <br> - 2.0.0 <br> - 3.0.0 <br> - 3.0.0-ALPHA9 |
| Supported Server Software | [DragMine](https://github.com/DragMineTeam/DragMine) |

### My Server

| ServerIP |  |
|:---|:---:|
| Address | __honey-mc.net__ |
| Port | __19132__ |

### Links
 * [Web](https://honey-mc.net) - The server's web page.
 * [Wiki](http://seesaawiki.jp/honey-mc/) - You can get a lot of information!
 * [Lobi](https://lobi.co/invite/ic385) - Community of the server.
 * [Discord](https://discord.gg/Qe8tE9N) - Chat on discord.