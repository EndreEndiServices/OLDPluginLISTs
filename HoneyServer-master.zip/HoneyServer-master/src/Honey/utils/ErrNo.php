<?php

namespace Honey\utils;

class ErrNo{

	const ERRNO_001 = "001";
	const ERRNO_002 = "002";
	const ERRNO_003 = "003";
	const ERRNO_004 = "004";
}