<?php

namespace Honey;

class FormIds{

	const FORM_REGISTER = 0;
	const MENU_USER_SETTINGS = 1;
	const FORM_ADMIN_SETTINGS = 2;
}