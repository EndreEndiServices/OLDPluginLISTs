# * *This plugin is now compatible with 3.0 API's, and will not work on older versions of PocketMine.
# ZapFactions Pro ~~~ by EpicDF & Derpific, edited by Zeao.

### This is a custom build of FactionsPro, based on the version by @Tethered_.

### Update 1.9.x /// (Tested, and all is well. Release added @ https://poggit.pmmp.io/ci/TheFixerDevelopment/ZapFactionsPro/FactionsPro
#### Update 1.8.1.0 /// (Formed and tested .phar, successfully tested. Release added.).
#### Update 1.8.1 /// PureChat 1.3.3 100% compatible, use {faction} before group names. Working on official .phar.
#### Update 1.8.0 /// Enabled w/ PC1.4 code after heavy editing; testing alt. PureChat versions. Faction STR fix.
#### Update 1.7.8 /// Usage with Pure Chat 1.4 confirmed, **MUST** use extra editing in PC1.4 code to correct.
#### Update 1.7.6 /// Faction War implemented, testing; Confirmed compatibility with PurePerms 1.3.7.

The .phar plugin works! How-To Install:

1. Download most recent .phar build from https://poggit.pmmp.io/ci/TheFixerDevelopment/ZapFactionsPro/FactionsPro

2. Upload .phar plugin into the Plugins folder in your server files.

3. Restart your server.

4. If it says anywhere in the console "Loading plugin FactionsPro v1.9.0" then it worked! Enjoy :)

(5. **If** it didn't show up in console during server loading, check for errors at the top of console history. If there is an error, please report to me here. If there is **no** error, you likely did not fully install the plugin or did not put it in the correct folder.)
**Hint: Your plugins folder will be here 95% of the time: PocketMine\Server\Plugins**

