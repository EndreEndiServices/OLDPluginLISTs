<?php

namespace dialect;

use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\CommandExecutor;
use pocketmine\utils\Config;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerJoinEvent;
class Main extends PluginBase implements Listener{

	function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		if(!file_exists($this->getDataFolder())){
        mkdir($this->getDataFolder(), 0744, true);
    }
    $this->config = new Config($this->getDataFolder() . "config.yml", Config::YAML,
    array(
          "方言（デフォルト）" => "標準語",
          "標準語" => "対応済",
          "関西弁" => "対応済",
    ));
    $this->pl = new Config($this->getDataFolder() . "player.yml", Config::YAML,
    array(
          "名前" => "方言",
    ));
  }
  function onJoin(PlayerJoinEvent $e){
    $p = $e->getPlayer();
    $n = $p->getName();
    if(!$this->pl->exists($n)){
    $de = $this->config->get("方言（デフォルト）");
    $this->pl->set($n, $de);
    $this->pl->save();
  }
  }
  function getDialect($name){
  	$di = $this->pl->get($name);
  	return $di;
  }
  function onChat(PlayerChatEvent $e){
  	$m = $e->getMessage();
    $p = $e->getPlayer();
    $di = $this->pl->get($p->getName());
  	$d = $p->getDisplayName();
  	if($di == "関西弁"){
  		if(strpos($m, "ダメ") !== false){
  		$s = str_replace("ダメ", "あかん", $m);
  		$e->setCancelled();
  		$this->getServer()->broadcastMessage("<".$d."> ".$s);
  }
  if(strpos($m, "バカ") !== false){
  		$s = str_replace("バカ", "あほ", $m);
  		$e->setCancelled();
  		$this->getServer()->broadcastMessage("<".$d."> ".$s);
  }
  if(strpos($m, "いい") !== false){
  		$s = str_replace("いい", "ええ", $m);
  		$e->setCancelled();
  		$this->getServer()->broadcastMessage("<".$d."> ".$s);
  }
  if(strpos($m, "おかしな") !== false){
  		$s = str_replace("おかしな", "けったいな", $m);
  		$e->setCancelled();
  		$this->getServer()->broadcastMessage("<".$d."> ".$s);
  }
  if(strpos($m, "めんどうくさい") !== false){
  		$s = str_replace("めんどうくさい", "邪魔くさい", $m);
  		$e->setCancelled();
  		$this->getServer()->broadcastMessage("<".$d."> ".$s);
  }
  if(strpos($m, "ちがう") !== false){
  		$s = str_replace("ちがう", "ちゃう", $m);
  		$e->setCancelled();
  		$this->getServer()->broadcastMessage("<".$d."> ".$s);
  }
  if(strpos($m, "何回") !== false){
  		$s = str_replace("何回", "なんべん", $m);
  		$e->setCancelled();
  		$this->getServer()->broadcastMessage("<".$d."> ".$s);
  }
  if(strpos($m, "本当") !== false){
  		$s = str_replace("本当", "ほんま", $m);
  		$e->setCancelled();
  		$this->getServer()->broadcastMessage("<".$d."> ".$s);
  }
  }
}
  function onCommand(CommandSender $sender, Command $command, $label, array $args){
    if(strtolower($command->getName()) == "word"){
      if(!isset($args[0])){
        $sender->sendMessage("§e方言が選択されていません");
      }
      if(!$this->config->exists($args[0])){
        $sender->sendMessage("§eその方言には対応していません");
      }else{
        $this->pl->set($sender->getName(), $args[0]);
        $this->pl->save();
        $sender->sendMessage("§e方言を変更しました");
      }
    }
    if(strtolower($command->getName()) == "wordlist"){
        $sender->sendMessage("§e[方言一覧]\n標準語　:　チャットにそのまま発言できます\n関西弁　:　関西弁に変換されます（一部");
    }
  }
}
