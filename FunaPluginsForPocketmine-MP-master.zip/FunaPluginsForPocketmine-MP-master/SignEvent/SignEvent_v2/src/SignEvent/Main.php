<?php

namespace SignEvent;

use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\utils\Config;
use pocketmine\level\Level;
use pocketmine\block\Block;
use pocketmine\math\Vector3;
use pocketmine\level\Position;
use pocketmine\event\block\SignChangeEvent;
use pocketmine\tile\Sign;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\item\Item;
use pocketmine\network\protocol\TransferPacket;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\scheduler\PluginTask;
use pocketmine\scheduler\CallbackTask;
use pocketmine\scheduler\Task;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\tile;
use pocketmine\nbt\NBT;

class Main extends PluginBase implements Listener{

	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getLogger()->info("§bプラグインが読み込まれました。");
		$this->getLogger()->info("§c二次配布は禁止です。 §b製作者R_Funa");

			if (!file_exists($this->getDataFolder())) @mkdir($this->getDataFolder(), 0744, true);
		$this->config = new Config($this->getDataFolder()."transfer.yml", Config::YAML);
    $this->give = new Config($this->getDataFolder()."give.yml", Config::YAML);
    $this->sign = new Config($this->getDataFolder()."others.yml", Config::YAML);
    $this->set = array();
  $this->i = array();
		}
		public function SignChange(SignChangeEvent $e){
        $line = $e->getLine(0);
        $line1 = $e->getLine(1);
        $line2 = $e->getLine(2);
        $line3 = $e->getLine(3);
        $p = $e->getPlayer();
        switch($line){
      case "[TRANSFER]":
      case "[transfer]":
      if(!ctype_alnum($line2)){
        $p->sendMessage("§b*You have to type alphanumeric characters.*");
        break;
      }
          $e->setLine(0, "§b[TRANSFER]");
          $e->setLine(1, "§e".$line1.""); 
        $e->setLine(2, "§e".$line2."");
        $block = $e->getBlock();
        $xyz = (Int)$e->getBlock()->getX().":".(Int)$e->getBlock()->getY().":".(Int)$e->getBlock()->getZ().":".$block->getLevel()->getFolderName();
        $ip = explode(".", $line1);
        $this->config->set($xyz,[
        "x" => $block->getX(),
        "y" => $block->getY(),
        "z" => $block->getZ(),
        "World" => $block->getLevel()->getFolderName(),
        "IP" => $ip[0].".".$ip[1].".".$ip[2].".".$ip[3],
        "PORT" => (int) $line2,
      ]);
        $this->config->save();
        break;
      case "[MYSTATUS]":
      case "[mystatus]":
      	$e->setLine(0, "§b[MYSTATUS]");
          $e->setLine(2, "§d".$p->getAddress().""); 
        $e->setLine(1, "§e".$p->getName()."");
        $e->setLine(3, "§e".$p->getClientId()."");
        break;
      case "[GIVEID]":
      case "[giveid]":
      if(!ctype_digit($line1)){
        $p->sendMessage("§b*You have to type numeric characters.*");
        break;
      }
       $e->setLine(0, "§b[GIVEID]");
       $e->setLine(1, "§eID : ".$line1.":".$line2."");
       $e->setLine(2, "§eHOW : ".$line3."");
       $e->setLine(3, "");
       $block = $e->getBlock();
       $xyz = (Int)$e->getBlock()->getX().":".(Int)$e->getBlock()->getY().":".(Int)$e->getBlock()->getZ().":".$block->getLevel()->getFolderName();
       $this->give->set($xyz,[
        "x" => $block->getX(),
        "y" => $block->getY(),
        "z" => $block->getZ(),
        "World" => $block->getLevel()->getFolderName(),
        "ID" => (int) $line1,
        "DAMAGE" => (int) $line2,
        "HOW" => (int) $line3,
      ]);
        $this->give->save();
       break;
       case "[XYZ]":
       case "[xyz]":
       $block = $e->getBlock();
       $e->setLine(0, "§b[XYZ]");
       $e->setLine(1, "§eX : ".(Int)$e->getBlock()->getX()."");
       $e->setLine(2, "§eY : ".(Int)$e->getBlock()->getY()."");
       $e->setLine(3, "§eZ : ".(Int)$e->getBlock()->getZ()."");
       break;
       case "[SC]":
       case "[sc]":
       $block = $e->getBlock();
       $this->bx = $block->getX();
       $this->by = $block->getY();
       $this->bz = $block->getZ();
       $this->ln = $block->getLevel();
       $this->getServer()->getScheduler()->scheduleDelayedTask(new CallbackTask([$this, 'del'], []), 20 * 30);
       break;
       case "[WINFO]":
       case "[winfo]":
        $level = $p->getLevel();
        $ln = $level->getFolderName();
        $chunk = count($level->getChunks());
        $en = count($level->getEntities());
        $tile = count($level->getTiles());
        $e->setLine(0, "§b[".$ln."]");
       $e->setLine(1, "§eCHUNK : ".$chunk."");
       $e->setLine(2, "§eENTITIES : ".$en."");
       $e->setLine(3, "§eTILES : ".$tile."");
       break;
       case "[COUNT]":
       case "[count]":
       if(ctype_digit($line1)){
        $block = $e->getBlock();
        $this->c = (Int)$line1;
        $this->x = $block->getX();
        $this->y = $block->getY();
        $this->z = $block->getZ();
        $this->level = $block->getLevel();
        $this->getServer()->getScheduler()->scheduleRepeatingTask(new CallbackTask([$this, "cou"]), 20);
       }
       break;
       case "[JUMP]":
       case "[jump]":
       $block = $e->getBlock();
       $cvc = (Int)$e->getBlock()->getX().":".(Int)$e->getBlock()->getY().":".(Int)$e->getBlock()->getZ().":".$block->getLevel()->getFolderName().":JUMP";
       $this->sign->set($cvc,[
        "x" => $block->getX(),
        "y" => $block->getY(),
        "z" => $block->getZ(),
        "World" => $block->getLevel()->getFolderName(),
        "JUMP" => (int) $line1,]);
       $this->sign->save();
       $e->setLine(0, "§b[JUMP]");
       $e->setLine(1, "§eHIGH : ".$line1."");
       $e->setLine(2, "");
       $e->setLine(3, "");
       break;
       case "[WLIST]":
       case "[wlist]":
       $block = $e->getBlock();
       $cvc = (Int)$e->getBlock()->getX().":".(Int)$e->getBlock()->getY().":".(Int)$e->getBlock()->getZ().":".$block->getLevel()->getFolderName().":WLIST";
       $this->sign->set($cvc,[
        "x" => $block->getX(),
        "y" => $block->getY(),
        "z" => $block->getZ(),
        "World" => $block->getLevel()->getFolderName(),
        "NOW" => $line1,]);
       $this->sign->save();
       $e->setLine(0, "§b[WLIST]");
       $e->setLine(1, "§e".$line1."");
       $e->setLine(2, "");
       $e->setLine(3, "");
       if($line1 == "on"){
        $this->getServer()->setConfigBool("white-list",true);
       }else{
        $this->getServer()->setConfigBool("white-list",false);
       }
  }
  }
  public function onCommand(CommandSender $sender, Command $command, $label, array $args) {
    switch($command->getName()){
      case "sign":
       $p = $this->getServer()->getPlayer($sender->getName());
       $x = $p->getX();
       $y = $p->getY();
       $z = $p->getZ();
       $level = $p->getLevel();
       $pos = new Vector3((Int)$x,(Int)$y,(Int)$z);
       $block = Block::get(63,0);
       $level->setBlock($pos, $block);
       $sign = $level->getTile($pos);
       $o = explode("/", $args[0]);
       if($sign instanceof Sign){//Signオブジェクトかの判定
       $sign->setText("".$o[0]."", "".$o[1]."", "".$o[2]."", "".$o[3]."");//文字をセット
       $sign->saveNBT();//データ(NBT)を保存
       $p->sendMessage("§b*Success*");
       $xyz = (Int)$x.":".(Int)$y.":".(Int)$z.":".$p->getLevel()->getFolderName();
       $this->sign->set($xyz,["1" => $args[0],"2" => $args[1],]);
     }
    }
  }
  public function PlayerTouch(PlayerInteractEvent $e){
    $block = $e->getBlock();
                $p = $e->getPlayer();
    $var = $block->getX().":".$block->getY().":".$block->getZ().":".$block->getLevel()->getFolderName();
    if($p->getGamemode() == 0){
    if($this->config->exists($var)){
      $pk = new TransferPacket();
      $a = $this->config->get($var);
            $pk->address = $a["IP"];
            $pk->port = $a["PORT"];
            $p->dataPacket($pk);
    }
    if($this->give->exists($var)){
      $b = $this->config->get($var);
      $id1 = $b["IP"];
      $id = intval($id1);
      $da1 = $b["DAMAGE"];
      $da = intval($da1);
      $how1 = $b["HOW"];
      $how = intval($how1);
      $item = Item::get($id, $da, $how);
      if($p->getInventory()->canAddItem($item)){
      $p->getInventory()->addItem($item);
    }else{
      $p->sendMessage("§b*Your inventory is full of other items!*");
    }
    }
    $var2 = $block->getX().":".$block->getY().":".$block->getZ().":".$block->getLevel()->getFolderName().":JUMP";
    if($this->sign->exists($var2)){
      $var21 = $this->sign->get($var2);
      $high = $var21["JUMP"];
      $MotionJ = new Vector3($p->getX(),$p->getY(),$p->getZ()); //初期座標
      $jump = (Int)$high; //ジャンプ分の高さ
      $MotionJ->y = $jump;
      $p->setMotion($MotionJ); //ジャンプを実行
    }
    $var2 = $block->getX().":".$block->getY().":".$block->getZ().":".$block->getLevel()->getFolderName().":WLIST";
    if($this->sign->exists($var2)){
      $var21 = $this->sign->get($var2);
      $now = $var21["NOW"];
      $pos = new Vector3((Int)$var21["x"], (Int)$var21["y"], (Int)$var21["z"]);//座標をセット
      $level = $p->getLevel();
    $sign = $level->getTile($pos);//Tileオブジェクトを取得
    if($sign instanceof Sign){//Signオブジェクトかの判定
      if($now == "ON"){
    $sign->setText("§b[WLIST]", "§eOFF", "", "");//文字をセット
    $sign->saveNBT();//データ(NBT)を保存
    $block = $e->getBlock();
       $cvc = (Int)$e->getBlock()->getX().":".(Int)$e->getBlock()->getY().":".(Int)$e->getBlock()->getZ().":".$block->getLevel()->getFolderName().":WLIST";
       $this->sign->set($cvc,[
        "x" => $block->getX(),
        "y" => $block->getY(),
        "z" => $block->getZ(),
        "World" => $block->getLevel()->getFolderName(),
        "NOW" => "OFF",]);
       $this->sign->save();
    $this->getServer()->setConfigBool("white-list",false);
  }else{
$sign->setText("§b[WLIST]", "§eON", "", "");//文字をセット
    $sign->saveNBT();//データ(NBT)を保存
    $block = $e->getBlock();
       $cvc = (Int)$e->getBlock()->getX().":".(Int)$e->getBlock()->getY().":".(Int)$e->getBlock()->getZ().":".$block->getLevel()->getFolderName().":WLIST";
       $this->sign->set($cvc,[
        "x" => $block->getX(),
        "y" => $block->getY(),
        "z" => $block->getZ(),
        "World" => $block->getLevel()->getFolderName(),
        "NOW" => "ON",]);
       $this->sign->save();
    $this->getServer()->setConfigBool("white-list",true);
  }
  }
    }
  }
  if($this->sign->exists($var)){
    $items = $p->getInventory()->getItemInHand();
    $var4 = $this->sign->get($var);
    if(!$items == 0){
      $level = $p->getLevel();
    $l2 = $var4["2"];
    $r =  explode("/", $l2);
    $pos = new Vector3($block->x, $block->y, $block->z);//座標をセット
    $sign = $level->getTile($pos);//Tileオブジェクトを取得
    if($sign instanceof Sign){//Signオブジェクトかの判定
    $sign->setText("".$r[0]."", "".$r[1]."", "".$r[2]."", "".$r[3]."");//文字をセット
    $sign->saveNBT();//データ(NBT)を保存
}
  }else{
    $level = $p->getLevel();
    $l1 = $var4["1"];
    $a =  explode("/", $l1);
    $pos = new Vector3($block->x, $block->y, $block->z);//座標をセット
    $sign = $level->getTile($pos);//Tileオブジェクトを取得
    if($sign instanceof Sign){//Signオブジェクトかの判定
    $sign->setText("".$a[0]."", "".$a[1]."", "".$a[2]."", "".$a[3]."");//文字をセット
    $sign->saveNBT();//データ(NBT)を保存
  }
  }
  }
}
  public function onBreak(BlockBreakEvent $event){
       $player = $event->getPlayer();
       $block = $event->getBlock();
       $x = $block->getX();
       $y = $block->getY();
       $z = $block->getZ();
       $world = $block->getLevel()->getName();
       $name = $player->getName(); 
       $xyz = (Int)$event->getBlock()->getX().":".(Int)$event->getBlock()->getY().":".(Int)$event->getBlock()->getZ().":".$world;
       $xyz2 = (Int)$event->getBlock()->getX().":".(Int)$event->getBlock()->getY().":".(Int)$event->getBlock()->getZ().":".$world.":JUMP";
            if($this->config->exists($xyz)){
                       $this->config->remove($xyz);
                        $this->config->save();}if($this->give->exists($xyz)){
                       $this->give->remove($xyz);
                        $this->give->save();}if($this->sign->exists($xyz)){
                       $this->sign->remove($xyz);
                        $this->sign->save();}if($this->sign->exists($xyz2)){
                       $this->sign->remove($xyz2);
                        $this->sign->save();}}
  public function del(){
    $this->ln->setBlock(new Vector3($this->bx,$this->by,$this->bz), Block::get(0,0));
    $this->getServer()->getScheduler()->cancelTask("del");
  }
  public function cou(){
    $this->c - 1;
    $pos = new Vector3($this->x, $this->y, $this->z);//座標をセット
    $sign = $this->level->getTile($pos);//Tileオブジェクトを取得
    if($sign instanceof Sign){//Signオブジェクトかの判定
    $sign->setText("".$this->c."", "", "", "");//文字をセット
    $sign->saveNBT();//データ(NBT)を保存
  }
  if($this->c = 0){
    $this->level->setBlock(new Vector3($this->x,$this->y,$this->z), Block::get(0,0));
  }
  }
}
