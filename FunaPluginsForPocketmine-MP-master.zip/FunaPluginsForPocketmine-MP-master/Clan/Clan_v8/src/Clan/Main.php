<?php

namespace Clan;

use pocketmine\plugin\PluginBase;
use pocketmine\Server;
use pocketmine\utils\Config;
use pocketmine\item\Item;
use pocketmine\scheduler\Task;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\entity\EntityTeleportEvent;
use pocketmine\event\entity\EntityDeathEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityLevelChangeEvent;
use pocketmine\network\protocol\AddEntityPacket;
use pocketmine\network\protocol\SetEntityMotionPacket;
use pocketmine\network\protocol\AddPlayerPacket;
use pocketmine\network\protocol\PlayerEquipmentPacket;
use pocketmine\network\protocol\RemoveEntityPacket;
use pocketmine\network\protocol\SetEntityLinkPacket;
use pocketmine\network\protocol\UpdateAttributesPacket;
use pocketmine\network\protocol\EntityEventPacket;
use pocketmine\network\protocol\AddItemEntityPacket;
use pocketmine\network\protocol\SetEntityDataPacket;
use pocketmine\network\protocol\AdventureSettingsPacket;
use pocketmine\network\protocol\BatchPacket;
use pocketmine\network\protocol\DisconnectPacket;
use pocketmine\network\protocol\RespawnPacket;
use pocketmine\network\protocol\SetSpawnPositionPacket;
use pocketmine\network\protocol\TakeItemEntityPacket;
use pocketmine\network\protocol\TileEntityDataPacket;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\network\protocol\DataPacket;
use pocketmine\network\protocol\Info as ProtocolInfo;
use pocketmine\Entity\entity;
use pocketmine\math\Vector3;
use pocketmine\math\Vector2;
use pocketmine\Player;
use pocketmine\level\Level;
use pocketmine\level\Explosion;
use pocketmine\network\protocol\AddMobPacket;
use pocketmine\level\format\mcregion\Chunk;
use pocketmine\scheduler\PluginTask;
use pocketmine\scheduler\CallbackTask;
use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\Byte;
use pocketmine\nbt\tag\Compound;
use pocketmine\nbt\tag\Double;
use pocketmine\nbt\tag\Enum;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\nbt\tag\ShortTag;
use pocketmine\utils\TextFormat;
use pocketmine\utils\MainLogger;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntitySpawnEvent;
use pocketmine\event\entity\EntityDamageByChildEntityEvent;
use pocketmine\level\Position;
use pocketmine\entity\Villager;
use pocketmine\event\TranslationContainer;
use pocketmine\network\Network;
use pocketmine\entity\Human;
use pocketmine\entity\Squid;
use pocketmine\entity\PrimedTNT;
use pocketmine\entity\Arrow;
use pocketmine\event\player\PlayerItemHeldEvent ;
use pocketmine\entity\Effect;
use pocketmine\entity\Item as ItemEntity;
use pocketmine\entity\FallingSand;
use pocketmine\inventory\Inventory;
use pocketmine\plugin\Plugin;
use pocketmine\block\Block;
use pocketmine\tile\Tile;
use pocketmine\utils\UUID;
use pocketmine\utils\BinaryStream;
use pocketmine\event\level\ChunkLoadEvent;
use pocketmine\level\particle\FloatingTextParticle;
use pocketmine\event\block\SignChangeEvent;
use pocketmine\tile\Sign;

class Main extends PluginBase implements Listener{

  public function onEnable(){
    $this->getServer()->getPluginManager()->registerEvents($this,$this);
    if(!file_exists($this->getDataFolder())){
        mkdir($this->getDataFolder(), 0744, true);
    }
    $this->clan = new Config($this->getDataFolder() . "clan.yml", Config::YAML);
    $this->join = new Config($this->getDataFolder() . "join.yml", Config::YAML);
    $this->m = new Config($this->getDataFolder() . "mem.yml", Config::YAML);
    $this->l = new Config($this->getDataFolder() . "LEVEL/level.yml", Config::YAML);
    $this->le = new Config($this->getDataFolder() . "LEVEL/levelup.yml", Config::YAML);
    $this->cp = new Config($this->getDataFolder() . "CP/cp.yml", Config::YAML);
    $this->buy = new Config($this->getDataFolder() . "CP/buy.yml", Config::YAML);
    $this->ai = new Config($this->getDataFolder() . "ai.yml", Config::YAML,
    array(
          "x座標" => "128",
          "y座標" => "5",
          "z座標" => "128"
    ));
    $this->rand = mt_rand(1000,10000);
    $this->rand1 = mt_rand(1000,10000);
  }

  public function onCommand(CommandSender $sender, Command $command, $label, array $args){
    if(strtolower($command->getName()) == "clan"){
      if(!isset($args[0])) return false;
      switch($args[0]){
       case "help":
        $sender->sendMessage("§a[About CLANPLUGIN]\n§b/clan new §f新たにクランを作ります\n§b/clan list §fクランのリスト\n§b/clan info §fクランの情報を見ます\n§b/clan m <Name> <clan名> §fメンバーを追加します");
        break;

       case "new":
       if(!isset($args[1])) return false;
        $name = $sender->getName();
        $time = time();
        if(!$this->clan->exists($args[1])){
        $this->clan->set(strtolower($args[1]),
        array("リーダー" => $name,"作成時刻" => $time));
        $this->clan->save();
        $this->l->set($args[1], "1");
        $this->l->save();
        $this->le->set($args[1], "1");
        $this->le->save();
        $sender->sendMessage("§a[CLAN]§fクランの作成が完了しました");
        $this->m->set($name, $args[1]);
        $this->m->save();
        $this->cp->set($args[1], 0);
        $this->cp->save();
      }else{
        $sender->sendMessage("§c同名のクランが存在します！");
      }
        break;

       case "del":
       if(!isset($args[1])) return false;
        $this->clan->remove($args[1]);
        break;

       case "info":
       if(!isset($args[1])) return false;
       if($this->clan->exists($args[1])){
        if (file_exists("CP")) {
          if (file_exists("LEVEL")) {
        $leader = $this->clan->getAll()[strtolower($args[1])]["リーダー"];
        $t = $this->clan->getAll()[strtolower($args[1])]["作成時刻"];
        $men = $this->l->get($args[1]);
        $level = $this->le->get($args[1]);
        $sub = $this->m->get($args[1]);
        $cp = $this->cp->get($args[1]);
        $sender->sendMessage("§aClan : §f".$args[1]."\n§a作成者 : §f".$leader."\n§aサブ : §f".$sub."\n§a作成時刻 : §f".$t."\n§a人数 : §f".$men."\n§aレベル : §f".$level."\n§aCP : §f".$cp."");
      }}
      }else{
        $sender->sendMessage("§c存在しないクランです！");
      }
      break;

       case "m":
       if(!isset($args[1])) return false;
       if(!isset($args[2])) return false;
       if($this->clan->exists($args[2])){
        $clan = $this->clan->getAll()[strtolower($args[2])]["リーダー"];
        $name = $sender->getName();
        if($clan === $name){
          $cn = $this->m->get($name);
          $this->m->set($args[1], $cn);
          $this->m->save();
          $how = $this->l->get($cn);
          $many = $how + 1;
          $this->l->set($cn, $many);
          $this->l->save();
          $sender->sendMessage("§a[Clan]§f登録完了");
          $player = $this->getServer()->getPlayer($args[1]);
          if($player instanceof Player){
          $player->sendMessage("§a[Clan]§fあなたは".$args[2]."に所属しました");
        }
        }else{
          $sender->sendMessage("§cあなたはリーダーではありません！");
        }
      }
        break;

        case "sub":
        if(!isset($args[1])) return false;
        if(!isset($args[2])) return false;
        $clan = $this->clan->getAll()[strtolower($args[2])]["リーダー"];
        $name = $sender->getName();
        if($clan === $name){
          $cn = $this->m->get($name);
          $this->m->set($args[2], $args[1]);
          $this->m->save();
          $sender->sendMessage("§a[Clan]§f登録完了");
        }else{
          $sender->sendMessage("§cあなたはリーダーではありません！");
        }
        break;

        case "list":
        //PBANのコードを参考にさせていただきました
        $max = 0;
        foreach($this->clan->getAll(true) as $c){
        $max += count($c);
        }
        $max = ceil(($max / 5));
        $page = array_shift($args);
        $page = max(1, $page);
        $page = min($max, $page);
        $page = (int)$page;
        $sender->sendMessage("CLANリスト".$page."/".$max." を表示");
        $clanlist = array_reverse($this->clan->getAll(),true);
        $i = 0;
        foreach($clanlist as $b=>$a){
        if(($page - 1) * 5 <= $i && $i <= ($page - 1) * 5 + 4){
        $i1 = $i + 1;
        $sender->sendMessage("[".$i1."]".$b." : リーダー:".$clanlist[$b]["リーダー"]." 作成時刻:".$clanlist[$b]["作成時刻"]);
        }
        $i++;
        }
        if(count($args) >= 2){
        $max = 0;
        foreach($this->clan->getAll(true) as $c){
        $max += count($c);
        }
        $max = ceil(($max / 5));
        $page = array_shift($args);
        $page = max(1, $page);
        $page = min($max, $page);
        $page = (int)$page;
        $sender->sendMessage("CLANリスト".$page."/".$max." を表示");
        $clanlist = array_reverse($this->banlist->getAll(),true);
        $i = 0;
        foreach($clanlist as $b=>$a){
        if(($page - 1) * 5 <= $i && $i <= ($page - 1) * 5 + 4){
        $i1 = $i + 1;
        $sender->sendMessage("[".$i1."]".$b." : リーダー:".$clanlist[$b]["リーダー"]." 作成時刻:".$clanlist[$b]["作成時刻"]);
        }
        $i++;
        }
        }
      break;

      case "rank":
       if(!isset($args[1])) return false;
        $clan = $this->clan->getAll()[strtolower($args[1])]["リーダー"];
        $name = $sender->getName();
        if($clan === $name){
          $cn = $this->m->get($name);
          $how = $this->l->get($cn);
          if($how >= 5){
            $this->le->set($cn, "2");
            $this->le->save();
            $sender->sendMessage("§a[CLAN]§fあなたのクランは現在レベル2です！");
          }
          elseif($how >= 10){
            $this->le->set($cn, "3");
            $this->le->save();
            $sender->sendMessage("§a[CLAN]§fあなたのクランは現在レベル3です！");
          }
          elseif($how >= 15){
            $this->le->set($cn, "4");
            $this->le->save();
            $sender->sendMessage("§a[CLAN]§fあなたのクランは現在レベル4です！");
          }
          elseif($how >= 20){
            $this->le->set($cn, "5");
            $this->le->save();
            $sender->sendMessage("§a[CLAN]§fあなたのクランは現在レベル5です！");
          }
          elseif($how >= 30){
            $this->le->set($cn, "6");
            $this->le->save();
            $sender->sendMessage("§a[CLAN]§fあなたのクランは現在レベル5です！");
          }
          elseif($how >= 40){
            $this->le->set($cn, "7");
            $this->le->save();
            $sender->sendMessage("§a[CLAN]§fあなたのクランは現在レベル5です！");
          }
          elseif($how >= 50){
            $this->le->set($cn, "8");
            $this->le->save();
            $sender->sendMessage("§a[CLAN]§fあなたのクランは現在レベル5です！");
          }
          else{
            $sender->sendMessage("§a[CLAN]§fあなたのクランは現在レベルアップできません！");
          }
        }else{
          $sender->sendMessage("§cあなたはリーダーではありません！");
        }
        break;

        case "ban":
         if(!isset($args[1])) return false;
        if(!isset($args[2])) return false;
        if($this->clan->exists($args[2])){
        $clan = $this->clan->getAll()[strtolower($args[2])]["リーダー"];
        $sub = $this->m->get($args[2]);
        $name = $sender->getName();
        $c = $this->clan->get($args[1]);
        if($clan === $name){
          if($this->m->exists($args[1])){
            if($c === $args[2]){
          $this->m->remove($args[1]);
          $this->m->save();
          $sender->sendMessage("§a[Clan]§fBANが完了しました");
          }else{
        $sender->sendMessage("§a[Clan]§fあなたのクラン以外のプレイヤーです！");
      }
        }else{
          $sender->sendMessage("§a[Clan]§f存在しないプレイヤーです！");
        }
        }elseif($sub === $name){
          if($this->m->exists($args[1])){
            if($c === $args[2]){
          $this->m->remove($args[1]);
          $this->m->save();
          $sender->sendMessage("§a[Clan]§fBANが完了しました");
          }else{
        $sender->sendMessage("§a[Clan]§fあなたのクラン以外のプレイヤーです！");
      }
          }else{
          $sender->sendMessage("§a[Clan]§f存在しないプレイヤーです！");
        }
        }else{
          $sender->sendMessage("§cあなたはリーダーではありません！");
        }
      }else{
        $sender->sendMessage("存在しないCLANです！");
      }
      break;

      case "cp":
       if(!isset($args[1])) return false;
       $wood = $args[1] * 5;
       $item = Item::get(5, 0, $wood);
       $name = $sender->getName();
       if($this->m->exists($name)){
       $clan = $this->m->get($name);
       $p = $this->getServer()->getPlayer($name);
       if($p->getInventory()->contains($item)){//特定のアイテムが指定した数以上あるか
        $p->getInventory()->removeItem($item);
        $cpp = $this->cp->get($clan);
        $cps = $cpp + $args[1];
        $this->cp->set($clan, $cps);
        $this->cp->save();
        $sender->sendMessage("§a[Clan]§fCPを寄付しました");
       }else{
        $sender->sendMessage("§a[Clan]§fCPを送れませんでした！");
       }
       }else{
      $sender->sendMessage("§a[Clan]§fあなたはクランに所属していません！");
      break;
     }
       break;

      case "buy":
       if(!isset($args[1])) return false;
       if(!isset($args[2])) return false;
       //$args[1]が支払うCP,[2]が相手Clan
       $name = $sender->getName();
       $a = $this->m->get($name);
       if($this->clan->exists($a)){
        $clan = $this->clan->getAll()[strtolower($a)]["リーダー"];
        if($clan === $name){
          $b = $this->cp->get($a);
          $c = $b - $args[2];
          if($c <= 0){
            $sender->sendMessage("§a[Clan]§fお金が足りません！");
            break;
          }
          $this->cp->set($a, $c);
          $this->cp->save();
          if($this->clan->exists($args[2])){
            $d = $this->cp->get($args[2]);
            $e = $d + $args[1];
            $this->cp->set($args[2], $e);
            $this->cp->save();
          $sender->sendMessage("§a[Clan]§f支払い完了");
        }else{
          $sender->sendMessage("§a[Clan]§f存在しないクランです！");
        }
        }else{
          $sender->sendMessage("§a[Clan]§fあなたはリーダーではありません！");
        }
      }


      case "c":
      //COREを参考にしました
      if(isset($args[1])){
        if (!$sender instanceof ConsoleCommandSender){
        $message = $args[1];
        $online = Server::getInstance()->getOnlinePlayers();
        $nametags = $sender->getNameTag();
        $name = $sender->getName();
        $clan = $this->m->get($name);
        if(isset($args[1])){ $sender->sendMessage("§a[Clan]§fメッセージは一文にしてください");}
        foreach($online as $player){
          $nametag = $player->getNameTag();
          if(strpos($nametags,$clan) !== false){
            if(strpos($nametag,$clan) !== false){
              $player->sendMessage("<§f[§d".$sender->getName()."§f]> ".$message);
              $this->getLogger()->info("<§f[§d".$sender->getName()."§f]> ".$message);
            }
            }
          }
        }else{
          $sender->sendMessage("コンソールからの送信は出来ません！");
        }
      }
      case "pay":
        if(isset($args[1])){
          if(isset($args[2])){
            $clan = $this->m->get($sender->getName());
            $cp = $this->cp->get($clan);
            if($this->buy->exists($args[2])){
              $id = intval($args[2]);
              $am = $this->buy->get($id);
              if($am > $cp){
                $sender->sendMessage("§a[Clan]§fCPがたりません");
              }else{
                if(!isset($args[3])){
                $item = Item::get($id, 0, $args[1]);
                $p = $this->getServer()->getPlayer($sender->getName());
                $p->getInventory()->addItem($item);
                $mo = $cp - $am;
                $this->cp->set($clan, $mo);
                $this->cp->save();
                $sender->sendMessage("§a[Clan]§f購入ができました！");
              }else{
                $item = Item::get($id, $args[3], $args[1]);
                $p = $this->getServer()->getPlayer($sender->getName());
                $p->getInventory()->addItem($item);
                $mo = $cp - $am;
                $this->cp->set($clan, $mo);
                $this->cp->save();
                $sender->sendMessage("§a[Clan]§f購入ができました！");
              }
              }
            }else{
              $sender->sendMessage("§a[Clan]§fそのIDの商品は存在しません！");
            }
          }else{
            $sender->sendMessage("§a[Clan]§f二つ目にIDを記入してください。もしあなたが欲しいITEMにダメージ値があれば三つ目にダメージ値を書いてください。決して : を使わないでください。");
          }
        }else{
          $sender->sendMessage("§a[Clan]§f一つ目に個数を記入してください。");
        }
        break;
        case "sell":
        $p = $this->getServer()->getPlayer($sender->getName());
        if(isset($args[1])){
          if(isset($args[2])){
         if($p->isOp()){
          $this->buy->set($args[1], $args[2]);
          $this->buy->save();
          $sender->sendMessage("§a[Clan]§f売りました。");
         }
       }}
       break;
       case "exit":
       $this->m->remove($sender->getName());
       $this->m->save();
       $many = $how - 1;
          $this->l->set($cn, $many);
          $this->l->save();
          $sender->sendMessage("§a[Clan]§f脱退完了");
          break;
        case "inv":
         if(!isset($args[0])){
          $sender->sendMessage("§a[Clan]§f紹介文がセットされていません！");
          break;
         }
         $players = $this->getServer()->getOnlinePlayers();
         $s = count($players);
         for($i = 0; $i < 2; $i++){
          foreach ($players as $player) {
            $p = mt_rand(1,$s);
            if($p == 2){
              $player->sendMessage("§a[Clan勧誘]§f".$args[1]."");
            }
          }
         }
         break;

        case "into":
         if(!isset($args[0])){
          $sender->sendMessage("§a[Clan]§fクランが指定されていません！");
          break;
         }
         if(!isset($args[1])){
          $sender->sendMessage("§a[Clan]§f申請文が設定されていません！");
          break;
         }
         $leader = $this->clan->getAll()[strtolower($args[0])]["リーダー"];
         $this->join->set(strtolower($leader),
        array("申請文" => $args[1],"申請者" => $sender->getName()));
         $this->join->save();
         $sender->sendMessage("§a[Clan]§f申請しました");
    }
  }
}
  public function onReceive(DataPacketReceiveEvent $event){
    $pk = $event->getPacket();
    if($pk instanceof InteractPacket){
      if($pk->target == $this->rand && $pk::NETWORK_ID == 0x1f){
        $p = $event->getPlayer();
        $name = $p->getName();
      }
    }
  }
  public function onJoin(PlayerJoinEvent $e){
    $p = $e->getPlayer();
    $name = $p->getName();
    if($this->m->exists($name)){
       $clan = $this->m->get($name);
       $tag = $p->getNameTag();
       $p->setNameTag("[§b".$clan."§f]".$tag."");
       $p->save();
     }
     if($this->join->exists($name)){
      $m = $this->join->getAll()[strtolower($name)]["申請文"];
      $s = $this->join->getAll()[strtolower($name)]["申請者"];
      $p->sendMessage("§a[Clan申請]§f".$s.">".$m."");
      $this->join->remove($name);
      $this->join->save();
     }

       $xd = $this->ai->get("x座標");
    $yd = $this->ai->get("y座標");
    $zd = $this->ai->get("z座標");
    $x = intval($xd);
    $y = intval($yd);
    $z = intval($zd);
    $p = $e->getPlayer();
    $name = $p->getName();
    $skin = $p->getSkinData();


        $pk1 = new AddPlayerPacket();
    $pk1->uuid = UUID::fromRandom();
    $pk1->username = $clan;
    $pk1->eid = $this->rand1;
    $pk1->x = $x + 1.5;
    $pk1->y = $y - 0.5;
    $pk1->z = $z;
    $pk1->speedX = 0;
    $pk1->speedY = 0;
    $pk1->speedZ = 0;
    $pk1->yaw = 0;
    $pk1->pitch = 0;
    $pk1->item = Item::get(0);
    $pk1->metadata = [
      Entity::DATA_FLAGS => [Entity::DATA_TYPE_BYTE, 0],
      Entity::DATA_FLAGS => [Entity::DATA_TYPE_BYTE, 0 << Entity::DATA_FLAG_SILENT],
      Entity::DATA_FLAGS => [Entity::DATA_TYPE_BYTE, 1 << Entity::DATA_FLAG_INVISIBLE],
      Entity::DATA_FLAGS => [Entity::DATA_TYPE_BYTE, 1 << Entity::DATA_FLAG_NO_AI],
      Entity::DATA_LEAD_HOLDER => [Entity::DATA_TYPE_LONG, -1],
      ];
        $p->dataPacket($pk1);
        if($this->m->exists($p->getName())){
        $clan = $this->m->get($p->getName());
        $position = new Vector3($x + 1.5, $y + 1.8, $z);
        $p->getLevel()->addParticle(new FloatingTextParticle($position, "§6Clan§f : §b".$clan."")); 
      }
  }
  public function onEntityDamageByEntity(EntityDamageEvent $event){
        if($event instanceof EntityDamageByEntityEvent){
                $damager = $event->getDamager(); //殴った人                
                $player = $event->getEntity();//殴られた人
                if($player instanceof Player and $damager instanceof Player){
                if($this->m->exists($damager)){
                  $d = $this->m->get($damager);
                if($this->m->exists($player)){
                  $p = $this->m->get($player);
                if($d === $p){
                  $event->setCancelled();
                }
              }
            }
              }
        }
}
 public function onSignChange(SignChangeEvent $e){
        $line = $e->getLine(0);
      if($line == "clan"){
        $p = $e->getPlayer();
        if($this->m->exists($p->getName())){
          $clan = $this->m->get($p->getName());
          $e->setLine(0, "§b[Clan Status]");
          $e->setLine(1, "§eName : §b".$p->getName().""); 
        $e->setLine(2, "§e所属クラン : §b".$clan."");
        $e->setLine(3, "§eリーダー : §b".$this->clan->getAll()[strtolower($clan)]["リーダー"]."");
        }
      }}
  function newClan($clanname,$name){
        $time = time();
        if(!$this->clan->exists($clanname)){
        $this->clan->set(strtolower($clanname),
        array("リーダー" => $name,"作成時刻" => $time));
        $this->clan->save();
        $this->l->set($clanname, "1");
        $this->l->save();
        $this->le->set($clanname, "1");
        $this->le->save();
        return "§bクランの作成が完了しました";
        $this->m->set($name, $clanname);
        $this->m->save();
        $this->cp->set($clanname, 0);
        $this->cp->save();
      }else{
        return "§c同名のクランが存在します！";
      }
  }
   function joinClan($clanname,$name){
    if($this->clan->exists($clanname)){
        if($clan === $name){
          $cn = $this->m->get($name);
          $this->m->set($clanname, $cn);
          $this->m->save();
          $how = $this->l->get($cn);
          $many = $how + 1;
          $this->l->set($cn, $many);
          $this->l->save();
          return "§a[Clan]§f登録完了";
        }else{
          return "§cあなたはリーダーではありません！";
        }
      }
   }
   function checkClan($clanname){
    if($this->clan->exists($clanname)){
      return true;
    }else{
      return false;
    }
   }
   function setCP($clanname,$how){
       if($this->clan->exists($clanname)){
        $clan = $this->clan->getAll()[strtolower($clanname)]["リーダー"];
          $b = $this->cp->get($clanname);
          $c = (Int)$b + $how;
          $this->cp->set($clanname, $c);
          $this->cp->save();
      }
   }
}
