<?php

namespace Lie;

use pocketmine\plugin\PluginBase;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\Listener;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\CommandExecutor;

use pocketmine\item\Item;


class Main extends PluginBase implements Listener{

	public function onEnable()
	{
    $this->getServer()->getPluginManager()->registerEvents($this,$this);
	}

  public function onCommand(CommandSender $sender, Command $command, $label, array $args)
	{
        switch (strtolower($command->getName())) {     
        case "ine":
        if(!isset($args[0])) return false;
         if($sender->isOp()){
         $this->getServer()->broadcastMessage("§e".$args[0]." joined the game");
       }else{
        $sender->sendMessage("§c権限がありません！");
       }
        break;

        case "inj":
        if(!isset($args[0])) return false;
         if($sender->isOp()){
         $this->getServer()->broadcastMessage("§e".$args[0]."が世界にやってきました");
         }else{
        $sender->sendMessage("§c権限がありません！");
       }
        break;

        case "lee":
        if(!isset($args[0])) return false;
         if($sender->isOp()){
         $this->getServer()->broadcastMessage("§e".$args[0]." left the game");
         }else{
        $sender->sendMessage("§c権限がありません！");
       }
        break;

        case "lej":
        if(!isset($args[0])) return false;
         if($sender->isOp()){
         $this->getServer()->broadcastMessage("§e".$args[0]."が世界を去りました");
         }else{
        $sender->sendMessage("§c権限がありません！");
       }
        break;

        case "lc":
        if(!isset($args[0])) return false;
        if(!isset($args[1])) return false;
         if($sender->isOp()){
         $this->getServer()->broadcastMessage("<".$args[0]."> ".$args[1]."");
         }else{
        $sender->sendMessage("§c権限がありません！");
       }
        break;

        case "lop":
        if(!isset($args[0])) return false;
         if($sender->isOp()){
         $player = $this->getServer()->getPlayer($args[0]);
         if ($player instanceof Player){
         $player->sendMessage("§fYou are now op!");
     }else{
         $sender->sendMessage("そのプレイヤーはオフラインです");
     }
         }else{
        $sender->sendMessage("§c権限がありません！");
    }
        break;

        case "lg":
        if(!isset($args[0])) return false;
        if($sender->isOp()){
            $player = $this->getServer()->getPlayer($args[0]);
            if ($player instanceof Player){
                $player->sendMessage("§fゲームモードが変更されました");
                $item = Item::get(1, 0, 1);
                $player->getInventory()->addItem($item);
                $item = Item::get(2, 0, 1);
                $player->getInventory()->addItem($item);
                $item = Item::get(3, 0, 1);
                $player->getInventory()->addItem($item);
                $item = Item::get(4, 0, 1);
                $player->getInventory()->addItem($item);
                $item = Item::get(5, 0, 1);
                $player->getInventory()->addItem($item);
     }else{
         $sender->sendMessage("そのプレイヤーはオフラインです");
     }
     }else{
         $sender->sendMessage("§c権限がありません！");
        }

    }

    }


}

