﻿# R_Funa's Plugins For Pocketmine-MP
 
 ## 概要
 
 ここにあるPluginのすべてについての二次配布を禁止します。
 ただし、R_Funaが製作した事を明記し、このサイトへのURLを添付した場合のみ許可することとします。
 ここにあるプラグインの名前が書いてあるフォルダのうち、最初のフォルダをそのままpluginsファイルへ入れた場合、プラグインは動作しません。
 その中にあるSRCもしくは.pharのどちらかをpluginsへ入れることで作動します。
 また、プラグインに関する説明は読むことをお勧めします。読まなかった場合の事故などについては製作者は一切の責任を負いません。
 
## Select Plugin: [Tennis](#Tennis)/ [Dialect](#Dialect)/ [Track](#Track)/ [Fencing](#Fencing)/ [Board](#Board)/ [SignEvent](#SignEvent)/ [Clan](#Clan)/ [MakeHouse](#MakeHouse)

<a name="Tennis"></a>
## Tennis
**| 配布中 : Version 3.0 | (2017/5/2配布開始)**<br><br>
機能 : テニスのルールを実装、鉱石ブロックタップで打ち返す。麦ブロックタップでサーブ。黒曜石破壊でスマッシュ。<br>
Command : /s（開始）・/f（終了)・/r（ラケット変更）<br><br>

テニスコート作り方はTennisフォルダ内の画像のように作ってください。寸法などは自由です。<br>
鉱石ブロックと麦ブロックあればプレイ可能です。<br>
<br>

<a name="Dialect"></a>
## Dialect
**| 配布中 : Version 1.0 | (2017/5/4配布開始)**<br>
/word <方言名>　/wordlistにある方言を方言名に入れれば自動変換<br>
/wordlist　　方言を全て確認<br><br>

関西弁でも変換される言葉に限りがあります。<br><br>

<a name="Track"></a>
## Track
**| 配布中 : Version 1.0 | (2017/5/4配布開始)**<br>
/track <プレイヤー名> で追跡開始<br>
/tfin　で追跡終了<br>
非常にカクカクします。<br><br>

<a name="Fencing"></a>
## Fencing
**| 配布中 : Version 1.0 | (2017/5/1配布開始)**<br>
機能 : フェンシングのルールを実装<br>
追加Command : /fen helpで全てを確認可能<br>
Fencingは一突きすれば勝てるという原則とともに、<br>スニークしていれば一突きから防衛できるという簡単なシステムが付いています。<br>単純なルールですが奥が深いこのゲームを楽しむことができ、暇つぶしには最適です！<br><br>

<a name="Board"></a>
## Boad
**| 配布中 : Version 1.0 | (2017/5/1配布開始)**<br>
-GOOD・BAD機能を追加。<br>
-掲示板が使える​<br>
/chat <Contents> 掲示板に投稿<br>
/good <スレッドナンバー> 高評価<br>
/bad <スレッドナンバー> 低評価<br>
/bl　掲示板を閲覧<br><br>

<a name="SignEvent"></a>
## SignEvent
**| 配布中 : Version 2.0 | (2017/2/12配布開始)**<br>
*サーバー間移動を看板で*<br>
　　　[transfer]<br>
　　　　 IP<br>
　　　　PORT<br>
　　 何も書かない<br><br>

*看板で座標を取得*<br>
　　　　[xyz]<br>
　　 何も書かない<br>
　　 何も書かない<br>
　　 何も書かない<br><br>

*自分の情報を看板に*<br>
　　　[mystatus]<br>
　　 何も書かない<br>
　　 何も書かない<br>
　　 何も書かない<br><br>

*無料アイテム配布を看板で*<br>
　　　　[giveid]<br>
　　 　　　ID<br>
　　 　 DAMAGE<br>
　　 　　 個数<br><br>

*看板でホワリスONOFF*<br>
　　　 [WLIST]<br>
　　 　ON or OFF<br>
　　 何も書かない<br>
　　 何も書かない<br><br>

*ワールドの情報を看板に*<br>
　　　 [WINFO]<br>
　　 何も書かない<br>
　　 何も書かない<br>
　　 何も書かない<br>
<br><br>

<a name="Clan"></a>
## Clan
**| 配布中 : Version 8.0 | (2017/5/29配布開始)**<br>
[About ClanPlugin]<br>
このPluginではClan(=グループ)<br>を作成しマインクラフトマルチの機能を一層豊かにすることができます。<br>
Clan内での様々な機能によりあなたはより充実した楽しい時間を過ごせることとなるでしょう。<br><br>

[Update]<br>
v1.0.0<br>
-同じクランの人への攻撃は効果がない<br>
-ネームタグにクラン名を表示​<br>
v2.0.0<br>
-クランのレベル機能実装<br>
-- /clan rank CLANname<br>
v3.0.0<br>
-クランメンバーをBANする機能を追加<br>
-- /clan ban <相手> <CLANname>​<br>
-サブリーダー機能を追加<br>
-- /clan sub <相手> <CLANname>​<br>
v3.0.1<br>
-不具合修正（レベルUPに関する）<br>
　　ー＞Config類の削除の必要はありません<br>
v4.0.0<br>
-CP(ClanPoint)を追加<br>
-- /clan cp <寄付するCP> <CLANname>​<br>
-CPによりクラン同士のやりとりが可能に<br>
-- /clan buy <支払うCP> <相手CLANname>​<br>
v5.0.0<br>
-Clan内チャット実装<br>
-- /clan c <内容>​<br>
-不具合修正<br>
v5.0.1<br>
-不具合修正<br>
-攻撃時の不具合修正<br>
※Fileの形式が変更されているため、Clanの設定し直しが大変だという方は今まで通りのv5.0.0を、<br>Clanの設定し直しについての心配がないという方はv5.0.1をご使用ください。​<br>
v6.0.0<br>
-LEVEL機能およびCP機能を選択制に。<br>
-AI機能を追加<br>
-CP機能を追加​<br>
v7.0.0<br>
-クランメンバーが自ら脱退することが可能に<br>
-- /clan exit<br>
-鯖内にいるプレイヤーにランダムに勧誘<br>
-- /clan inv <紹介文><br>
-参加申請を可能に<br>
-- /clan into <Clan名> <申請文><br>
-看板で自分のクラン情報を確認（一行目にclanとかく）​<br>
v8.0.0 公開中<br>
-APIを追加​<br><br>

[Commands]<br>
基本Commandは以下の通り<br>
/clan new <ClanName> クランを作成<br>
/clan m <相手> <メンバー> メンバー追加<br>
/clan info <ClanName> クラン情報を取得<br>
/clan list クランのリスト<br>
そのほかコマンドは上のUpdate情報よりご確認ください。<br><br>

[About CP]<br>
木材（オーク）五個　= 1CPという交換比率です<br><br>

[APIの使い方]<br>
＊必須文＊<br>
PHP:<br>
$this->Clan = $this->getServer()->getPluginManager()->getPlugin("Clan");<br>        if($this->Clan === null){<br>            $this->getLogger()->info(TextFormat::RED ."Clanがないです");<br>            $this->getServer()->shutdown();<br>        }else{<br>            $this->getLogger()->info(TextFormat::AQUA."Clanを読み込みました");<br>        }<br><br>

＊CLAN追加コード＊<br>
PHP:<br>
$this->Clan->newClan("クランの名前", "リーダーにする人の名前");<br>
＊CLANメンバー追加コード＊<br>
PHP:<br>
$this->Clan->joinClan("クランの名前", "リーダーにする人の名前");<br>
＊CLANの有無を確認するコード＊<br>
PHP:<br>
$this->Clan->checkClan("クランの名前");<br>
あればtrue　なければfalse<br>

＊CPを増やすコード＊<br>
PHP:<br>
$this->Clan->setCP("クランの名前", 増やすCP);<br><br>

[V6.0.0以降について]<br>
[CP機能]<br><br>

CP（全て大文字）というフォルダをClan（clan.yml・mem.ymlなどが入っているフォルダ）の<br>中に作ってください。（今まで使っていた人も、これから使う人も）<br>
　今までこのプラグインを使っていたという人はcp.ymlをそのフォルダ内に移行してください。<br>
　このフォルダを作ることでCP機能が使えるようになります。<br><br>
　
CPで物を購入できるようになりました！<br>
　　/cp pay <個数> <ID>（<ダメージ値>）//購入します<br>
　　/cp sell <ID> <個数> //CPで購入できるアイテムを増やします。<br>（ID 1を追加した場合IDが1のものは全て販売対象となります）<br>

[LEVEL機能]<br><br>

LEVEL（全て大文字）というフォルダをClan（clan.yml・mem.ymlなどが入っているフォルダ）の<br>中に作ってください。（今まで使っていた人も、これから使う人も）<br>
　今までこのプラグインを使っていたという人は<br>level.ymlとlevelup.ymlをそのフォルダ内に移行してください。<br>
　このフォルダを作ることでLEVEL機能が使えるようになります。<br><br>

[AI機能]<br>
AI機能:<br><br>

ai.ymlが通常のファイル内に生成されるようになります。<br>そこに座標を書き込むことで自分の所属クランがわかるAIを指定した位置に設置できます。<br><br>

※全ての機能を使う場合ファイル構造は必ず下のようになるようにお願いします（V6.0.0以降）<br><br>

Clanー>cp.yml & mem.yml & ai.yml<br>
　┣ー>CPー>cp.yml & buy.yml　　//自分でこのフォルダは作る<br>
　┗ー>LEVELー>level.yml & levelup.yml　　//自分でこのフォルダは作る<br><br>

※全ての機能を使わないとバグが出る恐れがあります。<br><br>

<a name="Lie"></a>
## Lie
**| 配布中 : Version 2.5 | (2016/8/24配布開始)**<br>
嘘をつきすぎると信用がなくなります（多分）<br>
導入の際は御気をつけ下さい<br>

＜嘘つきコマンド＞<br>

/inj <Name>　又は /ine <Name><br>
実際はいないけどJoinメッセージを出すことができます。<br>
injは日本語　ineは英語です<br><br>

/lej <Name>　又は /lee <Name><br>
実際は退出しないけどQuitメッセージを出すことができます。<br>
lejは日本語　leeは英語です<br><br>

/lc <Name> <Chat><br>
<Name>の人になりすまして<Chat>を送信します。<br><br>

/lop <Name><br>
<Name>の人に与えていないけどOPを与えたメッセージをおくります。<br><br>

追加（v2.5）<br>
/lg <Name><br>
<Name>の人はクリエにならないけどクリエになったメッセージと<br>
クリエ時に手にもたされる（自動的に）五種類のアイテムが渡されます。<br>

<a name="MakeHouse"></a>
## MakeHouse
**| 配布中 : Version 2.0 | (2016/7/16配布開始)**<br>
Configの設定<br><br>

免許の種類変更<br>
Name.ymlに以下の値がセットされています。<br>

Code:<br>
Name: 建築<br>
この建築の部分を作りたい種類にしてください。<br><br>

免許があるひとに特典を渡す(V2.0.0以降)<br>
Vip.ymlに以下の値がセットされています。<br><br>

※注意<br>
Code:<br>
特典の種類がコマンドの場合はスラッシュも含めて記入してください。<br>
という文章があると思いますが、無視でお願いします。<br><br>

Code:<br>
説明: 'このCONFIGでは免許保持者への特典を設定することができます。<br>特典の種類がコマンドの場合はスラッシュも含めて記入してください。<br>NULLというのは未設定と言う意味です。<br>アイテムの場合はNULLのところにID : Damege値 : 個数を記入してください。（例-> 1:0:64　は石を64個）<br>Damege値と個数がないとエラーが出ます。タイミングのOnceは免許取得時だけ特典を渡します。'<br>
特典の種類: アイテム or NULL<br>
特典のタイミング: Join or Once<br>
ゴールド免許: "0:0:0"<br>
シルバー免許: "0:0:0"<br>
ノーマル免許: "0:0:0"<br><br>

特典の種類について<br>
特典の種類はアイテムとNULLの二つあり、それは以下のような意味です。<br>
アイテム -> 特典付与時にアイテムを渡す。<br>
NULL -> 特典を渡さない。<br>
どちらかを選択してお書きください。<br><br>

特典のタイミングについて<br>
特典のタイミングはJoinとOnceの二つあり、それが以下のような意味です。<br>
Join -> サーバーに参加時、免許があれば特典を渡す。<br>
Once -> 免許取得時のみ、特典を渡す。<br>
どちらかを選択してお書きください。<br><br>

例）アイテム / Join / ゴールドは石64個 / シルバーは石32個 / ノーマルは何も渡さない<br><br>

Code:<br>
説明: 'このCONFIGでは免許保持者への特典を設定することができます。<br>特典の種類がコマンドの場合はスラッシュも含めて記入してください。<br>NULLというのは未設定と言う意味です。<br>アイテムの場合はNULLのところにID : Damege値 : 個数を記入してください。（例-> 1:0:64　は石を64個）<br>Damege値と個数がないとエラーが出ます。タイミングのOnceは免許取得時だけ特典を渡します。'<br>
特典の種類: アイテム<br>
特典のタイミング: Join<br>
ゴールド免許: "1:0:64"<br>
シルバー免許: "1:0:32"<br>
ノーマル免許: "0:0:0"<br><br>




Command<br><br>

ゴールド免許を付与（opのみ）<br>
/mgold <相手の名前><br><br>

シルバー免許を付与（opのみ）<br>
/msil <相手の名前><br><br>

ノーマル免許を付与（opのみ）<br>
/maker <相手の名前><br><br>

免許を失効させる（opのみ）<br>
/mdel <相手の名前><br><br>

免許を確認（全プレイヤーが可能）<br>
/mch <相手の名前><br><br>
