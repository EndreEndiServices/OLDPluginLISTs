<?php

namespace Board;
use pocketmine\utils\Config;
use pocketmine\event\Listener;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\Server;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\CommandExecutor;
class Main extends PluginBase implements Listener{
public function onEnable(){
if(!file_exists($this->getDataFolder())){
    mkdir($this->getDataFolder(), 0744, true);
}
$this->board = new Config($this->getDataFolder() . "Board.yml", Config::YAML);
$this->good = new Config($this->getDataFolder() . "Good.yml", Config::YAML);
$this->bad = new Config($this->getDataFolder() . "Bad.yml", Config::YAML);
$this->getLogger()->info("§c二次配布等は禁止です。　§b Created by R_Funa");
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }
    public function onCommand(CommandSender $sender, Command $command, $label, array $args){
     switch($command->getName()){
     	case "chat":
        if(isset($args[0])){
            if($this->board->exists(1)){
        $all = $this->board->getAll();
        $max = max(array_keys($all));
        $num = $max + 1;
        $this->board->set($num, "[".$sender->getName()."] ".$args[0]);
        $this->board->save();
        $this->good->set($num, 0);
        $this->good->save();
        $this->bad->set($num, 0);
        $this->bad->save();
    }else{
        $this->board->set(1, "[".$sender->getName()."] ".$args[0]);
        $this->board->save();
        $this->good->set(1, 0);
        $this->good->save();
        $this->bad->set(1, 0);
        $this->bad->save();
    }
        $this->getServer()->broadcastPopup("[ ".$sender->getName()." ] ".$args[0]."");
        $sender->sendMessage("§aSuccess : 投稿が完了しました。");
    }else{
        $sender->sendMessage("§cError : 内容が存在しません。");
    }
        return true;
        break;
     	case "good":
        if(isset($args[0])){
            if($this->board->exists($args[0])){
            $point = $this->good->get($args[0]);
            $po = (Int)$point + 1;
        $this->good->set($args[0], $po);
        $this->good->save();
    }else{
        $sender->sendMessage("§cError : 番号が存在しません。");
    }
    }else{
        $sender->sendMessage("§cError : 番号が確認できません。");
    }
     	return true;
        break;
        case "bad":
        if(isset($args[0])){
            if($this->board->exists($args[0])){
            $point = $this->bad->get($args[0]);
            $po = (Int)$point + 1;
        $this->bad->set($args[0], $po);
        $this->bad->save();
    }else{
        $sender->sendMessage("§cError : 番号が存在しません。");
    }
    }else{
        $sender->sendMessage("§cError : 番号が確認できません。");
    }
        return true;
        break;
        case "bl":
        $all = $this->board->getAll();
        $max = max(array_keys($all));
        for($i = 1; $i <= $max; $i++){
            $s = $this->board->get($i);
            $g = $this->good->get($i);
            $b = $this->bad->get($i);
            $sender->sendMessage("< §b".$i."§f >".$s." §eGOOD / ".$g."｜BAD / ".$b."");
        }
        return true;
        break;
     }
    }
}
