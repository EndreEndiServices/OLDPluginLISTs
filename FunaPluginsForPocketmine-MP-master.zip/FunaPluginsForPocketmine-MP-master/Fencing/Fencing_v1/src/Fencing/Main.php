<?php

namespace Fencing;

use pocketmine\Player;
use pocketmine\Plugin\PluginBase;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\utils\Config;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\CommandExecutor;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\scheduler\PluginTask;
use pocketmine\scheduler\CallbackTask;
use pocketmine\scheduler\Task;
use pocketmine\math\Vector3;
use pocketmine\event\player\PlayerToggleSneakEvent;

class Main extends PluginBase implements Listener{
  public $fencing = false;
  public function onEnable(){
    $this->getServer()->getPluginManager()->registerEvents($this,$this);
    if(!file_exists($this->getDataFolder())){
    mkdir($this->getDataFolder(), 0744, true);}
    $this->fe = new Config($this->getDataFolder() . "Fencing.yml", Config::YAML);
    $this->getLogger()->info("§bFencingが読み込まれました。§aby R_Funa");
    $this->getLogger()->info("§b二次配布・改造配布は禁止です。");
  }

  public function onCommand(CommandSender $sender, Command $command, $label, array $args){
    if(strtolower($command->getName()) == "fen"){
      if(!isset($args[0])) return false;
      switch($args[0]){
       case "mem":
       if(!isset($args[1])) return false;
       if(!isset($args[2])) return false;
       $mem1 = $this->getServer()->getPlayer($args[1]);
       $mem2 = $this->getServer()->getPlayer($args[2]);
       if($mem1 instanceof Player){
        if($mem2 instanceof Player){
       $this->mem1 = $mem1;
       $this->mem2 = $mem2;
       $sender->sendMessage("§6[Fencing]§b参加者をセットしました。");
     }else{
     $sender->sendMessage("§6[Fencing]§b存在しないプレイヤーが含まれています！");
   }
     }else{
      $sender->sendMessage("§6[Fencing]§b存在しないプレイヤーが含まれています！");
     }
       return true;
        break;
        case "start":
        $n1 = $this->mem1->getName();
        $n2 = $this->mem2->getName();
        $this->mem1->sendMessage("§6[Fencing]§b開始します。位置についてください。");
        $this->mem2->sendMessage("§6[Fencing]§b開始します。位置についてください。");
        $this->mem1->sendTitle("§aフェンシング開始");
         $this->mem2->sendTitle("§aフェンシング開始");
        $this->fencing = true;
        $this->getServer()->getScheduler()->scheduleDelayedTask(new CallbackTask([$this, 'Finish'], []), 20 * 180);
        return true;
        break;
        case "help":
       $sender->sendMessage("§6[Fencing]\n§b/fen mem§f : 参加者をセット\n§b/fen start§f : Fencing開始");
       return true;
        break;
        }
        }
    }
    public function Finish(){
      $this->getServer()->getScheduler()->cancelTasks($this);
      $this->mem1->sendMessage("§6[Fencing]§b終了してください。勝負は引き分けとなりました。");
      $this->mem2->sendMessage("§6[Fencing]§b終了してください。勝負は引き分けとなりました。");
      $this->fencing = false;
    }
    public function onEntityDamageByEntity(EntityDamageEvent $event){
        if($event instanceof EntityDamageByEntityEvent){
                $damager = $event->getDamager(); //殴った人                
                $player = $event->getEntity();//殴られた人
                $dn = $damager->getName();
                $pn = $player->getName();
                if($player instanceof Player and $damager instanceof Player){
                  if($this->fencing = true){
                    if(!$player->isSneaking()){
                      if(!$damager->isSneaking()){
                    $damager->sendMessage("§6[Fencing]§bあなたの勝利です！");
                    $player->sendMessage("§6[Fencing]§bあなたは敗北しました...");
                    $damager->sendMessage("§6[Fencing]§終了しました！");
                    $player->sendMessage("§6[Fencing]§b終了しました！");
                    $this->fencing = false;
                    $this->getServer()->getScheduler()->cancelTasks($this);
                  }
                }
                  }
                  }
            }
          }
}
