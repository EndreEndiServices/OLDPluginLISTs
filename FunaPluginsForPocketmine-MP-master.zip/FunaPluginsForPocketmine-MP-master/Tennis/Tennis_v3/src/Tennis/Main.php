<?php

namespace Tennis;

use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\Server;
use pocketmine\utils\Config;
use pocketmine\event\Listener;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\CommandExecutor;
use pocketmine\block\Block;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\block\BlockBreakEvent;

class Main extends PluginBase implements Listener{

	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		if(!file_exists($this->getDataFolder())){
    mkdir($this->getDataFolder(), 0744, true);}
    unlink($this->getDataFolder() . "tennis.yml");
    $this->t = new Config($this->getDataFolder() . "tennis.yml", Config::YAML);
    $this->p = new Config($this->getDataFolder() . "point.yml", Config::YAML);
    $this->r = new Config($this->getDataFolder() . "racket.yml", Config::YAML);
  }
   public function onCommand(CommandSender $sender, Command $command, $label, array $args){
	switch (strtolower($command->getName())){
		case "s":
		if(isset($args[0])){$sender->sendMessage("自分のプレイヤー名をセット"); break;}
		if(isset($args[1])){$sender->sendMessage("相手のプレイヤー名をセット"); break;}
		$this->t->set($args[0], $args[1]);
		$this->t->save();
		$this->t->set($args[1], $args[0]);
		$this->t->save();
		$this->p->set($args[0], "0");
		$this->p->save();
		$this->p->set($args[1], "0");
		$this->p->save();
		$this->getServer()->broadcastTip("§a".$args[0]."§fvs§b".$args[1]."");
		break;

		case "f":
		unlink($this->getDataFolder() . "tennis.yml");
		unlink($this->getDataFolder() . "point.yml");
		break;

		case "r":
		$rank = $this->r->get($sender->getName());
		if($rank == "超速ラケット"){
			$this->r->set($sender->getName(), "軽量ラケット");//スライス
			$this->r->save();
			$sender->sendMessage("§a[Tennia]§f軽量ラケットになった！");
		}elseif($rank == "軽量ラケット"){
			$this->r->set($sender->getName(), "スタンダードラケット");//直球
			$this->r->save();
			$sender->sendMessage("§a[Tennia]§fスタンダードラケットになった！");
		}elseif($rank == "スタンダードラケット"){
			$this->r->set($sender->getName(), "ハイラケット");//ロブ
			$this->r->save();
			$sender->sendMessage("§a[Tennia]§fハイラケットになった！");
		}elseif($rank == "ハイラケット"){
			$this->r->set($sender->getName(), "重量ラケット");//ドロップショット
			$this->r->save();
			$sender->sendMessage("§a[Tennia]§f重量ラケットになった！");
		}elseif($rank == "重量ラケット"){
			$this->r->set($sender->getName(), "超速ラケット");//ドロップショット
			$this->r->save();
			$sender->sendMessage("§a[Tennia]§f超速ラケットになった！");
		}

		break;
}
}
  public function onJoin(PlayerJoinEvent $e){
  	$p = $e->getPlayer();
  	$n = $p->getName();
  	if(!$this->r->exists($n)){
  		$this->r->set($n, "軽量ラケット");//スライス
		$this->r->save();
  	}
  }
  public function onTouch(PlayerInteractEvent $e){
		$p = $e->getPlayer();
	    $block = $e->getBlock();
	    $id = $block->getId();
	    $ip = $p->getAddress();
	    if($this->t->exists($p->getName())){
	    if($id == 170){//穀物の集め
	    	$sp = mt_rand(100,300);
	    	$this->getServer()->broadcastTip("§a[Tennis]§f".$sp."km/hのサーブが打たれました！\nby ".$p->getName()."");
	    	$this->t->set("サーブ", $sp);
	    	$this->t->save();
	    	$this->t->set("時間", time());
	    	$this->t->save();
	    	$this->t->set($p->getAddress(), "サーブ");
	    	$this->t->save();
	    	$this->t->set("打った人", $p->getName());
	    	$this->t->save();

	    }
	}
	    if($this->t->exists("サーブ")){
	    if($id == 41){//金ブロック
	    	$t = mt_rand(1,6);
	    	if($t = 2){
	    	$ranka = $this->r->get($p->getName());
	    	$p = $e->getPlayer();
	    	if($this->t->get("打った人") == $p->getName()){
	$p->sendMessage("§a[Tennis]§f空振った");
	}else{
	    	if($this->t->exists($p->getName())){
	    	$t = time();
	    	$b = $this->t->get("時間");
	    	$ti = intval($b);
	    	$ss = $this->t->get("サーブ");
	    	$s = intval($ss);
	    	$a = $this->t->get($p->getName());
	    	$pa = $this->getServer()->getPlayer($a);
	    	$ip = $pa->getAddress();
	    	$ae = $t - $ti;
	    	$bb = $ae * $s;
	    		    		if($bb < 900){
	    		if($this->t->get($ip) == "スライス"){
	    		$ri = mt_rand(200,600);
	    		$this->getServer()->broadcastTip("§a[Tennis]§f".$ri."km/hのフラットが打たれました！\nby ".$p->getName()."\n相性により2倍!");
	    	$this->t->set("サーブ", $ri);
	    	$this->t->save();
	    	$this->t->set("時間", time());
	    	$this->t->save();
	    	$this->t->set($p->getAddress(), "フラット");
	    	$this->t->save();
	    	$this->t->set("打った人", $p->getName());
	    	$this->t->save();
	    }elseif($this->t->get($ip) == "ロブ"){
	    	$riik = mt_rand(100,150);
	    		$this->getServer()->broadcastTip("§a[Tennis]§f".$riik."km/hのフラットが打たれました！\nby ".$p->getName()."\n相性により1/2!");
	    	$this->t->set("サーブ", $riik);
	    	$this->t->save();
	    	$this->t->set("時間", time());
	    	$this->t->save();
	    	$this->t->set($p->getAddress(), "フラット");
	    	$this->t->save();
	    	$this->t->set("打った人", $p->getName());
	    	$this->t->save();
	    }elseif($this->t->get($ip) == "ドロップショット"){
	    	$riikas = mt_rand(400,500);
	    		$this->getServer()->broadcastTip("§a[Tennis]§f".$riikas."km/hのフラットが打たれました！\nby ".$p->getName()."\n相性により1/2!");
	    	$this->t->set("サーブ", $riikas);
	    	$this->t->save();
	    	$this->t->set("時間", time());
	    	$this->t->save();
	    	$this->t->set($p->getAddress(), "フラット");
	    	$this->t->save();
	    	$this->t->set("打った人", $p->getName());
	    	$this->t->save();
	    }elseif($ranka == "超速ラケット"){
	    	$riik1 = mt_rand(300,400);
	    	$this->getServer()->broadcastTip("§a[Tennis]§f".$riik1."km/hのフラットが打たれました！\nby ".$p->getName()."");
	    	$this->t->set("サーブ", $riik1);
	    	$this->t->save();
	    	$this->t->set("時間", time());
	    	$this->t->save();
	    	$this->t->set($p->getAddress(), "フラット");
	    	$this->t->save();
	    	$this->t->set("打った人", $p->getName());
	    	$this->t->save();
	    }elseif($ranka == "ニューイヤーラケット"){
	    	$riik1 = mt_rand(300,400);
	    	$this->getServer()->broadcastTip("§a[Tennis]§f".$riik1."km/hのフラットが打たれました！\nby ".$p->getName()."");
	    	$this->t->set("サーブ", $riik1);
	    	$this->t->save();
	    	$this->t->set("時間", time());
	    	$this->t->save();
	    	$this->t->set($p->getAddress(), "フラット");
	    	$this->t->save();
	    	$this->t->set("打った人", $p->getName());
	    	$this->t->save();
	    	}else{
	    	$spp = mt_rand(200,300);
	    	$this->getServer()->broadcastTip("§a[Tennis]§f".$spp."km/hのフラットが打たれました！\nby ".$p->getName()."");
	    	$this->t->set("サーブ", $spp);
	    	$this->t->save();
	    	$this->t->set("時間", $t);
	    	$this->t->save();
	    	$this->t->set($p->getAddress(), "フラット");
	    	$this->t->save();
	    	$this->t->set("打った人", $p->getName());
	    	$this->t->save();
	    }
	    }else{
	    	$this->getServer()->broadcastTip("§a[Tennis]§f打ち返せなかった！\nby ".$p->getName()."");
	    	$this->getServer()->broadcastMessage("§a[Tennis]§f打ち返せなかった！\nby ".$p->getName()."");
	    	$this->t->remove("サーブ");
	    	$this->t->save();
	    	$o = $this->t->get($p->getName());
	    	$oo = $this->p->get($o);
	    	$ooooo = $this->p->get($p->getName());
	    	$ooo = intval($oo);
	    	$oooo = $ooo + 1;
	    	$this->p->set($o, $oooo);
	    	$this->p->save();
	    	$this->getServer()->broadcastMessage("§a[Tennis]§f".$p->getName()."/".$ooooo." VS ".$o."/".$oo."");
	    }
	}
}
	    }}
	    elseif($id == 42){//鉄ブロック
	    	$rankb = $this->r->get($p->getName());
	    	$t = mt_rand(1,6);
	    	if($t = 2){
	    	if($this->t->get("打った人") == $p->getName()){
	    		$p->sendMessage("§a[Tennis]§f空振った");
	}else{
	    	if($this->t->exists($p->getName())){
	    	$te = time();
	    	$tr = $this->t->get("時間");
	    	$tii = intval($tr);
	    	$pp = $this->t->get("サーブ");
	    	$w = intval($pp);
	    	$dry = $this->t->get($p->getName());
	    	$drive = $this->getServer()->getPlayer($dry);
	    	$tt = $te - $tii;
	    	$ff = $tt * $w;
	    	$ipp = $drive->getAddress();
	    		if($ff < 1500){
	    	if($this->t->get($ipp) == "直球"){
	    		$rii = mt_rand(50,100);
	    		$this->getServer()->broadcastTip("§a[Tennis]§f".$rii."km/hのスライスが打たれました！\nby ".$p->getName()."\n相性により1/2!");
	    	$this->t->set("サーブ", $rii);
	    	$this->t->save();
	    	$this->t->set("時間", time());
	    	$this->t->save();
	    	$this->t->set($p->getAddress(), "スライス");
	    	$this->t->save();
	    	$this->t->set("打った人", $p->getName());
	    	$this->t->save();
	    	}elseif($this->t->get($ip) == "ロブ"){
	    	$riikk = mt_rand(200,400);
	    		$this->getServer()->broadcastTip("§a[Tennis]§f".$riikk."km/hのスライスが打たれました！\nby ".$p->getName()."\n相性により2倍!");
	    	$this->t->set("サーブ", $riikk);
	    	$this->t->save();
	    	$this->t->set("時間", time());
	    	$this->t->save();
	    	$this->t->set($p->getAddress(), "スライス");
	    	$this->t->save();
	    	$this->t->set("打った人", $p->getName());
	    	$this->t->save();
	    }elseif($this->t->get($ip) == "ドロップショット"){
	    	$riikk = mt_rand(300,400);
	    		$this->getServer()->broadcastTip("§a[Tennis]§f".$riikk."km/hのスライスが打たれました！\nby ".$p->getName()."\n相性により2倍!");
	    	$this->t->set("サーブ", $riikk);
	    	$this->t->save();
	    	$this->t->set("時間", time());
	    	$this->t->save();
	    	$this->t->set($p->getAddress(), "スライス");
	    	$this->t->save();
	    	$this->t->set("打った人", $p->getName());
	    	$this->t->save();
	    }elseif($rankb == "軽量ラケット"){
	    	$riik2 = mt_rand(200,300);
	    	$this->getServer()->broadcastTip("§a[Tennis]§f".$riik2."km/hのスライスが打たれました！\nby ".$p->getName()."");
	    	$this->t->set("サーブ", $riik2);
	    	$this->t->save();
	    	$this->t->set("時間", time());
	    	$this->t->save();
	    	$this->t->set($p->getAddress(), "スライス");
	    	$this->t->save();
	    	$this->t->set("打った人", $p->getName());
	    	$this->t->save();
	    }elseif($rankb == "ニューイヤーラケット"){
	    	$riik2 = mt_rand(200,300);
	    	$this->getServer()->broadcastTip("§a[Tennis]§f".$riik2."km/hのスライスが打たれました！\nby ".$p->getName()."");
	    	$this->t->set("サーブ", $riik2);
	    	$this->t->save();
	    	$this->t->set("時間", time());
	    	$this->t->save();
	    	$this->t->set($p->getAddress(), "スライス");
	    	$this->t->save();
	    	$this->t->set("打った人", $p->getName());
	    	$this->t->save();
	    	}else{
	    	$sppp = mt_rand(100,200);
	    	$this->getServer()->broadcastTip("§a[Tennis]§f".$sppp."km/hのスライスが打たれました！\nby ".$p->getName()."");
	    	$this->t->set("サーブ", $sppp);
	    	$this->t->save();
	    	$this->t->set("時間", time());
	    	$this->t->save();
	    	$this->t->set($p->getAddress(), "スライス");
	    	$this->t->save();
	    	$this->t->set("打った人", $p->getName());
	    	$this->t->save();
	    }
	    }else{
	    	$this->getServer()->broadcastTip("§a[Tennis]§f打ち返せなかった！\nby ".$p->getName()."");
	    	$this->getServer()->broadcastMessage("§a[Tennis]§f打ち返せなかった！\nby ".$p->getName()."");
	    	$this->t->remove("サーブ");
	    	$this->t->save();
	    	$yi = $this->t->get($p->getName());
	    	$ya = $this->p->get($yi);
	    	$ye = $this->p->get($p->getName());
	    	$yo = intval($ya);
	    	$yu = $yo + 1;
	    	$this->p->set($yi, $yu);
	    	$this->p->save();
	    	$this->getServer()->broadcastMessage("§a[Tennis]§f".$p->getName()."/".$ye." VS ".$yi."/".$ya."");
	    }
	}
}
	    }
	}
	    elseif($id == 57){//ダイヤブロック
	    	$t = mt_rand(1,6);
	    	if($t = 2){
	    	$rankc = $this->r->get($p->getName());
	    	if($this->t->get("打った人") == $p->getName()){
	    		$p->sendMessage("§a[Tennis]§f空振った");
	}else{
	    	if($this->t->exists($p->getName())){
	    	$funa = time();
	    	$funyat = $this->t->get("時間");
	    	$do = intval($funyat);
	    	$it = $this->t->get("サーブ");
	    	$p = $e->getPlayer();
	    	$high = intval($it);
	    	$en = $funa - $do;
	    	$play = $en * $high;
	    		if($play < 2000){
	    	if($this->t->get($p->getAddress()) == "スライス"){
	    		$r = mt_rand(200,600);
	    		$this->getServer()->broadcastTip("§a[Tennis]§f".$r."km/hの直球が打たれました！\nby ".$p->getName()."\n相性により2倍!");
	    	$this->t->set("サーブ", $r);
	    	$this->t->save();
	    	$this->t->set("時間", time());
	    	$this->t->save();
	    	$this->t->set($p->getAddress(), "直球");
	    	$this->t->save();
	    	$this->t->set("打った人", $p->getName());
	    	$this->t->save();
	    }elseif($this->t->get($ip) == "直球"){
	    	$riike = mt_rand(200,500);
	    		$this->getServer()->broadcastTip("§a[Tennis]§f".$riike."km/hの直球が打たれました！\nby ".$p->getName()."\n相性により約2倍!");
	    	$this->t->set("サーブ", $riike);
	    	$this->t->save();
	    	$this->t->set("時間", time());
	    	$this->t->save();
	    	$this->t->set($p->getAddress(), "直球");
	    	$this->t->save();
	    	$this->t->set("打った人", $p->getName());
	    	$this->t->save();
	    	}elseif($this->t->get($ip) == "ドロップショット"){
	    	$riike = mt_rand(300,400);
	    		$this->getServer()->broadcastTip("§a[Tennis]§f".$riike."km/hの直球が打たれました！\nby ".$p->getName()."\n相性により約2倍!");
	    	$this->t->set("サーブ", $riike);
	    	$this->t->save();
	    	$this->t->set("時間", time());
	    	$this->t->save();
	    	$this->t->set($p->getAddress(), "直球");
	    	$this->t->save();
	    	$this->t->set("打った人", $p->getName());
	    	$this->t->save();
	    	}elseif($rankc == "ニューイヤーラケット"){
	    	$riik3 = mt_rand(200,400);
	    	$this->getServer()->broadcastTip("§a[Tennis]§f".$riik3."km/hの直球が打たれました！\nby ".$p->getName()."");
	    	$this->t->set("サーブ", $riik3);
	    	$this->t->save();
	    	$this->t->set("時間", time());
	    	$this->t->save();
	    	$this->t->set($p->getAddress(), "直球");
	    	$this->t->save();
	    	$this->t->set("打った人", $p->getName());
	    	$this->t->save();
	    	}else{
	    	$spppp = mt_rand(100,300);
	    	$this->getServer()->broadcastTip("§a[Tennis]§f".$spppp."km/hの直球が打たれました！\nby ".$p->getName()."");
	    	$this->t->set("サーブ", $spppp);
	    	$this->t->save();
	    	$this->t->set("時間", time());
	    	$this->t->save();
	    	$this->t->set($p->getAddress(), "直球");
	    	$this->t->save();
	    	$this->t->set("打った人", $p->getName());
	    	$this->t->save();
	    }
	    }else{
	    	$this->getServer()->broadcastTip("§a[Tennis]§f打ち返せなかった！\nby ".$p->getName()."");
	    	$this->getServer()->broadcastMessage("§a[Tennis]§f打ち返せなかった！\nby ".$p->getName()."");
	    	$this->t->remove("サーブ");
	    	$this->t->save();
	    	$s = $this->t->get($p->getName());
	    	$ss = $this->p->get($s);
	    	$sssss = $this->p->get($p->getName());
	    	$sss = intval($ss);
	    	$ssss = $sss + 1;
	    	$this->p->set($s, $ssss);
	    	$this->p->save();
	    	$this->getServer()->broadcastMessage("§a[Tennis]§f".$p->getName()."/".$sssss." VS ".$s."/".$ss."");
	    }
	}
}
	    }}elseif($id == 173){//石炭ブロック
	    	$rankd = $this->r->get($p->getName());
	    	$t = mt_rand(1,6);
	    	if($t = 2){
	    	if($this->t->get("打った人") == $p->getName()){
	    		$p->sendMessage("§a[Tennis]§f空振った");
	}else{
	    	if($this->t->exists($p->getName())){
	    		$tenn = time();
	    	$funya = $this->t->get("時間");
	    	$did = intval($funya);
	    	$iit = $this->t->get("サーブ");
	    	$p = $e->getPlayer();
	    	$hig = intval($iit);
	    	$eon = $tenn - $did;
	    	$player = $eon * $hig;
	    		    		if($player < 900){
	    	if($this->t->get($p->getAddress()) == "直球"){
	    		$rrr = mt_rand(100,150);
	    		$this->getServer()->broadcastTip("§a[Tennis]§f".$rrr."km/hのロブが打たれました！\nby ".$p->getName()."\n相性により2倍!");
	    	$this->t->set("サーブ", $rrr);
	    	$this->t->save();
	    	$this->t->set("時間", $tenn);
	    	$this->t->save();
	    	$this->t->set($p->getAddress(), "ロブ");
	    	$this->t->save();
	    	$this->t->set("打った人", $p->getName());
	    	$this->t->save();
	    }elseif($this->t->get($ip) == "ドロップショット"){
	    	$riikl = mt_rand(800,1000);
	    		$this->getServer()->broadcastTip("§a[Tennis]§f".$riikl."km/hのロブが打たれました！\nby ".$p->getName()."\n相性により1/2!");
	    	$this->t->set("サーブ", $riikl);
	    	$this->t->save();
	    	$this->t->set("時間", time());
	    	$this->t->save();
	    	$this->t->set($p->getAddress(), "ロブ");
	    	$this->t->save();
	    	$this->t->set("打った人", $p->getName());
	    	$this->t->save();
	    }elseif($this->t->get($ip) == "スマッシュ"){
	    	$riikll = mt_rand(600,700);
	    		$this->getServer()->broadcastTip("§a[Tennis]§f".$riikll."km/hのロブが打たれました！\nby ".$p->getName()."\n相性により1/2!");
	    	$this->t->set("サーブ", $riikll);
	    	$this->t->save();
	    	$this->t->set("時間", time());
	    	$this->t->save();
	    	$this->t->set($p->getAddress(), "ロブ");
	    	$this->t->save();
	    	$this->t->set("打った人", $p->getName());
	    	$this->t->save();
	    }elseif($this->t->get($ip) == "サーブ"){
	    	$riiklll = mt_rand(400,500);
	    		$this->getServer()->broadcastTip("§a[Tennis]§f".$riiklll."km/hのロブが打たれました！\nby ".$p->getName()."\n相性により2倍!");
	    	$this->t->set("サーブ", $riikll);
	    	$this->t->save();
	    	$this->t->set("時間", time());
	    	$this->t->save();
	    	$this->t->set($p->getAddress(), "ロブ");
	    	$this->t->save();
	    	$this->t->set("打った人", $p->getName());
	    	$this->t->save();
	    }elseif($rankd == "ハイラケット"){
	    	$riik4 = mt_rand(150,175);
	    	$this->getServer()->broadcastTip("§a[Tennis]§f".$riik4."km/hのフラットが打たれました！\nby ".$p->getName()."\n相性により1/2!");
	    	$this->t->set("サーブ", $riik4);
	    	$this->t->save();
	    	$this->t->set("時間", time());
	    	$this->t->save();
	    	$this->t->set($p->getAddress(), "ロブ");
	    	$this->t->save();
	    	$this->t->set("打った人", $p->getName());
	    	$this->t->save();
	    	}else{
	    	$sppppp = mt_rand(50,75);
	    	$this->getServer()->broadcastTip("§a[Tennis]§f".$sppppp."km/hのロブが打たれました！\nby ".$p->getName()."");
	    	$this->t->set("サーブ", $sppppp);
	    	$this->t->save();
	    	$this->t->set("時間", $tenn);
	    	$this->t->save();
	    	$this->t->set($p->getAddress(), "ロブ");
	    	$this->t->save();
	    	$this->t->set("打った人", $p->getName());
	    	$this->t->save();
	    }
	    }else{
	    	$this->getServer()->broadcastTip("§a[Tennis]§f打ち返せなかった！\nby ".$p->getName()."");
	    	$this->getServer()->broadcastMessage("§a[Tennis]§f打ち返せなかった！\nby ".$p->getName()."");
	    	$this->t->remove("サーブ");
	    	$this->t->save();
	    	$c = $this->t->get($p->getName());
	    	$cc = $this->p->get($c);
	    	$ccccc = $this->p->get($p->getName());
	    	$ccc = intval($cc);
	    	$cccc = $ccc + 1;
	    	$this->p->set($c, $cccc);
	    	$this->p->save();
	    	$this->getServer()->broadcastMessage("§a[Tennis]§f".$p->getName()."/".$ccccc." VS ".$c."/".$cc."");
	    }
	    	}
	    }
	    }}elseif($id == 133){//エメラルドブロック
	    	$ranke = $this->r->get($p->getName());
	    	$t = mt_rand(1,6);
	    	if($t = 2){
	    	if($this->t->get("打った人") == $p->getName()){
	    		$p->sendMessage("§a[Tennis]§f空振った");
	}else{
	    	if($this->t->exists($p->getName())){
	    		$tennn = time();
	    	$funy = $this->t->get("時間");
	    	$done = intval($funy);
	    	$iiti = $this->t->get("サーブ");
	    	$p = $e->getPlayer();
	    	$higg = intval($iiti);
	    	$eono = $tennn - $done;
	    	$playero = $eono * $higg;
	    		if($playero < 700){
	    	if($this->t->get($p->getAddress()) == "直球"){
	    		$rrrr = mt_rand(400,500);
	    		$rrrrr = $rrrr/10;
	    		$this->getServer()->broadcastTip("§a[Tennis]§f".$rrrrr."km/hのドロップショットが打たれました！\nby ".$p->getName()."\n相性により2倍!");
	    	$this->t->set("サーブ", $rrrr);
	    	$this->t->save();
	    	$this->t->set("時間", $tennn);
	    	$this->t->save();
	    	$this->t->set($p->getAddress(), "ドロップショット");
	    	$this->t->save();
	    	$this->t->set("打った人", $p->getName());
	    	$this->t->save();
	    	}elseif($this->t->get($ip) == "ロブ"){
	    	$riikf = mt_rand(10,15);
	    		$this->getServer()->broadcastTip("§a[Tennis]§f".$riikf."km/hのドロップショットが打たれました！\nby ".$p->getName()."\n相性により1/2!");
	    	$this->t->set("サーブ", $riikf);
	    	$this->t->save();
	    	$this->t->set("時間", time());
	    	$this->t->save();
	    	$this->t->set($p->getAddress(), "ドロップショット");
	    	$this->t->save();
	    	$this->t->set("打った人", $p->getName());
	    	$this->t->save();
	    }elseif($this->t->get($ip) == "サーブ"){
	    	$riikff = mt_rand(10,15);
	    		$this->getServer()->broadcastTip("§a[Tennis]§f".$riikff."km/hのドロップショットが打たれました！\nby ".$p->getName()."\n相性により1/2!");
	    	$this->t->set("サーブ", $riikff);
	    	$this->t->save();
	    	$this->t->set("時間", time());
	    	$this->t->save();
	    	$this->t->set($p->getAddress(), "ドロップショット");
	    	$this->t->save();
	    	$this->t->set("打った人", $p->getName());
	    	$this->t->save();
	    }elseif($ranke == "重量ラケット"){
	    	if(!$this->t->get($ip) == "サーブ"){
	    	$riik5 = mt_rand(400,500);
	    	$this->getServer()->broadcastTip("§a[Tennis]§f".$riik5."km/hのフラットが打たれました！\nby ".$p->getName()."");
	    	$this->t->set("サーブ", $riik5);
	    	$this->t->save();
	    	$this->t->set("時間", time());
	    	$this->t->save();
	    	$this->t->set($p->getAddress(), "ドロップショット");
	    	$this->t->save();
	    	$this->t->set("打った人", $p->getName());
	    	$this->t->save();
	    }else{
	    	$riik45 = mt_rand(100,200);
	    	$this->getServer()->broadcastTip("§a[Tennis]§f".$riik5."km/hのフラットが打たれました！\nby ".$p->getName()."\n相性により1/2!");
	    	$this->t->set("サーブ", $riik5);
	    	$this->t->save();
	    	$this->t->set("時間", time());
	    	$this->t->save();
	    	$this->t->set($p->getAddress(), "ドロップショット");
	    	$this->t->save();
	    	$this->t->set("打った人", $p->getName());
	    	$this->t->save();
	    }
	    	}else{
	    	$spppppppp = mt_rand(300,400);
	    	$sppppppp = $spppppppp/10;
	    	$this->getServer()->broadcastTip("§a[Tennis]§f".$sppppppp."km/hのドロップショットが打たれました！\nby ".$p->getName()."");
	    	$this->t->set("サーブ", $sppppppp);
	    	$this->t->save();
	    	$this->t->set("時間", $tennn);
	    	$this->t->save();
	    	$this->t->set($p->getAddress(), "ドロップショット");
	    	$this->t->save();
	    	$this->t->set("打った人", $p->getName());
	    	$this->t->save();
	    }
	    }else{
	    	$this->getServer()->broadcastTip("§a[Tennis]§f打ち返せなかった！\nby ".$p->getName()."");
	    	$this->getServer()->broadcastMessage("§a[Tennis]§f打ち返せなかった！\nby ".$p->getName()."");
	    	$this->t->remove("サーブ");
	    	$this->t->save();
	    	$f = $this->t->get($p->getName());
	    	$ff = $this->p->get($f);
	    	$fffff = $this->p->get($p->getName());
	    	$fff = intval($ff);
	    	$ffff = $fff + 1;
	    	$this->p->set($f, $ffff);
	    	$this->p->save();
	    	$this->point->plusPoint($f, 10);
	    	$this->getServer()->broadcastMessage("§a[Tennis]§f".$p->getName()."/".$fffff." VS ".$f."/".$ff."");
	    }
	    	}
	    }
	}
	}
}
	}
	public function onBreak(BlockBreakEvent $e){
		if($this->t->exists("サーブ")){
		$p = $e->getPlayer();
		$n = $p->getName();
		$b = $e->getBlock();
		$id = $b->getID();
		if($this->t->exists($n)){
		if($id == 49){
		$this->getServer()->broadcastMessage("§a[Tennis]§f".$n."のスマッシュ！");
		$speed = mt_rand(800,1000);
		$this->t->set("サーブ", $speed);
	    	$this->t->save();
	    	$this->getServer()->broadcastTip("§a[Tennis]§f".$speed."km/hのスマッシュが打たれました！\nby ".$p->getName()."");
	    	$this->t->set($p->getAddress(), "スマッシュ");
	    	$this->t->save();
	    	$this->t->set("打った人", $p->getName());
	    	$this->t->save();
	    }
	    }
	    }
	}
}
