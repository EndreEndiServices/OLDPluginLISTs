<?php

namespace Makehouse;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\item\Item;
use pocketmine\event\player\PlayerCommandPreprocessEvent;

class Main extends PluginBase implements Listener{

	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this,$this);
		if(!file_exists($this->getDataFolder())) mkdir($this->getDataFolder());
		$this->maker = new Config($this->getDataFolder().'Maker.yml', Config::YAML);
		$this->name = new Config($this->getDataFolder().'Name.yml', Config::YAML);
		if(!$this->name->exists("Name")){
		$this->name->set("Name", "建築");
		$this->name->save();
	}
	$this->vip = new Config($this->getDataFolder().'Vip.yml', Config::YAML, array(
'説明' => 'このCONFIGでは免許保持者への特典を設定することができます。特典の種類がコマンドの場合はスラッシュも含めて記入してください。NULLというのは未設定と言う意味です。アイテムの場合はNULLのところにID : Damege値 : 個数を記入してください。（例-> 1:0:64　は石を64個）Damege値と個数がないとエラーが出ます。タイミングのOnceは免許取得時だけ特典を渡します。',
'特典の種類' => 'アイテム or NULL',
'特典のタイミング' => 'Join or Once',
'ゴールド免許' => "0:0:0",
'シルバー免許' => "0:0:0",
'ノーマル免許' => "0:0:0"
));
}
	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
		$p = $this->getServer()->getPlayer($args[0]);
		switch (strtolower($command->getName())) {
			case 'mgold':
			 if(!isset($args[0])){
			 	$sender->sendMessage("".$this->Message1()."免許を与える相手が指定されていません！");
			 	return true;
			 	break;
			 }
			 $this->maker->set($args[0], "ゴールド免許");
			 $this->maker->save();
			 $this->getServer()->broadcastMessage("".$this->Message1()." §e".$args[0]." §bがゴールド免許を取得");
			 if($this->VipCheck() == 2){
			 	$p = $this->getServer()->getPlayer($args[0]);
			 	$id = $this->VipGiveId("ゴールド免許");
			 	$d = $this->VipGiveDamege("ゴールド免許");
			 	$how = $this->VipGiveHow("ゴールド免許");
			 	$item = Item::get($id, $d, $how);
			 	$p->getInventory()->addItem($item);
			 }
			 return true;
			break;

			case 'msil':
			 if(!isset($args[0])){
			 	$sender->sendMessage("".$this->Message1()."免許を与える相手が指定されていません！");
			 	return true;
			 	break;
			 }
			 $this->maker->set($args[0], "シルバー免許");
			 $this->maker->save();
			 $this->getServer()->broadcastMessage("".$this->Message1()." §e".$args[0]." §bがシルバー免許を取得");
			 if($this->VipCheck() == 2){
			 	$p = $this->getServer()->getPlayer($args[0]);
			 	$id = $this->VipGiveId("シルバー免許");
			 	$d = $this->VipGiveDamege("シルバー免許");
			 	$how = $this->VipGiveHow("シルバー免許");
			 	$item = Item::get($id, $d, $how);
			 	$p->getInventory()->addItem($item);
			 }
			 return true;
			break;

			case 'maker':
			  if(!isset($args[0])){
			 	$sender->sendMessage("".$this->Message1()."免許を与える相手が指定されていません！");
			 	return true;
			 	break;
			 }
			 $this->maker->set($args[0], "ノーマル免許");
			 $this->maker->save();
			 $this->getServer()->broadcastMessage("".$this->Message1()." §e".$args[0]." §bがノーマル免許を取得");
			 if($this->VipCheck() == 2){
			 	$p = $this->getServer()->getPlayer($args[0]);
			 	$id = $this->VipGiveId("ノーマル免許");
			 	$d = $this->VipGiveDamege("ノーマル免許");
			 	$how = $this->VipGiveHow("ノーマル免許");
			 	$item = Item::get($id, $d, $how);
			 	$p->getInventory()->addItem($item);
			 }
			 return true;
			break;

			case 'mdel':
			 if(!isset($args[0])){
			 	$sender->sendMessage("".$this->Message1()."免許を失効させる相手が指定されていません！");
			 	return true;
			 	break;
			 }
			 $this->maker->remove($args[0]);
			 $this->maker->save();
			 $this->getServer()->broadcastMessage("".$this->Message1()." §e".$args[0]." §bが免許を失効");
			 return true;
			break;

			case 'mch':
			 if(!isset($args[0])){
			 	$sender->sendMessage("".$this->Message1()."免許を確認する相手が指定されていません！");
			 	return true;
			 	break;
			 }
			 $player = $this->getServer()->getPlayer($sender->getName());
			 	if($this->maker->exists($args[0])){
			 		$sender->sendMessage("§a[".$this->Message1()."§bそのプレイヤーは§e".$this->Check($args[0])."§bを持っています");
			 	}else{
			 		$sender->sendMessage("§a[".$this->Message1()."§bそのプレイヤーは免許を持っていません");
			}

			 return true;
			break;

		}

	}

    public function onJoin(PlayerJoinEvent $event){
    	$p = $event->getPlayer();
		$username = $p->getName();
		if($this->maker->exists($username)){
			$this->getServer()->broadcastMessage("§a[".$this->Message1()."§d".$this->maker->get($username)."§b取得者がJOIN");
			if($this->VipCheck() == 1){
			 	$id = $this->VipGiveId($this->maker->get($username));
			 	$d = $this->VipGiveDamege($this->maker->get($username));
			 	$how = $this->VipGiveHow($this->maker->get($username));
			 	$item = Item::get($id, $d, $how);
			 	$p->getInventory()->addItem($item);
			 }
		}
	}
	private function Message1(){
		return "§a[".$this->name->get("Name")."免許]§b";
	}
	private function Check($name){
		return $this->maker->get($name);
	}
	private function VipCheck(){
		/*
		1 : アイテム & Join
		2 : アイテム & Once
		3 : コマンド
		4 ; NULL
		*/
		if($this->vip->get("特典の種類") == "アイテム"){
			if($this->vip->get("特典のタイミング") == "Join"){
				return 1;
			}elseif($this->vip->get("特典のタイミング") == "Once"){
				return 2;
			}else{
				return 3;
			}
		}else{
			return 3;
		}
	}
	private function VipGiveId($menkyoname){
		if($this->vip->exists($menkyoname)){
		if($this->VipCheck() == 1){
			$menkyo = $this->vip->get($menkyoname);
			$m = explode(":", $menkyo);
			return (Int)$m[0];
		}
		elseif($this->VipCheck() == 2){
			$menkyo = $this->vip->get($menkyoname);
			$m = explode(":", $menkyo);
			return (Int)$m[0];
		}
	}else{
		return 0;
	}
	}
	private function VipGiveDamege($menkyoname){
		if($this->vip->exists($menkyoname)){
		if($this->VipCheck() == 1){
			$menkyo = $this->vip->get($menkyoname);
			$m = explode(":", $menkyo);
			return (Int)$m[1];
		}
		elseif($this->VipCheck() == 2){
			$menkyo = $this->vip->get($menkyoname);
			$m = explode(":", $menkyo);
			return (Int)$m[1];
		}
	}else{
		return 0;
	}
	}
	private function VipGiveHow($menkyoname){
		if($this->vip->exists($menkyoname)){
		if($this->VipCheck() == 1){
			$menkyo = $this->vip->get($menkyoname);
			$m = explode(":", $menkyo);
			return (Int)$m[2];
		}
		elseif($this->VipCheck() == 2){
			$menkyo = $this->vip->get($menkyoname);
			$m = explode(":", $menkyo);
			return (Int)$m[2];
		}
	}else{
		return 0;
	}
	}
	}
