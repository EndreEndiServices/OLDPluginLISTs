# CRcore

Features:
* TPS player to spawn on death.
* Title by Nick

Forkable for anyone ;D and useable for anyone
EXCEPT PEOPLE ASSOSSCIATED WITH ROLEPLEXPE
H
