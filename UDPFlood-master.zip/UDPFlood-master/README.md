# How to start UDP Flood?
1. Start-up start.cmd.
2. Enter target IP address.
3. Enter attack count.