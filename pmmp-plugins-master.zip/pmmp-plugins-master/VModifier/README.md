# VModifier
![Release](https://img.shields.io/badge/release-v2.0-blue.svg)

VModifier is a PocketMine-MP plugin that allows you to modify the output for PocketMine version commands. This plugin can be easily disabled from the config in case you want to temporarily remove its features.

## Commands
This plugin has no commands.

## Permissions
This plugin has no permissions.

**Note**: This plugin will alter default permission nodes from the following commands:
- `/version`
- `/ver`
- `/about`
