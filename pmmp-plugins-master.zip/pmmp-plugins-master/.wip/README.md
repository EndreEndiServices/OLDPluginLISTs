# Work in progress
List of plugins that are still under development and are not ready to run on production PocketMine servers. Most will contain bugs and hence code contributions are highly valued.

## Plugins

| Name | Development phase |
| ---- | ----------------- |
| [**BadWord**](https://github.com/kenygamer/pmmp-plugins/blob/master/.wip/BadWord) | *Pre-alpha* |
