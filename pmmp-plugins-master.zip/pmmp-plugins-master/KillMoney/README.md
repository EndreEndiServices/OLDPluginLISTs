# KillMoney
![Release](https://img.shields.io/badge/release-v1.1.3-blue.svg)

KillMoney is a PocketMine-MP plugin that allows you to give your players the opportunity to earn money by killing other players. You can also set messages to display them to the killer/victim by enabling this feature on the config.

**KillMoney 1.1.3 is not compatible with older KillMoney and PocketMine versions.**

## Commands
| Command | Usage | Description |
| ------- | ----- | ----------- |
| `/killmoney` | `/killmoney` | Prints out information about this KillMoney installation. |

## Permissions
```yaml
killmoney.command:
 default: true
killmoney.killer.receive.money:
 default: true
killmoney.victim.lose.money:
 default: false
```
