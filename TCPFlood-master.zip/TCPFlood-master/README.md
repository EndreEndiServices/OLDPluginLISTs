# How to start TCP Flood?
1. Start-up start.cmd.
2. Enter target IP address.
3. Enter target port.
4. Enter attack count.
