# PluginsInfo
Plugin for PocketMine-MP api 3.0.0-ALPHA10 to get informations on plugins, commands and permissions  

[![Poggit-CI](https://poggit.pmmp.io/ci.badge/TheNewHEROBRINEX/PluginsInfo/PluginsInfo)](https://poggit.pmmp.io/ci/TheNewHEROBRINEX/PluginsInfo/PluginsInfo)
## Commands
**/plugininfo** \<PluginName\> (alias: /plinfo) Get informations about a plugin  
**/commandinfo** \<commmandname\> (alias: /cmdinfo) Get informations about a command  
**/commandinfo** \<permission.name\> (alias: /perminfo) Get informations about a permission  
**/permissions** [pageNumber] (alias: /perms) Get a list of permissions 