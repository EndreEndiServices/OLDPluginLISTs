# ServerCore(WIP)
An essential all-in-one plugin, from custom help to being able to kick multiple players in one command.
