# FastRespawn

Plugin for PocketMine that will respawn you automatically when you die without show you the red screen.<br>

### Installation
It is easy you can download it from github in .zip format and extract it and put plugin folder in the plugins folder.
> Note: you should install DevTools plugin in your server you can find it in Poggit.

### Translation
INDEV

### Features
- Easy to use (if you don't know how to use it i think you are spoon and you should see this video(Arabic Dub): https://www.youtube.com/watch?v=FS83qD2LVEg
- No permissions and commands.
- Config File.
- Messages you can edit in config file.
- Money when you kill if you want (True/False) and you should to install (EconomyAPI).

### Commands and Permissions
No commands and permissions in this plugin but if you want to put permission you can but you should know how :)

### Feedback
I'd like to keep my issue tracker as clean as possible, so please take the following in consideration when opening a new issue in the issue tracker:
- If you have an issue with the plugin, check if the issue exists in the Issue tracker, and report it if not.
- If you'd like support or have a question about the plugin, please click the Gitter button under the title.
- If you have a great idea for a new feature or enhancement, please create a new issue in the Issue tracker.
- If you just want to have a talk, please click the Gitter button below the title.

### About Me
If you want to know more about me you can follow me:
>Instagram: @khavmc<br/>
>YouTube: xkhhv<br/>
>PMMP: KHAV
