# HydraStart
Simple yet useful restarter plugin for your Minecraft PE server [PocketMine-MP] !

## Features

> Auto reconnecter [Makes player(s) automatically rejoin **beta**]

> CountDown system

> Fully customizeable messages

> No overloading

# Branches

> This copy of HydraStart was tested and works on **TSP** , **Tesseract**, and those softwares who aren't latest fork of PocketMine-MP

> Go to **PocketMine** branch of this repo to get this working on other softwares also

## Addotional info:
> My Twitter: @TheAz928

> Server: play.hydrape.us:19132 [Beta]
