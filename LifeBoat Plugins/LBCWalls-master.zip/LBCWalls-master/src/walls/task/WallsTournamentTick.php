<?php

namespace walls\task;

use pocketmine\level\sound\ClickSound;
use pocketmine\level\sound\PopSound;
use pocketmine\scheduler\PluginTask;
use pocketmine\utils\TextFormat;
use walls\GameManager;

/**
 * Class WallsTournamentTick, runs every half of a second
 */
class WallsTournamentTick extends PluginTask {

	protected $lastTick = 0;
	protected $lastTip = 0;
	protected $plugin;
	protected $gameManager;
	protected $inGamePlayers;
	protected $notificationTime;
	protected $tick = 0;

	/**
	 * Initializes Walls tournament tick
	 */
	public function __construct($plugin, $gameManager) {
		$this->plugin = $plugin;
		$this->gameManager = $gameManager;
		parent::__construct($plugin);
		$this->lastTick = time();
	}

    /**
     * Runs handlers tick evert second and runs messages tick every half of a second (for displaying popups)
     */
	public function onRun($currentTick) {
		$this->inGamePlayers = $this->gameManager->getPlayersInGame();
		$this->messagesTick();
		if (time() > $this->lastTick) {
			$this->handlersTick();
		}
		$this->lastTick = time();
	}
	
	public function handlersTick(){
			$this->tick++;
			$count = count($this->inGamePlayers);
			$state = $this->gameManager->getGameState();
			
            /*
             * Recolors players names every 3 seconds
             */
			if ($this->lastTick % 3 == 0) {
			foreach ($this->plugin->getServer()->getOnlinePlayers() as $player) {
				if($player->getTeam() != "spectators"){
					$player->updateDisplayedName(constant('pocketmine\utils\TextFormat::' . strtoupper($player->getTeam())));
					}
				}
			}
			if (!$this->gameManager->isGameStarted()) {
				$playersLimit = $this->gameManager->getGameConfig("playersLimit");
				if ($count < $playersLimit) {
					$this->gameManager->setGameState(GameManager::ACCEPTING_PLAYERS);
				} elseif ($count < 24) {
					$this->gameManager->setGameState(GameManager::ACCEPTING_VIP);
				} else {
					$this->gameManager->setGameState(GameManager::FULL);
				}

				if ($count >= $playersLimit || $state == GameManager::COUNTDOWN) {
					
                    /**
                     * Countdown before match start
                     */
					$this->gameManager->setGameState(GameManager::COUNTDOWN);
					$this->gameManager->setGameConfig("startedCountdown", "dec");
					$startedCountdown = $this->gameManager->getGameConfig("startedCountdown");
					
                    /**
                     * Plays sound when countdown before game start is running
                     */
                    if ($startedCountdown <= 5 && $startedCountdown > 0) {
						foreach ($this->inGamePlayers as $p) {
							$sound = new ClickSound($p->getPosition(), 2);
							$this->plugin->getServer()->getDefaultLevel()->addSound($sound, [$p]);
						}
					}
					if ($startedCountdown === 0) {
						foreach ($this->inGamePlayers as $p) {
							$sound = new PopSound($p->getPosition(), 2);
							$this->plugin->getServer()->getDefaultLevel()->addSound($sound, [$p]);
						}
					}
				} else {
					$this->gameManager->setGameConfig("startedCountdown", "default");
				}

				/**
                 * Start match
                 */
				if ($state != GameManager::END_GAME && $this->gameManager->getGameConfig("startedCountdown") < 1) {
					$this->gameManager->setGameState(GameManager::IN_GAME);
					$this->notificationTime = 10;
					$this->gameManager->start();
				}
			}

			if ($state === GameManager::IN_GAME) {
                
				/**
                 * Plays sound when countdown before walls drop is running
                 */
				$this->gameManager->setGameConfig("wallsDropTimer", "dec");
				$wallsDropTimer = $this->gameManager->getGameConfig("wallsDropTimer");
				if ($wallsDropTimer <= 5 && $wallsDropTimer > 0) {
					foreach ($this->inGamePlayers as $p) {
						$sound = new ClickSound($p->getPosition(), 3);
						$this->plugin->getServer()->getDefaultLevel()->addSound($sound, [$p]);
					}
				}
				if ($wallsDropTimer === 0) {
					foreach ($this->inGamePlayers as $p) {
						$sound = new PopSound($p->getPosition(), 3);
						$this->plugin->getServer()->getDefaultLevel()->addSound($sound, [$p]);
					}
				}
                
				/**
                 * Send walls drop notification (every minute)
                 */
				if (is_int($wallsDropTimer / 60) && $wallsDropTimer > 0) {
					foreach ($this->inGamePlayers as $player) {
						$wallsWillDropInStr = $this->plugin->lang->getTranslatedString($player->language, 'WALLS_WILL_DROP_IN');
						$minutesStr = $this->plugin->lang->getTranslatedString($player->language, 'MINUTES');
						$player->sendMessage("§9>§7 " . $wallsWillDropInStr . " " . ($wallsDropTimer / 60). " " . $minutesStr . ".");
					}
				}

				/*
                 * Drop the walls
                 */
				if ($wallsDropTimer < 1) {
					$this->gameManager->setGameState(GameManager::DROPPED);
					$this->gameManager->drop();
				}
			}

			if ($this->gameManager->getGameState() === GameManager::DROPPED) {
				$this->gameManager->setGameConfig("deathmatchTimer", "dec");
				$deathmatchTimer = $this->gameManager->getGameConfig("deathmatchTimer");
                
                /**
                 * Plays sound and send popup when countdown before deathmatch is running
                 */
				if ($deathmatchTimer <= 5 && $deathmatchTimer > 0) {
					foreach ($this->inGamePlayers as $p) {
						$deathmatchInStr = $this->plugin->lang->getTranslatedString($p->language, 'DEATHMATCH_IN');
						$secondsStr = $this->plugin->lang->getTranslatedString($p->language, 'SECONDS');
						$sound = new ClickSound($p->getPosition(), 2);
						$this->plugin->getServer()->getDefaultLevel()->addSound($sound, [$p]);
						$p->sendPopup(TextFormat::YELLOW . $deathmatchInStr . " " . $deathmatchTimer . " " . $secondsStr);
					}
				}
				if ($deathmatchTimer === 0) {
					foreach ($this->inGamePlayers as $p) {
						$sound = new PopSound($p->getPosition(), 2);
						$this->plugin->getServer()->getDefaultLevel()->addSound($sound, [$p]);
					}
				}
                
				/**
                 * Send deathmatch notification (every minute)
                 */
				if (is_int($deathmatchTimer / 60) && $deathmatchTimer <= 300) {
					foreach ($this->inGamePlayers as $p) {
						$deathmatchInStr = $this->plugin->lang->getTranslatedString($p->language, 'DEATHMATCH_IN');
						$minutesStr = $this->plugin->lang->getTranslatedString($p->language, 'MINUTES');
						$p->sendPopup("§9>§7 " . $deathmatchInStr . " " . ($deathmatchTimer / 60) . " " . $minutesStr . ".");
					}
				}

				/*
                 * Start the deathmatch
                 */
				if ($deathmatchTimer < 1) {
					$this->gameManager->setGameState(GameManager::DEATHMATCH);
					$this->gameManager->deathmatch();
				}
			}

			if ($this->gameManager->getGameState() === GameManager::DEATHMATCH) {
				
                /**
                 * Plays sound and send popup when countdown before game end is running
                 */
				$this->gameManager->setGameConfig("endMatchTimer", "dec");
				$endMatchTimer = $this->gameManager->getGameConfig("endMatchTimer");
				if (is_int($endMatchTimer / 60) && $endMatchTimer <= 180 && $endMatchTimer > 0) {
					foreach ($this->inGamePlayers as $p) {
						$deathmatchEndInStr = $this->plugin->lang->getTranslatedString($p->language, 'DEATHMATCH_WILL_END_IN');
						$minutesStr = $this->plugin->lang->getTranslatedString($p->language, 'SECONDS');
						$p->sendPopup("§9>§7 " . $deathmatchEndInStr . " " . ($endMatchTimer / 60) . " " . $minutesStr . ".");
					}
				}

				/*
                 * End the match
                 */
				if ($endMatchTimer < 1) {
					$this->gameManager->setGameState(GameManager::END_GAME);
					$this->gameManager->endGame();
				}
			}

			/*
             * End match if only one player in game left
             */
			if ($this->gameManager->getGameState() !== GameManager::ACCEPTING_PLAYERS && $count === 1) {
				$this->gameManager->setShuttingDown();
			}

			if ($this->gameManager->isShuttingDown()) {
				if ($this->gameManager->getGameConfig("shutdownTimer") < 1) {
					$this->gameManager->endGame();
					$this->lastTick = 0;
				}
				$this->gameManager->setGameConfig("shutdownTimer", "dec");
			}
	}
	
	public function messagesTick(){
		if ($this->lastTip < microtime(true)) {
            $state = $this->gameManager->getGameState();
            foreach ($this->plugin->getServer()->getOnlinePlayers() as $p) {
                
                /**
                 * Send "please login first" notification to spectators
                 */
                if($p->getTeam() == "spectators" && $state != GameManager::COUNTDOWN && $state != GameManager::ACCEPTING_PLAYERS){
                    $p->sendLocalizedPopup("WAIT_MATCH_ENDS");
                    continue;
                }
                
                if ($state === GameManager::COUNTDOWN) {
                    
                    /*
                     * Send notification when countdown before match start is running
                     */
                    $startingIn = $this->plugin->lang->getTranslatedString($p->language, 'STARTING_IN');
                    $seconds = $this->plugin->lang->getTranslatedString($p->language, 'SECONDS');
                    $color = $this->gameManager->getGameConfig("startedCountdown") <= 3 ? 'YELLOW' : 'GREEN';
                    $colorTextFormat = constant('\\pocketmine\\utils\\TextFormat::' . $color);
                    $p->sendPopup($colorTextFormat . $startingIn . " " . TextFormat::AQUA . $this->gameManager->getGameConfig("startedCountdown") . " " . $seconds);
                }elseif ($this->gameManager->isShuttingDown() && $this->gameManager->getGameConfig("shutdownTimer") <= 10) {
                    
                    /*
                     * Send notification when countdown before match end is running
                     */
                    $returningStr = $this->plugin->lang->getTranslatedString($p->language, 'RETURNING_TO_LOBBY_IN');
                    $secondsStr = $this->plugin->lang->getTranslatedString($p->language, 'SECONDS');
                    $p->sendTip(TextFormat::AQUA . $returningStr . " " . $this->gameManager->getGameConfig("shutdownTimer") . " " . $secondsStr . ".");
                } elseif ($state === GameManager::ACCEPTING_PLAYERS) {
                    
                    /*
                     * Send notification when more players needs to start
                     */
                    $waitingForStr = $this->plugin->lang->getTranslatedString($p->language, 'WAITING_FOR');
                    $playersStr = $this->plugin->lang->getTranslatedString($p->language, 'PLAYERS');
                    $p->sendPopup(TextFormat::YELLOW . $waitingForStr . " " . ($this->gameManager->getGameConfig("playersLimit") - count($this->inGamePlayers)) . " " . $playersStr . ".");
                } elseif ($this->notificationTime !== 0) {
                    
                    /*
                     * Send notification when game has been started
                     */
                    if ($this->notificationTime < 1) {
                        $this->notificationTime = 0;
                        return false;
                    }
                    $this->notificationTime--;
                    $p->sendLocalizedPopup('GAME_STARTED', [], TextFormat::BOLD . TextFormat::GREEN);
                } else {
                    
                    /*
                     * Send notification of different game states
                     */
                    $timeMsg = "";
                    switch ($state) {
                        case GameManager::IN_GAME:
                            if ($this->gameManager->getGameConfig("wallsDropTimer") > 300) {
                                $color = 'GREEN';
                            } elseif ($this->gameManager->getGameConfig("wallsDropTimer") > 5) {
                                $color = 'YELLOW';
                            } else {
                                $color = 'RED';
                            }
                            $dropStr = $this->plugin->lang->getTranslatedString($p->language, 'DROP');
                            $timeMsg = constant('\\pocketmine\\utils\\TextFormat::' . $color) . $dropStr . ": " . date("i:s", $this->gameManager->getGameConfig("wallsDropTimer"));
                            break;
                        case GameManager::DEATHMATCH:
                            $color = $this->gameManager->getGameConfig("deathmatchTimer") < 180 ? 'YELLOW' : 'RED';
                            $deathmatchStr = $this->plugin->lang->getTranslatedString($p->language, 'DEATHMATCH');
                            $timeMsg = constant('\\pocketmine\\utils\\TextFormat::' . $color) . $deathmatchStr . ": " . date("i:s", $this->gameManager->getGameConfig("endMatchTimer"));
                            break;
                        case GameManager::END_GAME:
                            $color = $this->gameManager->getGameConfig("shutdownTimer") < 15 ? 'YELLOW' : 'RED';
                            $endStr = $this->plugin->lang->getTranslatedString($p->language, 'END');
                            $timeMsg = constant('\\pocketmine\\utils\\TextFormat::' . $color) . $endStr . ": " . date("i:s", $this->gameManager->getGameConfig("shutdownTimer"));
                            break;
                    }
                    if (strlen($timeMsg) > 0) {
                        $teamStr = "";
                        if ($p->getTeam() == 'spectatorss') {
                            $lobbyToReturnStr = $this->plugin->lang->getTranslatedString($p->language, 'LOBBY_TO_RETURN');
                            $teamStr = TextFormat::AQUA . "/" . $lobbyToReturnStr;
                        } else {
                            $colorStr = $this->plugin->lang->getTranslatedString($p->language, strtoupper($p->getTeam()));
                            $teamStr = constant('\\pocketmine\\utils\\TextFormat::' . strtoupper($p->getTeam())) . $colorStr;
                        }
                        $p->sendPopup($timeMsg . TextFormat::GRAY . " - " . $teamStr);
                    }
                }
            }
            $this->lastTip = microtime(true) - .5;
		}
	}

}
