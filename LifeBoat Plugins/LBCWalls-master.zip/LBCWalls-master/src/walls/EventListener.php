<?php

namespace walls;

use LbCore\LbCore;
use LbCore\LbEventListener;
use pocketmine\event\server\QueryRegenerateEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\inventory\InventoryOpenEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\event\player\PlayerItemHeldEvent;
use pocketmine\event\player\PlayerKickEvent;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\event\player\PlayerCreationEvent;
use pocketmine\event\level\ChunkLoadEvent;
use pocketmine\inventory\ChestInventory;
use pocketmine\inventory\DoubleChestInventory;
use pocketmine\inventory\PlayerInventory;
use LbCore\event\PlayerAuthEvent;
use pocketmine\item\Item;
use walls\WallsPlayer;
use pocketmine\utils\TextFormat;
use walls\GameManager;
use pocketmine\event\entity\EntityExplodeEvent;

/**
 * Walls plugin EventListener, handling events like onPlayerLogin, onPlayerDeath etc
 */
class EventListener extends LbEventListener {

	protected $plugin;
	protected $gameManager;

	/**
	 * Walls listener constructor called in Walls onEnable()
	 */
	public function __construct(Walls $plugin, $gameManager) {
		$this->plugin = $plugin;
		$this->gameManager = $gameManager;
		parent::__construct($plugin);
	}

	/**
	 * Set WallsPlayer instead of LbPlayer
	 */
	public function onPlayerCreation(PlayerCreationEvent $event) {
		$event->setPlayerClass(WallsPlayer::class);
	}

	/**
	 * Set server name and attributes
	 */
	public function onQuery(QueryRegenerateEvent $event) {
		$lbcore = LbCore::getInstance();
		if (isset($lbcore->playerCount->wl_players)) {
			$event->setPlayerCount($lbcore->playerCount->wl_players);
		}
		if (isset($lbcore->playerCount->wl_slots)) {
			$event->setMaxPlayerCount($lbcore->playerCount->wl_slots);
		}
		$event->setServerName('{-name-:-Lifeboat Walls-,-node-:{-type-:-WL-,-ip-:-' . $lbcore->getDomainName() . '-,-players-:' . count($this->plugin->getServer()->getOnlinePlayers()) . ',-maxplayers-:90,-tps-:' . $this->plugin->getServer()->getTicksPerSecond() . '}}');
	}

	/**
	 * Runs when player joins a server
	 * Add 4 wools items to player inventory for select player's team
	 */
	public function onPlayerLogin(PlayerLoginEvent $event) {
		parent::onPlayerLogin($event);
		$player = $event->getPlayer();
        foreach($this->gameManager->getSpectators() as $spectator){
            $player->hidePlayer($spectator);
        }
		if(!$this->gameManager->isGameStarted() || $this->gameManager->getGameState() == GameManager::IN_GAME){
			$player->setFoodEnabled(false); //Disable hunger for this game mode
			$player->setupInventory(); // Add 4 wools to player inventory for changing team
			$team = $this->gameManager->selectTeam($player); // Add player to random team
			$this->gameManager->addPlayerToGame($player); // Add player to list of in-game players
			$player->setNameTag(constant("\\pocketmine\\utils\\TextFormat::" . strtoupper($team)) . $player->getName()); // Set color of player's name
        }else{
			$this->gameManager->addPlayerToSpectators($player);
            $player->teleport($this->gameManager->getSpectatorSpawnPoint($player));
		}
	}

    /*
     * Give kit when player authorizes
     */
    public function onPlayerAuth(PlayerAuthEvent $event){
        $player = $event->getPlayer();
        $player->getInventory()->sendContents($player);
    }
    
	/**
	 * Deny players from drop wools when game is not started
	 */
	public function onPlayerDropItem(PlayerDropItemEvent $event) {
		if (!$this->gameManager->isGameStarted()) {
			$event->setCancelled(true);
		}
	}

	/**
	 * Runs when player dies. Moves player to spectators. Checks for game end 
	 */
	public function onPlayerDeath(PlayerDeathEvent $event) {
		$player = $event->getEntity();
        $event->setDeathMessage("");
		$attacker = false;
		if (!$player instanceof WallsPlayer) {
			return false;
		}
		$attackerevt = $player->getLastDamageCause();
		if ($attackerevt instanceof EntityDamageByEntityEvent) {
			$attacker = $attackerevt->getDamager();

			if ($attacker instanceof Player) {
				$this->plugin->lang->broadcastMessageLocalized('WAS_SLAIN_BY', [], $player->getDisplayName() . TextFormat::DARK_AQUA . " ", " " . $attacker->getDisplayName());
				$this->plugin->getServer()->getScheduler()->scheduleAsyncTask(new \LbCore\task\KillRequest($player, $attacker));
			}
		}
        $vector = $this->gameManager->getSpectatorSpawnPoint($player);

		$player->setGamemode(WallsPlayer::SPECTATOR);
		$player->setNameTag($player->getName());
		$player->setDisplayName($player->getName());
		$player->teleport($vector);

		$this->gameManager->addPlayerToSpectators($player);
		$player->setTeam("spectators");

		$this->gameManager->removeFromGame($player);

		$player->hideFromAll();

		$player->setSpawn($vector);

		$this->gameManager->getWinner(); // Check to end of game
	}

	/**
	 * Runs when player takes item from his inventory
	 * Move player to specific team, when player takes a wool item
	 */
	public function onPlayerItemHeld(PlayerItemHeldEvent $event) {
		$slot = $event->getInventorySlot();
		$player = $event->getPlayer();

		if (!$this->gameManager->isPlayerInGame($player->getId())) {
			$event->setCancelled(true);
			return;
		}

		if (!$this->gameManager->isGameStarted() && $event->getItem()->getId() == Item::WOOL) {
			switch ($event->getItem()->getDamage()) { // Check wool color
				case 14:
					$team = "red";
					break;
				case 3:
					$team = "blue";
					break;
				case 13:
					$team = "green";
					break;
				case 4:
					$team = "yellow";
					break;
				default:
					return false;
			}

			if ($team === $player->getTeam()) {
				$teamString = $this->plugin->lang->getTranslatedString($player->language, 'TEAM');
				$player->sendLocalizedMessage('YOU_ALREADY_ON_THE', [], TextFormat::YELLOW, " " . constant("\\pocketmine\\utils\\TextFormat::" . strtoupper($team)) . $team . ' ' . TextFormat::YELLOW . $teamString . '.');
				return false;
			}

			$this->gameManager->selectTeam($player, $team);
		}
	}

	/**
	 * Runs on player respawn, move player to spectators when game started or move him to lobby
	 */
	public function onPlayerRespawn(PlayerRespawnEvent $event) {
		$player = $event->getPlayer();
		if ($this->gameManager->isGameStarted()) {
            if($this->gameManager->getGameState() != GameManager::IN_GAME){
                $player->sendLocalizedMessage('YOU_NOW_SPECTATING');
                $player->sendLocalizedMessage('WILL_JOIN_NEXT');
                if ($this->gameManager->isPlayerInSpectators($player->getId())) {
                    $player->setGamemode(WallsPlayer::SPECTATOR);
                    $pos = $this->gameManager->getSpectatorSpawnPoint($player);
                    $event->getRespawnPosition()->setComponents($pos->getX(), $pos->getY(), $pos->getZ());
                }
            }
		} else {
			$lobby = $this->gameManager->getLobbyVector();
			$event->getRespawnPosition()->setComponents($lobby->x, $lobby->y, $lobby->z);
			$this->gameManager->returnToLobby($player);
		}
	}

	/**
	 * Runs when player leaves the game. Check for game end 
	 */
	public function onPlayerQuit(PlayerQuitEvent $event) {
		$player = $event->getPlayer();
        $event->setQuitMessage("");
		$this->gameManager->removeFromGame($player);
		if ($this->gameManager->isGameStarted()) {
			$this->gameManager->getWinner();
		}
	}

	/**
	 * Runs when player was kicked from the game 	 
	 */
//	public function onPlayerKick(PlayerKickEvent $event) {
//		$player = $event->getPlayer();
//		$reason = $event->getReason();
//		if (stristr($reason, "fly")) {
//			$x = $player->getFloorX();
//			$y = $player->getFloorY();
//			$z = $player->getFloorZ();
//			if (
//				$this->plugin->getServer()->getDefaultLevel()->getBlockIdAt($x, $y, $z) !== 0 or
//				$this->plugin->getServer()->getDefaultLevel()->getBlockIdAt($x + 1, $y, $z) !== 0 or
//				$this->plugin->getServer()->getDefaultLevel()->getBlockIdAt($x + 1, $y, $z + 1) !== 0 or
//				$this->plugin->getServer()->getDefaultLevel()->getBlockIdAt($x - 1, $y, $z) !== 0 or
//				$this->plugin->getServer()->getDefaultLevel()->getBlockIdAt($x - 1, $y, $z - 1) !== 0 or
//				$this->plugin->getServer()->getDefaultLevel()->getBlockIdAt($x, $y, $z - 1) !== 0 or
//				$this->plugin->getServer()->getDefaultLevel()->getBlockIdAt($x, $y, $z + 1) !== 0
//			) {
//				$event->setCancelled(true);
//			}
//		}
//	}

	/**
	 * Runs when player try to break block, allow only when game is started
	 */
	public function onBlockBreak(BlockBreakEvent $event) {
		$player = $event->getPlayer();

		if (!$this->gameManager->isGameStarted() || $player->isSpectator()) {
			$event->setCancelled(true);
			return false;
		}

		$block = $event->getBlock();

		if (!$player->checkWallBlockBreak($block->getId())) { // Don't allow to break walls
			$event->setCancelled(true);
			return false;
		}
	}

	/**
	 * Runs when player open chest, chest is filling by items (if it hasn't filled already)
	 */
	public function onInventoryOpen(InventoryOpenEvent $event) {
		$inv = $event->getInventory();
		$player = $event->getPlayer();

		if ($event->getInventory() instanceof PlayerInventory) {
			return;
		}
		if (!$this->gameManager->isGameStarted()) {
			$event->setCancelled(true);
			return false;
		}

		$luck = 1;
		if ($player->vipStatus !== 'none') {
			$luck++;
		}

		if ($inv instanceof ChestInventory or $inv instanceof DoubleChestInventory) {
			if ($inv instanceof ChestInventory) {
				$this->gameManager->fillChest($event, false, $luck);
			} elseif ($inv instanceof DoubleChestInventory) {
				$this->gameManager->fillChest($event, true, $luck);
			}
		}
	}

	/**
	 * Runs when player try to set block, allows only when game is started
	 */
	public function onBlockPlace(BlockPlaceEvent $event) {
        parent::onBlockPlace($event);
		if (!$this->gameManager->isGameStarted()) {
			$event->setCancelled(true);
			return false;
		}

		$block = $event->getBlockAgainst();
		$player = $event->getPlayer();
		$y = $block->getY();

		if ($event->getBlock()->getId() === Item::CHEST) {
			$this->gameManager->addFilledChest($event->getBlock()->getX() . "," . $event->getBlock()->getY() . "," . $event->getBlock()->getZ());
		}

		if (!$player->checkBuildMaxHeight($y, $this->gameManager->getMaxBlockPlaceHeight())) {
			$event->setCancelled(true);
			return false;
		}
	}

	/**
	 * Executes when chunk loads
	 */
//	public function onChunkLoad(ChunkLoadEvent $event) {
//		$chunk = $event->getChunk();
//		for ($i = 0; $i < 16; $i++) {
//			for ($j = 0; $j < 16; $j++) {
//				$chunk->setBiomeColor($i, $j, 141, 179, 96);
//				$chunk->setChanged(true);
//			}
//		}
//	}

	/*
	 * Denying to hit player's teammates 
	 */
	public function onEntityDamage(EntityDamageEvent $event) {
		$player = $event->getEntity();
		if (!$this->gameManager->isGameStarted()) {
			$event->setCancelled(true);
			return false;
		} else {
			if ($event instanceof EntityDamageByEntityEvent) {
				$attacker = $event->getDamager();
                if($this->gameManager->isPlayerInSpectators($attacker->getId())){
                    $event->setCancelled(true);
                    return;
                }
				if ($attacker instanceof WallsPlayer && $player instanceof WallsPlayer) {
					if ($attacker->getTeam() === $player->getTeam()) {
						$event->setCancelled(true);
					}
				}
			}
		}
	}
    
    public function onEntityExplode(EntityExplodeEvent $event){
        $event->setBlockList([]);
    }

}
