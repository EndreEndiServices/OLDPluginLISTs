<?php

namespace walls;

use pocketmine\math\Vector3;
use walls\data\PluginData;
use pocketmine\utils\TextFormat;
use walls\WallsPlayer;
use pocketmine\item\Item;
use pocketmine\block\Air;

/*
 * Game manager, contains handlers of Walls game
 */
class GameManager {

	/*
     * Different game states
     */
	const PLUGIN_NAME = "walls";
	const ACCEPTING_PLAYERS = "accepting-players";
	const ACCEPTING_VIP = "accepting-vip";
	const COUNTDOWN = "countdown";
	const FULL = "full";
	const IN_GAME = "in-game";
	const DROPPED = "dropped";
	const DEATHMATCH = "deathmatch";
	const END_GAME = "end-game";
	const SHUTTING_DOWN = "shutting-down";

	protected $plugin; //Walls plugin
	protected $level;
	protected $lobbyVector;
	protected $gameConfig; //Game config from PluginData
	protected $chestItems; //List of items in chests
	protected $mapList; //List of maps
	protected $mapConfig; //Config of current map
	protected $map; //Map what used in game
	protected $started; //Is game started
	protected $dropped; //Is game dropped
	protected $shuttingDown; //Is game shutting down
	protected $inGamePlayers; //List of players in game
	protected $spectators = []; //List of spectators
	protected $state = self::ACCEPTING_PLAYERS; //Current state of game
	protected $maxBlockPlaceHeight = 120;
	protected $colors = array('red', 'blue', 'green', 'yellow'); //List of available teams
	protected $defaultColor = 'red'; //Default team
	protected $filledChests = []; // List of already filled chestss
	protected $defaultConfig; // Default game config (timers and etc)
	protected $testing = false; // Set it to "true" to enable test mode (see walls/data/PluginData)

	/**
	 * Walls game configs initialize (timers, maps, etc)
	 */
	public function __construct($plugin) {
		$this->plugin = $plugin;
		$this->level = $this->plugin->getServer()->getDefaultLevel();
		$this->level->setTime(0);
		$this->level->stopTime();
		$lobbyPoint = $this->level->getSpawnLocation();
		$this->lobbyVector = new Vector3($lobbyPoint->getX(), $lobbyPoint->getY(), $lobbyPoint->getZ());
		$pluginData = new PluginData(); //Initialize Walls config (maps and walls coords, etc)
		$this->chestItems = $pluginData->chestItems;
		$this->mapList = $pluginData->mapList;
		$this->mapConfig = $pluginData->mapConfig;
		$this->map = $this->mapList[rand(0, (count($this->mapList) - 1))]; //Get random map
        $this->plugin->getLogger()->info("Using map: " . $this->map);
		$this->defaultConfig = $this->testing ? $pluginData->testConfig : $pluginData->mainConfig;
		if ($this->testing) {
			$this->plugin->getLogger()->info("Testing mode enabled");
		}
		//$this->loadMap($this->map);
		$this->setDefaultParams();
	}

	/*
	 * Set default game parameters (timers, etc)
	 */
	public function setDefaultParams() {
		$this->started = false;
		$this->dropped = false;
		$this->shuttingDown = false;
		$this->inGamePlayers = [];
		$this->gameConfig = $this->defaultConfig;
	}

	/*
	 * Load selected map
	 */
//	public function loadMap($map) {
//		for ($x = -4; $x <= 4; $x++) {
//			for ($z = -4; $z <= 4; $z++) {
//				$this->level->loadChunk($x, $z, false);
//			}
//		}
//
//		for ($x = -10; $x <= -5; $x++) {//Spawn
//			for ($z = -1; $z <= 4; $z++) {
//				$this->level->loadChunk($x, $z, false);
//			}
//		}
//
//		for ($x = -24; $x <= -20; $x++) {//Deathmatch
//			for ($z = 22; $z <= 25; $z++) {
//				$this->level->loadChunk($x, $z, false);
//			}
//		}
//
//		switch ($map) {
//			case "Island":
//				for ($x = -34; $x <= -21; $x++) {
//					for ($z = -5; $z <= 9; $z++) {
//						$this->level->loadChunk($x, $z, false);
//					}
//				}
//				break;
//			case "Stronghold":
//				for ($x = -15; $x <= -1; $x++) {
//					for ($z = -29; $z <= -16; $z++) {
//						$this->level->loadChunk($x, $z, false);
//					}
//				}
//				break;
//			case "Desert":
//				for ($x = 15; $x <= 29; $x++) {
//					for ($z = -8; $z <= 5; $z++) {
//						$this->level->loadChunk($x, $z, false);
//					}
//				}
//				break;
//			case "Winter":
//				for ($x = 17; $x <= 30; $x++) {
//					for ($z = 16; $z <= 29; $z++) {
//						$this->level->loadChunk($x, $z, false);
//					}
//				}
//				break;
//		}
//	}

	/**
	 * Fills chest with items if it hasn't filled already
	 */
	public function fillChest($chest, $isDouble, $luck) {
		$block = $chest->getInventory()->getHolder();
		$newChestCoords = $block->getX() . "," . $block->getY() . "," . $block->getZ();
		if (in_array($newChestCoords, $this->filledChests)) {
			return false;
		} else {
			$this->filledChests[] = $newChestCoords;
		}
		$thisChest = array();
		$chest->getInventory()->clearAll();
		$items = $this->chestItems;
		if ($isDouble) {
			$cnt = rand(($luck * 6), ($luck * 12));
		} else {
			$cnt = rand(($luck * 3), ($luck * 8));
		}
		for ($d = 0; $d <= $cnt; $d++) {
			$r = rand(1, 1000);
			$done = false;
			if ($r < 718) {
				if (rand(1, 3) === 2) {
					$r = rand(718, 1000);
				}
			}
			foreach ($items as $item) {
				if ($done === false) {
					if ($r < $item[1]) {
						if (!in_array($item[0], $thisChest)) {
							$thisChest[] = $item[0];
							$done = true;
							if ($isDouble) {
								$slot = rand(0, 40);
							} else {
								$slot = rand(0, 26);
							}
							if ($item[2]) {
								$c = rand(1, 3);
							} else {
								$c = 1;
							}
							$chest->getInventory()->setItem($slot, Item::get($item[0], 0, $c));
						}
					}
				}
			}
		}
	}

	/**
	 * Start of the game
	 */
	public function start() {
		$this->plugin->lang->broadcastMessageLocalized('GAME_STARTED', [], '§9> §6');
		$this->plugin->lang->broadcastMessageLocalized('TEAM_CHAT_ENABLED', [], '§9>' . TextFormat::GREEN . ' ');
		$this->plugin->lang->broadcastMessageLocalized('USING_MAP', [], '§9> §6', ': ' . $this->mapConfig[$this->map]['friendlyName']);
		foreach ($this->plugin->getServer()->getOnlinePlayers() as $p) {
			if (isset($this->inGamePlayers[$p->getId()])) {
				$p->noDamageTicks = 20;
				$p->teleportByTeam($this->mapConfig[$this->map]);
			}
		}
		$this->started = true;
	}

	/**
	 * Drop the walls
	 */
	public function drop() {
        Logger::getInstance()->write("drop walls start", true);
		$config = $this->mapConfig[$this->map];
		$wallsCoords = $config['wallsCoords'];

		$this->level->freezeMap();

		foreach ($wallsCoords['xz'] as $c) {
			$this->destroyWalls($c['x'], $wallsCoords['y'], $c['z']);
		}

		$this->plugin->lang->broadcastMessageLocalized('WALLS_DROPPED', [], '§9>§7 ');

		$this->dropped = true;
        Logger::getInstance()->write("drop walls end", true);
	}

	/**
	 * Start the deathmatch
	 */
	public function deathmatch() {
		$this->plugin->lang->broadcastMessageLocalized('DEATHMATCH_STARTED', [], '§9>§7 ');

		foreach ($this->inGamePlayers as $p) {
			$p->moveToDeathmatch();
		}

		foreach ($this->spectators as $player) {
			$player->moveToDeathmatch();
		}
	}

	/**
	 * End the match
	 */
	public function endGame() {
		$this->level->unfreezeMap();
		$this->setDefaultParams();
		foreach ($this->plugin->getServer()->getOnlinePlayers() as $player) {
			if ($player->isSpectator()) {
				foreach ($this->plugin->getServer()->getOnlinePlayers() as $onlinePlayer) {
					$onlinePlayer->showPlayer($player);
				}
			}
			if ($player->isAlive()) {
				$this->returnToLobby($player);
			}
		}
		$this->spectators = array();
	}

	/**
	 * Returns specified player to the lobby.
	 */
	public function returnToLobby($player) {
		if (!$this->started) {
			$this->inGamePlayers[$player->getId()] = $player;
			$player->setGamemode(WallsPlayer::SURVIVAL);
            $player->setInDeathmatch(false);
            $player->showToAll();
            foreach($this->spectators as $spectator){
                $player->hidePlayer($spectator);
            }
			$player->setupInventory();
			$this->selectTeam($player);
			$player->setHealth($player->getMaxHealth());
		}
		$player->teleport($this->getLobbyVector());
		$player->setStateInLobby();
	}

	/**
	 * Stop the server
	 */
	public function stop() {
		$this->plugin->getServer()->shutdown();
	}

	/**
	 * Moves player to team
	 * if $team is empty - moves player to default/random team
	 */
	public function selectTeam($player, $team = null) {
		foreach ($this->colors as $color) {
			${$color} = array();
		}

		if ($team == null) {
			$min = PHP_INT_MAX;
			$team = $this->defaultColor;

			foreach ($this->plugin->getServer()->getOnlinePlayers() as $id => $data) {
				foreach ($this->colors as $color) {
					if ($data->getTeam() === $color) {
						${$color}[] = $id;
					}
				}
			}

			foreach ($this->colors as $color) {
				if (count(${$color}) < $min) {
					$min = count(${$color});
					$team = $color;
				}
			}
		} else {
			$max = 0;
			$maxColor = $this->defaultColor;
			foreach ($this->plugin->getServer()->getOnlinePlayers() as $id => $data) {
				foreach ($this->colors as $color) {
					if ($data->getTeam() === $color) {
						${$color}[] = $id;
					}
				}
			}

			foreach ($this->colors as $color) {
				if (count(${$color}) > $max) {
					$max = count(${$color});
					$maxColor = $color;
				}
			}

			if (count(${$team}) === $max or $maxColor === $team) {
				$player->sendLocalizedMessage('TEAM_IS_FULL', [], TextFormat::RED);
				return;
			}
		}
		$player->setTeam($team);
		$teamString = $this->plugin->lang->getTranslatedString($player->language, 'TEAM');
		$player->setNameTag(constant("\\pocketmine\\utils\\TextFormat::" . strtoupper($team)) . $player->getName());
		$player->sendLocalizedMessage('YOU_JOINED_THE', [], TextFormat::GREEN, " " . constant("\\pocketmine\\utils\\TextFormat::" . strtoupper($team)) . $team . TextFormat::GREEN . " " . $teamString . ".");
		return $team;
	}

	/**
	 * Checks and sets the winner team. Restarts the game when winner is found
	 */
	public function getWinner() {
		if ($this->started) {
			$colors = $this->colors;
			foreach ($colors as $color) {
				${$color} = array();
			}

			$max = 0;
			$maxColor = 'red';
			foreach ($this->plugin->getServer()->getOnlinePlayers() as $id => $data) {
				if (in_array($data->getTeam(), $colors)) {
					${$data->getTeam()}[] = $id;
				}
			}

			foreach ($colors as $color) {
				if (count(${$color}) > $max) {
					$max = count(${$color});
					$maxColor = $color;
				}
			}

			if ($max === 1) {
				$success = true;
				foreach ($colors as $color) {
					if ($color != $maxColor) {
						if (count(${$color}) >= $max) {
							$success = false;
						}
					}
				}
				if ($success) {
					$wonPrefix = "§9> " . constant("\\pocketmine\\utils\\TextFormat::" . strtoupper($maxColor)) . ucfirst($maxColor);
					$this->plugin->getServer()->broadcastMessage("§9> --------------------------------");
					$this->plugin->lang->broadcastMessageLocalized('WON_THE_MATCH', [], $wonPrefix . ' ');
					$this->plugin->getServer()->broadcastMessage("§9> --------------------------------");
					$this->state = $this::END_GAME;
					$this->shuttingDown = true;
				}
			}
		}
	}

	/**
	 * Removes specific player from list of players in game 
	 */
	public function removeFromGame($player) {
		unset($this->inGamePlayers[$player->getId()]);
	}

	/**
	 * Calculates and returns position of spectator spawn point. Depends on plugin state
	 */
	public function getSpectatorSpawnPoint(WallsPlayer $p) {
		$config = $this->mapConfig[$this->map];

		switch ($this->state) {
			case self::IN_GAME :
			case self::DROPPED :
				$respawnPos = $config['spectatorSpawnPoint'];
				break;
			case self::DEATHMATCH :
				$respawnPos = array('x' => -346, 'y' => 9, 'z' => 390);
				break;
			default :
				$respawnPos = array(
					'x' => $p->getX(),
					'y' => $p->getY(),
					'z' => $p->getZ()
				);
				break;
		}
		return new Vector3($respawnPos['x'], $respawnPos['y'], $respawnPos['z']);
	}

	/**
	 * Dropping the walls. The helper method
	 */
	protected function destroyWalls($arrX, $arrY, $arrZ) {
		if (count($arrX) > 1) {
			$z = $arrZ[0];
			for ($x = $arrX[0]; $x <= $arrX[1]; $x++) {
				$this->destroyWallsBlocks($x, $arrY, $z);
			}
		} elseif (count($arrZ) > 1) {
			$x = $arrX[0];
			for ($z = $arrZ[0]; $z <= $arrZ[1]; $z++) {
				$this->destroyWallsBlocks($x, $arrY, $z);
			}
		}
	}

	/**
	 * Dropping the walls. The helper method
	 */
    protected function destroyWallsBlocks($x, $arrY, $z) {
		for ($y = $arrY[0]; $y <= $arrY[1]; $y++) {
            $vector = new Vector3($x, $y, $z);
			$this->level->setBlock($vector, new Air(), false, false);
		}
	}

	/**
	 * Returns true when game started 
	 */
	public function isGameStarted() {
		return $this->started;
	}

	/**
	 * Returns true when game dropped 
	 */
	public function isGameDropped() {
		return $this->dropped;
	}

	/**
	 * Returns true when server is shutting down
	 */
	public function isShuttingDown() {
		return $this->shuttingDown;
	}

	/**
	 * Returns true when server is shutting down 
	 */
	public function setShuttingDown() {
		$this->shuttingDown = true;
	}

	/**
	 * Returns specific game config
	 */
	public function getGameConfig($configName) {
		return $this->gameConfig[$configName];
	}

	/**
	 * Sets new game config value
     * 
	 * @param mixed $value: 
	 *	"inc" - increments game config by 1
	 *	"dec" - decrements game config by 1
	 *	"default" - sets default game config
	 *	integer - sets specific value
	 */
	public function setGameConfig($configName, $value) {
		if (is_numeric($value)) {
			$this->gameConfig[$configName] = $value;
		} elseif ($value == "inc") {
			$this->gameConfig[$configName] ++;
		} elseif ($value == "dec") {
			$this->gameConfig[$configName] --;
		} elseif ($value == "default") {
			$this->gameConfig[$configName] = $this->defaultConfig[$configName];
		}
	}

	/**
	 * Adds player to list of players in game
	 */
	public function addPlayerToGame($player) {
		if (!$this->dropped) {
			$this->inGamePlayers[$player->getId()] = $player;
			if ($this->started) {
				$player->teleportByTeam($this->mapConfig[$this->map]);
			}
		}else{
            $this->removeFromGame($player);
            $this->addPlayerToSpectators($player);
        }
	}

	/**
	 * Adds player to list of spectators
	 */
	public function addPlayerToSpectators($player) {
		$this->spectators[$player->getId()] = $player;
        $player->setTeam("spectators");
        $player->hideFromAll();
	}

	/**
	 * Returns true when player is in game
	 */
	public function isPlayerInGame($playerId) {
		return isset($this->inGamePlayers[$playerId]) ? true : false;
	}

	/**
	 * Returns true when player is in list of spectators
	 */
	public function isPlayerInSpectators($playerId) {
		return isset($this->spectators[$playerId]) ? true : false;
	}

	/**
	 * Returns lobby coords
	 */
	public function getLobbyVector() {
		return $this->lobbyVector;
	}

	/**
	 * Adds chest to list of filled chests
	 */
	public function addFilledChest($position) {
		$this->filledChests[] = $position;
	}

	/**
	 * Returns maximum possible block placing height
	 */
	public function getMaxBlockPlaceHeight() {
		return $this->maxBlockPlaceHeight;
	}

	/**
	 * Returns list of players in game
	 */
	public function getPlayersInGame() {
		return $this->inGamePlayers;
	}

	/**
	 * Returns current game state
	 */
	public function getGameState() {
		return $this->state;
	}

	/**
	 * Sets new game state
	 */
	public function setGameState($state) {
		$this->state = $state;
	}
    
    /*
     * Returns list of spectators
     */
    public function getSpectators(){
        return $this->spectators;
    }

}
