<?php

namespace walls\data;

use pocketmine\item\Item;

/**
 * class PluginData creates coords for players spawn points, walls coords and timers,
 * list of items in chests, etc
*/
class PluginData {	
	
	/**
	 * Game countdowns, timers and limits
	*/
	public $mainConfig = array(
		'startedCountdown'  => 20,  // time before start the game (in secs)
		'shutdownTimer'		=> 15,  // time before return players to th lobby after end of the game (in secs)
		'wallsDropTimer'	=> 420, // time before drop walls (in secs)
		'deathmatchTimer'	=> 420, // time before deathmatch (in secs)
		'endMatchTimer'		=> 300, // deathmatch duration (in secs)
		'playersLimit'		=> 16  // min players number to start game
	);
	
	/**
	 * Game countdowns, timers and limits in the test mode (set GameManager->testing to true to enable it)
	*/
	public $testConfig = array(
		'startedCountdown'  => 10,
		'shutdownTimer'		=> 10,
		'wallsDropTimer'	=> 60,
		'deathmatchTimer'	=> 60,
		'endMatchTimer'		=> 60,
		'playersLimit'		=> 2
	);
	
	/**
	 * Available game maps
	*/
	public $mapList = array("Island", "Stronghold", "Desert", "Winter");
	
	public $mapConfig = array(
		"Island" => array(
			/**
             *  Walls coords. The Walls plugin uses these coords to drop the walls.
             */
			"wallsCoords" => array(
				"xz" => array(
					array(
						'x' => array(-417, -337),
						'z' => array(54),
					),
					array(
						'x' => array(-417, -337),
						'z' => array(23),
					),
					array(
						'x' => array(-530, -450),
						'z' => array(54),
					),
					array(
						'x' => array(-530, -450),
						'z' => array(23),
					),
					array(
						'x' => array(-418),
						'z' => array(55, 135),
					),
					array(
						'x' => array(-449),
						'z' => array(55, 135),
					),
					array(
						'x' => array(-418),
						'z' => array(-58, 22),
					),
					array(
						'x' => array(-449),
						'z' => array(-58, 22),
					)
				),
				"y" => array(63, 123)
			),
            
			/*
             *  Players spawn points coords. The Walls plugin uses these coords to teleport players when game starts
             */
			"spawnPoints" => array(
				array(array(-399, -403), array(137, 141)),
				array(array(-532, -536), array(69, 73)),
				array(array(-464, -468), array(-60, -64)),
				array(array(-331, -335), array(4, 8))
			),
            
			/*
             *  Spectators spawn point coords. 
             */
			"spectatorSpawnPoint" => array(
				'x' => -434,
				'y' => 65,
				'z' => 27
			),
			/*
             *  Displaying name of map
             */
			"friendlyName" => "Shiprekt"
		),
		"Stronghold" => array(
			"wallsCoords" => array(
				"xz" => array(
					array(
						'x' => array(-217, -137),
						'z' => array(-333)
					),
					array(
						'x' => array(-217, -137),
						'z' => array(-364)
					),
					array(
						'x' => array(-104, -24),
						'z' => array(-333)
					),
					array(
						'x' => array(-104, -24),
						'z' => array(-364)
					),
					array(
						'x' => array(-105),
						'z' => array(-332, -252)
					),
					array(
						'x' => array(-136),
						'z' => array(-332, -252)
					),
					array(
						'x' => array(-105),
						'z' => array(-445, -365)
					),
					array(
						'x' => array(-136),
						'z' => array(-445, -365)
					),
				),
				"y" => array(67, 123)
			),
			"spawnPoints" => array(
				array(array(-86, -90), array(-247, -250)),
                array(array(-18, -22), array(-378, -384)),
				array(array(-150, -156), array(-447, -451)),
				array(array(-219, -223), array(-313, -319))
			),
			"spectatorSpawnPoint" => array(
				'x' => -120,
				'y' => 81,
				'z' => -348
			),
			"friendlyName" => "Woodland"
		),
		"Desert" => array(
			"wallsCoords" => array(
				"xz" => array(
					array(
						'x' => array(265, 345),
						'z' => array(3),
					),
					array(
						'x' => array(265, 345),
						'z' => array(-28),
					),
					array(
						'x' => array(378, 458),
						'z' => array(-28),
					),
					array(
						'x' => array(378, 458),
						'z' => array(3),
					),
					array(
						'x' => array(377),
						'z' => array(4, 84),
					),
					array(
						'x' => array(346),
						'z' => array(4, 84),
					),
					array(
						'x' => array(377),
						'z' => array(-109, -29),
					),
					array(
						'x' => array(346),
						'z' => array(-109, -29),
					)
				),
				"y" => array(68, 123)
			),
			"spawnPoints" => array(
				array(array(391, 397), array(86, 90)),
				array(array(259, 263), array(17, 23)),
				array(array(326, 332), array(-111, -115)),
				array(array(460, 464), array(-42, -48))
			),
			"spectatorSpawnPoint" => array(
				'x' => 359,
				'y' => 85,
				'z' => -8
			),
			"friendlyName" => "Wild_West"
		),
		"Winter" => array(
			"wallsCoords" => array(
				"xz" => array(
					array(
						'x' => array(396, 476),
						'z' => array(349),
					),
					array(
						'x' => array(396, 476),
						'z' => array(380),
					),
					array(
						'x' => array(283, 363),
						'z' => array(349),
					),
					array(
						'x' => array(283, 363),
						'z' => array(380),
					),
					array(
						'x' => array(364),
						'z' => array(268, 348),
					),
					array(
						'x' => array(395),
						'z' => array(268, 348),
					),
					array(
						'x' => array(364),
						'z' => array(381, 461),
					),
					array(
						'x' => array(395),
						'z' => array(381, 461),
					)
				),
				"y" => array(67, 123)
			),
			"spawnPoints" => array(
				array(array(482, 478), array(329, 335)),
				array(array(409, 415), array(463, 466)),
				array(array(277, 281), array(394, 400)),
				array(array(344, 349), array(262, 266))
			),
			"spectatorSpawnPoint" => array(
				'x' => 381,
				'y' => 70,
				'z' => 364
			),
			"friendlyName" => "Outpost"
		)
	);
	
	/*
     *  List of available items to fill chests
     */
	public $chestItems = array(
	    array(Item::BREAD, 45, true),
	    array(Item::COOKED_PORKCHOP, 60, true),
	    array(Item::COOKED_CHICKEN, 90, true),
	    array(Item::CAKE, 120, false),
	    array(Item::BOWL, 135, true),
	    array(Item::STEAK, 165, true),
	    array(Item::APPLE, 175, true),
	    array(Item::RAW_CHICKEN, 180, true),
	    array(Item::RAW_PORKCHOP, 195, true),
	    array(Item::RAW_BEEF, 210, true),
	    array(Item::RED_MUSHROOM, 225, true),
	    array(Item::BROWN_MUSHROOM, 240, true),
	    array(Item::OBSIDIAN, 250, true),
	    array(Item::CARROT, 255, true),
	    array(Item::POTATO, 270, true),
	    array(Item::BAKED_POTATO, 300, true),
	    array(Item::WOODEN_AXE, 330, false),
	    array(Item::STONE_AXE, 355, false),
	    array(Item::GOLD_AXE, 375, false),
	    array(Item::IRON_AXE, 390, false),
	    array(Item::STICK, 470, false),
	    array(Item::WOODEN_SWORD, 480, false),
	    array(Item::STONE_SWORD, 560, false),
	    array(Item::GOLD_SWORD, 600, false),
	    array(Item::BOW, 610, false),
	    array(Item::FLINT_AND_STEEL, 620, false),
	    array(Item::BUCKET, 630, true),
	    array(Item::ARROW, 640, true),
	    array(Item::IRON_INGOT, 670, true),
	    array(Item::GOLD_INGOT, 690, true),
	    array(Item::DIAMOND, 700, false),
	    array(Item::IRON_HELMET, 718, false),
	    array(Item::IRON_CHESTPLATE, 724, false),
	    array(Item::IRON_LEGGINGS, 736, false),
	    array(Item::IRON_BOOTS, 754, false),
	    array(Item::GOLD_HELMET, 778, false),
	    array(Item::GOLD_CHESTPLATE, 796, false),
	    array(Item::GOLD_LEGGINGS, 814, false),
	    array(Item::GOLD_BOOTS, 838, false),
	    array(Item::LEATHER_CAP, 868, false),
	    array(Item::LEATHER_TUNIC, 892, false),
	    array(Item::LEATHER_PANTS, 916, false),
	    array(Item::LEATHER_BOOTS, 946, false),
	    array(Item::CHAIN_HELMET, 967, false),
	    array(Item::CHAIN_CHESTPLATE, 976, false),
	    array(Item::CHAIN_LEGGINGS, 985, false),
	    array(Item::CHAIN_BOOTS, 1000, false)
	);

}
