<?php

namespace walls\language;

use LbCore\language\core\Spanish as LbSpanish;

/**
 * Contains translated string specifically for Walls game on Spanish
 */
class Spanish extends LbSpanish {

	public function __construct() {
		$this->translates = array_merge($this->translates, array(
			'WALLS_DROPPED' => 'Los muros han caído!',
			'GAME_STARTED' => 'El juego ha comenzado!',
			'TEAM_CHAT_ENABLED' => 'Charla equipo habilitado.',
			'USING_MAP' => 'Utilizando el mapa',
			'DEATHMATCH_STARTED' => 'Deathmatch ha comenzado!',
			'WON_THE_MATCH' => 'ganado el partido.',
			'RETURNING_TO_LOBBY' => 'Volviendo a presionar...',
			'WAS_SLAIN_BY' => 'fue asesinado por',
			'YOU_ALREADY_ON_THE' => 'Usted ya está en el',
			'TEAM' => 'equipo',
			'TEAM_IS_FULL' => 'Ese equipo ya está lleno.',
			'YOU_JOINED_THE' => 'Se unió a la',
			'YOU_NOW_SPECTATING' => 'Batalla en curso. Usted es un espectador ahora.',
			'WILL_JOIN_NEXT' => 'Usted se unirá a la siguiente batalla.',
			'DISCONNECTED' => 'desconectado',
			'HEIGHT_LIMIT_RICHED' => 'Usted ha llegado al límite de altura de construcción.',
			'DONT_BREAK_WALL' => 'No trate de romper el muro.',
			'SECONDS' => 'segundo(s)',
			'STARTING_IN' => 'A partir de',
			'RETURNING_TO_LOBBY_IN' => 'Volviendo a presionar en',
			'WAITING_FOR' => 'Esperando',
			'PLAYERS' => 'jugador(es)',
			'DROP' => 'Soltar',
			'DEATHMATCH' => 'Combate a muerte',
			'END' => 'Fin',
			'LOBBY_TO_RETURN' => 'ejercer presión para volver',
			'RED' => 'ROJO',
			'BLUE' => 'AZUL',
			'GREEN' => 'VERDE',
			'YELLOW' => 'AMARILLO',
			'WALLS_WILL_DROP_IN' => 'Los muros caerán en ',
			'MINUTES' => 'minuto(s)',
			'DEATHMATCH_IN' => 'Deathmatch en ',
			'DEATHMATCH_WILL_END_IN' => 'Deathmatch terminará en ',
			'PLAYERS_ONLINE' => 'Los jugadores en línea',
			'DRAW' => 'dibujar',
            'WAIT_MATCH_ENDS' => 'Por favor, espere hasta que termine la partida actual.'
		));
	}

}
