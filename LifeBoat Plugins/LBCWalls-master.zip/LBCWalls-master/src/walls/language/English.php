<?php

namespace walls\language;

use LbCore\language\core\English as LbEnglish;

/**
 * Contains translated string specifically for Walls game on English
 */
class English extends LbEnglish {

	public function __construct() {
		$this->translates = array_merge($this->translates, array(
			'WALLS_DROPPED' => 'The walls have dropped!',
			'GAME_STARTED' => 'The game has started!',
			'TEAM_CHAT_ENABLED' => 'Team chat enabled.',
			'USING_MAP' => 'Using map',
			'DEATHMATCH_STARTED' => 'Deathmatch has started!',
			'WON_THE_MATCH' => 'won the match.',
			'RETURNING_TO_LOBBY' => 'Returning to lobby...',
			'WAS_SLAIN_BY' => 'was slain by',
			'YOU_ALREADY_ON_THE' => 'You\'re already on the',
			'TEAM' => 'team',
			'TEAM_IS_FULL' => 'That team is already full.',
			'YOU_JOINED_THE' => 'You joined the',
			'YOU_NOW_SPECTATING' => 'Battle in progress. You are a spectator now.',
			'WILL_JOIN_NEXT' => 'You will join the next battle.',
			'DISCONNECTED' => 'disconnected',
			'HEIGHT_LIMIT_RICHED' => 'You\'ve reached the build height limit.',
			'DONT_BREAK_WALL' => 'Don\'t try to break the wall.',
			'SECONDS' => 'second(s)',
			'STARTING_IN' => 'Starting in',
			'RETURNING_TO_LOBBY_IN' => 'Returning to lobby in',
			'WAITING_FOR' => 'Waiting for',
			'PLAYERS' => 'player(s)',
			'DROP' => 'Drop',
			'DEATHMATCH' => 'Deathmatch',
			'END' => 'End',
			'LOBBY_TO_RETURN' => 'lobby to return',
			'RED' => 'RED',
			'BLUE' => 'BLUE',
			'GREEN' => 'GREEN',
			'YELLOW' => 'YELLOW',
			'WALLS_WILL_DROP_IN' => 'The walls will drop in ',
			'MINUTES' => 'minute(s)',
			'DEATHMATCH_IN' => 'Deathmatch in ',
			'DEATHMATCH_WILL_END_IN' => 'Deathmatch will end in ',
			'PLAYERS_ONLINE' => 'Players online',
			'DRAW' => 'Draw',
            'WAIT_MATCH_ENDS' => 'Please wait until the current match ends.'
		));
	}

}
