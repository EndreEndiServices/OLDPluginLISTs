<?php

namespace walls;

use pocketmine\math\Vector3;
use pocketmine\item\Item;
use pocketmine\utils\TextFormat;
use pocketmine\block\Block;

/**
 * Specific handlers for WallsPlayer
 */
class WallsPlayer extends \LbCore\player\LbPlayer {

	/**
     * Specific WallsPlayer properties
     */
	protected $team = ""; // Color of team, which player belongs
	protected $vipKitGiven; // Preset extrakit status, used for vip
	protected $state;
    protected $particleHotbar = [5, 6];

	/**
	 * Give wools to players for changing teams
	 */
	public function setupInventory() {
		$this->getInventory()->clearAll();
		$this->setHotbarItem(1, Item::get(Item::WOOL, 14, 1));
		$this->setHotbarItem(2, Item::get(Item::WOOL, 3, 1));
		$this->setHotbarItem(3, Item::get(Item::WOOL, 13, 1));
		$this->setHotbarItem(4, Item::get(Item::WOOL, 4, 1));
		$this->getInventory()->sendContents($this);
	}

	/**
	 * Teleport players in accordance with team
	 */
	public function teleportByTeam($mapConfig) {
		switch ($this->team) {
			case 'red':
				$this->setNameTag(TextFormat::RED . $this->getName());
				$this->setDisplayName(TextFormat::RED . $this->getName());
				$this->teleport(new Vector3(rand($mapConfig['spawnPoints'][0][0][0], $mapConfig['spawnPoints'][0][0][1]), 71, rand($mapConfig['spawnPoints'][0][1][0], $mapConfig['spawnPoints'][0][1][1])));
				break;
			case 'blue':
				$this->setNameTag(TextFormat::BLUE . $this->getName());
				$this->setDisplayName(TextFormat::BLUE . $this->getName());
				$this->teleport(new Vector3(rand($mapConfig['spawnPoints'][1][0][0], $mapConfig['spawnPoints'][1][0][1]), 71, rand($mapConfig['spawnPoints'][1][1][0], $mapConfig['spawnPoints'][1][1][1])));
				break;
			case 'green':
				$this->setNameTag(TextFormat::GREEN . $this->getName());
				$this->setDisplayName(TextFormat::GREEN . $this->getName());
				$this->teleport(new Vector3(rand($mapConfig['spawnPoints'][2][0][0], $mapConfig['spawnPoints'][2][0][1]), 71, rand($mapConfig['spawnPoints'][2][1][0], $mapConfig['spawnPoints'][2][1][1])));
				break;
			case 'yellow':
				$this->setNameTag(TextFormat::YELLOW . $this->getName());
				$this->setDisplayName(TextFormat::YELLOW . $this->getName());
				$this->teleport(new Vector3(rand($mapConfig['spawnPoints'][3][0][0], $mapConfig['spawnPoints'][3][0][1]), 71, rand($mapConfig['spawnPoints'][3][1][0], $mapConfig['spawnPoints'][3][1][1])));
				break;
		}
        $this->getInventory()->clearAll();
        if($this->isAuthorized()){
            $this->setStateInGame();
        }
        $this->getInventory()->sendContents($this);
	}

	/**
	 * Checks if player try build block higher than a walls
	 */
	public function checkBuildMaxHeight($y, $maxBlockPlaceHeight) {
		if ($y >= $maxBlockPlaceHeight) {
			$this->sendLocalizedMessage('HEIGHT_LIMIT_RICHED', [], TextFormat::BLUE . "- " . TextFormat::RED);
			return false;
		} else {
			return true;
		}
	}

	/**
	 * Checks if player try break wall
	 */
	public function checkWallBlockBreak($blockId) {
		if ($blockId === Block::STAINED_CLAY) {
			$this->sendLocalizedMessage('DONT_BREAK_WALL', [], TextFormat::BLUE . "- " . TextFormat::RED);
			return false;
		} else {
			return true;
		}
	}

	/**
	 * Sets armor for player and put it on at once
	 */
	protected function setArmorItem($index, Item $item) {
		$this->getInventory()->setArmorItem($index, $item);
		$this->getInventory()->sendArmorContents($this);
	}

	/**
	 * Teleports player to the deathmatch arena
	 */
	public function moveToDeathmatch() {
		if ($this->getGamemode() != WallsPlayer::SPECTATOR) {
			$this->noDamageTicks = 20;
            $this->setInDeathmatch(true);
		}
		$this->teleport(new Vector3(rand(-351, -341), 9, rand(385, 395)));

		return true;
	}

	/**
	 * Returns player's team
	 */
	public function getTeam() {
		return $this->team;
	}

	/**
	 * Sets new team to player
	 */
	public function setTeam($team) {
		$this->team = $team;
	}

}
