<?php

namespace walls;

use LbCore\language\Translate;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\TextFormat;
use walls\EventListener;
use walls\GameManager;
use walls\task\WallsTournamentTick;
use Kits\Kit;

/**
 * Walls plugin
 */
class Walls extends PluginBase {

	protected $listener; // Walls Event Listener
	protected $lbcore; // LbComponents
	protected $gameManager; // Walls Game Manager
	public $lang; // LbCore\language\Translate

	/**
	 * Runs when plugin is enabled, base configuration, status messages
	 */
	public function onEnable() {
		$this->lbcore = $this->getServer()->getPluginManager()->getPlugin("LbCore");
		$this->gameManager = new GameManager($this);
		$this->lang = Translate::getInstance();
		$this->lang->createTranslations('walls\\language\\');
		$this->getLogger()->info("Starting Lifeboat Walls Game Server...");
		$this->listener = new EventListener($this, $this->gameManager);
        Kit::enable($this);
        //enable pets
		$this->getServer()->getPluginManager()->registerEvents(new \Pets\PetsManager($this), $this);
		$this->getServer()->getPluginManager()->registerEvents($this->listener, $this);
		$this->getServer()->getScheduler()->scheduleRepeatingTask(new WallsTournamentTick($this, $this->gameManager), 10);
		$this->getServer()->getNetwork()->setName(TextFormat::AQUA . "Life" . TextFormat::RED . "Boat " . TextFormat::BOLD . TextFormat::GOLD . "Walls");
		$this->getLogger()->info("Done!");
	}

	/**
	 * specific Walls commands handling:
	 * /lobby - return from arena to lobby
	 */
	public function onCommand(CommandSender $sender, Command $command, $label, array $args) {
		$name = $command->getName();
		switch ($name) {
			case "lobby":
				$sender->sendLocalizedMessage('RETURNING_TO_LOBBY');
				$this->gameManager->removeFromGame($sender);
				$this->gameManager->returnToLobby($sender);
				break;
		}
		return true;
	}
	
	public function onDisable() {
		
	}

}
