<?php

namespace Spleef;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\server\QueryRegenerateEvent;
use pocketmine\event\player\PlayerCreationEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\player\PlayerChatEvent;
use Spleef\player\CustomPlayer;
use pocketmine\utils\TextFormat;
use pocketmine\block\Block;
use pocketmine\block\TNT;
use pocketmine\level\Explosion;
use pocketmine\math\Vector3;
use Spleef\gadget\Mine;
use LbCore\LbEventListener;
use LbCore\LbCore;
use Spleef\task\GetProductTask;
use pocketmine\event\entity\EntityExplodeEvent;

/**
 * This class handle important for plugin events, 
 * override some of them from LbEventListener (as onPlayerCreation)
 */
class EventListener extends LbEventListener implements Listener {

	private $spPlugin;

	public function __construct($plugin) {
		$this->spPlugin = $plugin;
		parent::__construct($plugin);
	}

	/**
	 * Initialized on player creation, stores new player as CustomPlayer
	 * 
	 * @param PlayerCreationEvent $event
	 */
	public function onPlayerCreation(PlayerCreationEvent $event) {
		$event->setPlayerClass(CustomPlayer::class);
	}

	/**
	 * Initialized on player login, 
	 * set his state as lobby, 
	 * check if player has products
	 * 
	 * @param PlayerLoginEvent $event
	 */
	public function onPlayerLogin(PlayerLoginEvent $event) {
		parent::onPlayerLogin($event);
		$player = $event->getPlayer();
		$player->setStateInLobby();
		$this->spPlugin->getServer()->getScheduler()->scheduleAsyncTask(new GetProductTask($player->getName()));
	}

	/**
	 * Initialized when player join server,
	 * overrides join message,
	 * set default player options and items
	 * 
	 * @param PlayerJoinEvent $event
	 */
	public function onPlayerJoin(PlayerJoinEvent $event) {
		$event->setJoinMessage("");
		$event->getPlayer()->returnToLobby();
	}

	/**
	 * Initialized when player left the server,
	 * delete from game if needs
	 * 
	 * @param PlayerQuitEvent $event
	 */
	public function onPlayerQuit(PlayerQuitEvent $event) {
		$event->setQuitMessage("");
		$player = $event->getPlayer();	
		if ($player->currentGame != null) {
			$player->currentGame->leave($player);
			$player->currentGame = null;
			return;
		}
	}

	/**
	 * Initialized when player respawn 
	 * set default options and items to player,
	 * move him to lobby
	 * 
	 * @param PlayerRespawnEvent $event
	 */
	public function onPlayerRespawn(PlayerRespawnEvent $event) {
		$event->getPlayer()->returnToLobby(true);
	}

	/**
	 * Initialized when player moves
	 * prevent from moving before game starts
	 * 
	 * @param PlayerMoveEvent $event
	 */
	public function onPlayerMove(PlayerMoveEvent $event) {
		$player = $event->getPlayer();
		$player->lastMove = $this->spPlugin->getServer()->getTick();
		if ($player->currentGame !== null) {
			$player->currentGame->onPlayerMove($event);
		}
		//move to lobby spawnpoint
		if ($event->getTo()->getY() <= 15) {
			$area = $player->currentArea;
			if ($area === null) {
				return;
			}
			if ($area === $this->spPlugin->lobbyArea) {
				$event->getPlayer()->teleport(new Vector3($this->spPlugin->lobbyArea->centerX, $this->spPlugin->lobbyArea->y, $this->spPlugin->lobbyArea->centerZ));
			}
		}
	}

	/**
	 * Initialized when player drops item - cancel event
	 * 
	 * @param PlayerDropItemEvent $event
	 */
	public function onDropItem(PlayerDropItemEvent $event) {
		$event->setCancelled(true);
	}

	/**
	 * Sets server name and attributes
	 * 
	 * @param QueryRegenerateEvent $event
	 */
	public function onQuery(QueryRegenerateEvent $event) {
		$server = $this->spPlugin->getServer();
		$event->setServerName('{-name-:-Lifeboat ' . $this->spPlugin->serverGameType . '-,-node-:{-type-:-' . $this->spPlugin->serverGameTypeShort . '-,-ip-:-unknown-,-players-:-' . count($server->getOnlinePlayers()) . '-,-maxplayers-:70,-tps-:' . $server->getTicksPerSecond() .'}}');

		$server->getNetwork()->setName(TextFormat::AQUA . "Life" . TextFormat::RED . "Boat " . TextFormat::BOLD . TextFormat::GOLD . "Spleef");
		$lbcore = LbCore::getInstance();
		if (isset($lbcore->playerCount->sp_players)) {
			$event->setPlayerCount($lbcore->playerCount->sp_players);
		}
		if (isset($lbcore->playerCount->sp_slots)) {
			$event->setMaxPlayerCount($lbcore->playerCount->sp_slots);
		}
	}

	/**
	 * Cancel blockPlace event when player in lobby
	 * 
	 * @param BlockPlaceEvent $event
	 */
	public function onBlockPlace(BlockPlaceEvent $event) {
		if (!$event->getPlayer()->canPlaceBreakBlocks()) {
			$event->setCancelled(true);
			return;
		}
		$area = $event->getPlayer()->currentArea;
		if ($area === null) {
			return;
		}

		if ($area === $this->spPlugin->lobbyArea) {
			$event->setCancelled(true);
		}

		$b = $event->getBlock();

		if ($b->x < $area->centerX - $area->kickSize || $b->z < $area->centerZ - $area->kickSize ||
				$b->x > $area->centerX + $area->kickSize || $b->z > $area->centerZ + $area->kickSize) {
			$event->setCancelled(true);
			$event->getPlayer()->sendLocalizedMessage("PLACE_BLOCK_ERROR", array(), TextFormat::RED);			
			return;
		}
	}

	/**
	 * Initialized when block breaks,
	 * allow to break blocks only on arena,
	 * describes TNT logic (TNT is used on pizza game mode)
	 * 
	 * @param BlockBreakEvent $event
	 */
	public function onBlockBreak(BlockBreakEvent $event) {
		$player = $event->getPlayer();

		if ($player->currentGame == NULL) {
			return;
		}

		if (!$player->currentGame->started || $player->currentGame->countdown > 0) {
			$event->setCancelled(true);	
			return;
		}
		
		$game = $player->currentGame;
		if ($game->area->inArea($event->getBlock()->x, $event->getBlock()->z)) {
			$game->spleefBlockDestroyed($event->getBlock(), $event->getPlayer());
			$game->destroyBlock($event->getBlock()->getLevel(), $event->getBlock());
		}

		//TNT special logic for pizza gamemode
		if ($event->getBlock() instanceof TNT) {
			$this->spPlugin->level->setBlock($event->getBlock(), Block::get(Block::AIR), true);
			$explosion = new Explosion($event->getBlock(), 4);
			$explosion->explodeA();
			$explosion->explodeB();
			$event->setCancelled();
			return;
		}
		
		$event->setCancelled(true);
	}

	/**
	 * Executes when player uses item, mostly about VIP mines (silver carpets)
	 * 
	 * @param PlayerInteractEvent $event
	 */
	public function onUseItem(PlayerInteractEvent $event) {
		$player = $event->getPlayer();		
		$item = $player->getInventory()->getItemInHand();
		//VIP mine (silver carpet) logic
		if ($item->getId() !== Mine::PRODUCT_ID) {
			$game = $player->currentGame;
			if (!is_null($game) && $game->started && $game->countdown <= 0) {
				if ($event->getFace() !== 0xff && $game->area->inArea($event->getBlock()->x, $event->getBlock()->z)) {
					$game->spleefBlockDestroyed($event->getBlock(), $event->getPlayer());
					$game->destroyBlock($event->getBlock()->getLevel(), $event->getBlock());
				}
			}
		}
		//cancel event if needs
		if (!$player->canPlaceBreakBlocks()) {
					$event->setCancelled(true);	
			return;
				}
		if ($event->getFace() === 0xff) {
			return;
			}			
		$b = $event->getBlock();
		$area = $player->currentArea;
		if ($b->x < $area->centerX - $area->kickSize || $b->z < $area->centerZ - $area->kickSize ||
				$b->x > $area->centerX + $area->kickSize || $b->z > $area->centerZ + $area->kickSize) {
			$event->setCancelled(true);
			$event->getPlayer()->sendLocalizedMessage("PLACE_BLOCK_ERROR", array(), TextFormat::RED);			
			return;
		}
	}

	/**
	 * Executes when entity damaged
	 * cancel everything except death by falling from arena
	 * 
	 * @param EntityDamageEvent $event
	 */
	public function onDamage(EntityDamageEvent $event) {
		$player = $event->getEntity();
		if (!$player instanceof CustomPlayer) {
			return;
		}

		if ($event->getCause() == EntityDamageEvent::CAUSE_VOID) {
			if(is_object($player->currentGame)){
				$player->currentGame->playerDied($event->getEntity(), "void");
			}
		}
		$event->setCancelled(true);
	}
	
	/**
	 * Overwrite chat message with yellow nametags
	 * 
	 * @param PlayerChatEvent $event
	 */
	public function onPlayerChat(PlayerChatEvent $event) {
		parent::onPlayerChat($event);
		if ($event->isCancelled()) {
			return;
		}
		$recipients = $event->getRecipients();
		$initiator = $event->getPlayer();		
		if (!($initiator instanceof CustomPlayer)) {
			return;
		}		
		//overwrite chat message
		$event->setCancelled(true);
		$message = $event->getMessage();
		foreach ($recipients as $recipient) {
			$recipient->sendMessage(
					TextFormat::YELLOW . str_replace(TextFormat::WHITE, TextFormat::YELLOW, $initiator->getDisplayName()) 
					. "§b: " . TextFormat::WHITE . $message);
		}
	}

        public function onEntityExplode(EntityExplodeEvent $event){
            $event->setBlockList([]);
        }
}
