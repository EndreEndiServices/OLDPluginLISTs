<?php

namespace Spleef\task;

use pocketmine\utils\Utils;

/**
 * Save new amount of coins for player into db
 */
class AddCoinsTask extends DatabaseTask {

	/** @var int */
	public $coinsNum;

	/**
	 * Class constructor
	 * 
	 * @param $playerName
	 * @param int $coins
	 */
	public function __construct($playerName, $coins) {
		parent::__construct($playerName);
		$this->coinsNum = $coins;
	}

	/**
	 * Updates coins amount for specified player
	 */
	public function onRun() {
		$player = $this->playerName;
		$coins = intval($this->coinsNum);
		Utils::postURL('http://data.lbsg.net/apiv3/database.php', array(
			'auth' => $this->authString,
			'return' => false,
			'cmd' => "UPDATE login SET coins = coins + $coins WHERE username = '$this->dbName'"
				), 5);
	}

}
