<?php

namespace Spleef\task;

use pocketmine\Server;
use pocketmine\utils\Utils;
use Spleef\player\CustomPlayer;

/**
 * Send request to db to remove bought product
 */
class RemoveProductTask extends DatabaseTask {
	/* @var int */
	public $productId;
	/* @var int */
	public $amount;
	/* @var \stdClass*/
	public $virtualProducts;

	/**
	 * Class constructor
	 * 
	 * @param $playerName
	 * @param int $productId
	 * @param int $amount
	 */
	public function __construct($playerName, $productId, $amount = 1) {
		parent::__construct($playerName);

		$this->productId = $productId;
		$this->amount = $amount;
	}

	/**
	 * Removes specified product from bought products collection of current player
	 */
	public function onRun() {
		$player = $this->playerName;

		$result = Utils::postURL('http://data.lbsg.net/apiv3/database.php', array(
					'auth' => $this->authString,
					'return' => true,
					'cmd' => "SELECT virtualProductsBought FROM login WHERE username = '" . $this->dbName . "'"
						), 5);
		if (substr($result, 0, 4) != "fail") {
			$raw_data = json_decode($result, true);
			$virtualProductsStr = $raw_data["virtualProductsBought"];
			$virtualProducts = self::getProductListArray($virtualProductsStr);

			if (isset($virtualProducts[$this->productId])) {
				$virtualProducts[$this->productId] -= $this->amount;
				if ($virtualProducts[$this->productId] === 0) {
					unset($virtualProducts[$this->productId]);
				}
			}

			$this->virtualProducts = (object) $virtualProducts;

			$virtualProductsStr = self::getProductListString($virtualProducts);
			Utils::postURL('http://data.lbsg.net/apiv3/database.php', array(
				'auth' => $this->authString,
				'return' => false,
				'cmd' => "UPDATE login SET virtualProductsBought = '$virtualProductsStr' WHERE username = '$this->dbName'"
					), 5);
		}
	}

	/**
	 * Updates the current player instance after call to remote database. 
	 * Sets updated value to virtualProducts property
	 * 
	 * @param Server $server	 
	 */
	public function onCompletion(Server $server) {
		$player = $server->getPlayer($this->playerName);
		if ($player === null || !($player instanceof CustomPlayer)) {
			return;
		}
		$player->virtualPurchases = $this->virtualProducts;
	}

}
