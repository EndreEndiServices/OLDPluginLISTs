<?php

namespace Spleef\task;

use pocketmine\Server;
use pocketmine\utils\Utils;
use Spleef\player\CustomPlayer;

/**
 * Send request about bought products to db by player name
 * calls when player is logged in
 */
class GetProductTask extends DatabaseTask {
	/* @var \stdClass */
	private $virtualProducts = null;

	/**
	 * Class constructor
	 * 
	 * @param CustomPlayer $player
	 * @param int $coins
	 */
	public function __construct($playerName) {
		parent::__construct($playerName);
	}
	
	/**
	 * Send request
	 */
	public function onRun() {		
		$result = Utils::postURL('http://data.lbsg.net/apiv3/database.php', 
				array(
						'auth' => $this->authString,
						'return' => true,
						'cmd' => "SELECT virtualProductsBought FROM login WHERE username = '" .  $this->dbName . "'"
				), 
			5);
		
		if ($result !== false && !stristr($result, "fail")) {
			$raw_data = json_decode($result, true);
			if(is_array($raw_data) && isset($raw_data["virtualProductsBought"])){
				$virtualProductsStr = $raw_data["virtualProductsBought"];
				$virtualProducts = self::getProductListArray($virtualProductsStr);
				$this->virtualProducts = (object) $virtualProducts;
			}
		}		
	}

	/**
	 * Save collected products in player's data
	 * 
	 * @param Server $server
	 * @return type
	 */
	public function onCompletion(Server $server) {
		$player = $server->getPlayer($this->playerName);
		if ($player === null || !($player instanceof CustomPlayer)) {
			return;
		}
		if(!is_null($this->virtualProducts)){
			$player->virtualPurchases = $this->virtualProducts;	
		}
	}

}
