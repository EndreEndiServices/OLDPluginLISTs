<?php

namespace Spleef\task;

use pocketmine\scheduler\AsyncTask;
use Spleef\DatabaseManager;

/**
 * Common database task, 
 * contains methods to reformat products list as array or string
 */
abstract class DatabaseTask extends AsyncTask {
	/* @var string */
	protected $authString;
	/* @var string */
	protected $playerName;
	/** @var string */
	protected $dbName;

	/**
	 * Class constructor
	 * 
	 * @param $playerName
	 */
	public function __construct($playerName) {
		$this->authString = DatabaseManager::AUTH_STRING;
		$this->playerName = $playerName;
		$this->dbName = str_replace('_', '\_', $this->playerName);
	}

	/**
	 * Converts the products string to products array
	 * 
	 * @param string $str
	 * @return array
	 */
	public static function getProductListArray($str) {
		$arr = [];
		if ($str == "") {
			return $arr;
		}
		foreach (explode(",", $str) as $product) {
			$split = strpos($product, ":");
			if ($split !== false) {
				$prodId = intval(substr($product, 0, $split));
				$prodCount = intval(substr($product, $split + 1));
				$arr[$prodId] = $prodCount;
			} else {
				$arr[intval($product)] = 1;
			}
		}
		return $arr;
	}

	/**
	 * Converts the products array to products string
	 * 
	 * @param array $arr
	 * @return string
	 */
	public static function getProductListString($arr) {
		$str = "";
		$first = true;
		foreach ($arr as $id => $count) {
			if ($first) {
				$first = false;
			} else {
				$str .= ",";
			}
			$str .= $id . ":" . $count;
		}
		return $str;
	}

}
