<?php

namespace Spleef\task;

use pocketmine\Server;
use pocketmine\utils\Utils;
use Spleef\player\CustomPlayer;
use pocketmine\utils\TextFormat;
use Spleef\Plugin;

/**
 * This task controls product buy:
 * - check for enough coins,
 * - check for new purchase,
 * - save bought into db,
 * - update player options and amount of coins
 */
class AddProductTask extends DatabaseTask {
	/* @var bool */
	private $buy;
	/* @var int */
	private $productId;
	/* @var string */
	private $productName;
	/* @var bool */
	private $single;
	/* @var int */
	private $amount;
	/* @var int */
	private $coins;
	/* @var \stdClass */
	private $virtualProducts = null;
	/* @var bool */
	private $alreadyOwned = false;
	/* @var bool */
	private $notEnoughCoins = false;

	/**
	 * Class constructor
	 * 
	 * @param $playerName
	 * @param bool $buy
	 * @param int $productId
	 * @param int $amount
	 */
	public function __construct($playerName, $buy, $productId, $amount = 1) {
		parent::__construct($playerName);
		$this->buy = $buy;
		$this->productId = $productId;
		$this->amount = $amount;
	}

	/**
	 * Checks if specified player has enough coins to buy the product.
	 * Checks if product has been bought by specified player. 
	 * Buy pruduct when player have enough coins and the same product was not bought before.
	 */
	public function onRun() {
		$player = $this->playerName;
		//get db result
		$result = Utils::postURL('http://data.lbsg.net/apiv3/database.php', array(
					'auth' => $this->authString,
					'return' => true,
					'cmd' => "SELECT title,single,price FROM virtual_products WHERE ID = " . $this->productId
						), 5);

		if (substr($result, 0, 4) != "fail") {
			//prepare product options, name, cost
			$raw_data = json_decode($result, true);
			$price = intval($raw_data["price"]) * $this->amount;
			$single = $raw_data["single"];
			$this->single = $single;
			$title = $raw_data["title"];
			$this->productName = str_replace("&", "§", $title);

			$result = Utils::postURL('http://data.lbsg.net/apiv3/database.php', array(
						'auth' => $this->authString,
						'return' => true,
						'cmd' => "SELECT coins,virtualProductsBought FROM login WHERE username = '" . $this->dbName . "'"
							), 5);
			if (substr($result, 0, 4) != "fail") {
				//prepare player coins to buy
				$raw_data = json_decode($result, true);
				$coins = $raw_data["coins"];
				$this->coins = $coins;
				$virtualProductsStr = $raw_data["virtualProductsBought"];
				$virtualProducts = self::getProductListArray($virtualProductsStr);
				$this->virtualProducts = (object) $virtualProducts;
				$owned = 0;
				if (isset($virtualProducts[$this->productId])) {
					if ($single) {
						$this->alreadyOwned = true;
						return;
					}
					$owned = $virtualProducts[$this->productId];
				}
				//not enough money
				if ($this->buy && $coins < $price) {
					$this->notEnoughCoins = true;
					return;
				}
				//decrease coins
				$virtualProducts[$this->productId] = $owned + $this->amount;
				$this->virtualProducts = (object) $virtualProducts;
				if ($this->buy) {
					$this->coins -= $price;
				}
				
				$virtualProductsStr = self::getProductListString($virtualProducts);
				//save bought products and new amount of coins (if needs) in db
				if ($this->buy) {
					Utils::postURL('http://data.lbsg.net/apiv3/database.php', array(
						'auth' => $this->authString,
						'return' => false,
						'cmd' => "UPDATE login SET coins = coins - $price, virtualProductsBought = '$virtualProductsStr' WHERE username = '$this->dbName'"
							), 5);
				} else {
					Utils::postURL('http://data.lbsg.net/apiv3/database.php', array(
						'auth' => $this->authString,
						'return' => false,
						'cmd' => "UPDATE login SET virtualProductsBought = '$virtualProductsStr' WHERE username = '$this->dbName'"
							), 5);
				}
			}
		}
	}

	/**
	 * Update the current player instance. Set new values for 'coins'
	 * and 'virtualPurchases' properties after purchase.
	 * 
	 * @param Server $server	 
	 */
	public function onCompletion(Server $server) {
		$player = $server->getPlayer($this->playerName);
		if ($player === null || !($player instanceof CustomPlayer)) {
			return;
		}
		$player->coinsNum = $this->coins;
		$player->virtualPurchases = $this->virtualProducts;

		if (!$this->buy) {
			return;
		}
		$player->hasPurchaseTask = false;
		//send suitable messages
		if (!$this->alreadyOwned && !$this->notEnoughCoins) {
			if ($this->single) {
				$player->sendMessage($player->getTranslatedString("PURCHASED_ITEM") . TextFormat::BOLD . $this->productName . TextFormat::RESET . TextFormat::GREEN . "!");
				$player->sendPopup($player->getTranslatedString("PURCHASED_ITEM") . TextFormat::BOLD . $this->productName . TextFormat::RESET . TextFormat::GREEN . "!");
			}
		} else {
			if ($this->notEnoughCoins) {
				$player->sendMessage($player->getTranslatedString("ERROR_PREFIX", TextFormat::RED) . $player->getTranslatedString("ERR_INSUFFICENT_COINS"));
				$player->sendPopup($player->getTranslatedString("ERR_INSUFFICENT_COINS"));
			} else {
				$player->sendMessage($player->getTranslatedString("ERROR_PREFIX", TextFormat::RED) . $player->getTranslatedString("ALREADY_PURCHASED"));
				$player->sendPopup($player->getTranslatedString("ALREADY_PURCHASED"));
			}
		}
	}

}
