<?php


namespace Spleef\language;

use pocketmine\utils\TextFormat;
use LbCore\language\Translate;
use LbCore\language\core\Dutch as LbDutch;

class Dutch extends LbDutch {
	
	/**
	 * Merge LbCore base translations with custom plugin translates
	 */
	public function __construct() {
		$this->translates = array_merge($this->translates, $this->spTranslates);
	}

	private  $spTranslates = array(
		"ERROR_PREFIX" => "Fout> ",
		"GAME_PREFIX" => "Spel> ",
		"STOP_PREFIX" => "Stop> ",	 
		"CHAT_PREFIX" => "Babbelen> ",
		"JOIN_PREFIX" => "Toetreden> ",
		"QUIT_PREFIX" => "Verlaten> ",
		"KIT_PREFIX" => "Uitrusting> ",
		"WARNING_PREFIX" => TextFormat::RED . "Waarschuwing> ",
		"PUNISH_PREFIX" => "Straffen> ",
//		"CURRENT_GAME" => "U bent momenteel op: ",
//		"PLAYER_NOT_FOUND" => "Kan de speler niet vinden: ",
//		"COMMAND_IN_GAME" => "U moet deze opdracht in-game run",
//		"STARTING_GAME" => "Starten...",	
//		"WHITE" => "Whitelist:",
		"WELCOME_TO_LIFEBOAT" => TextFormat::GREEN . "Welkom bij reddingsboot arg1!",
		"PURCHASED_ITEM" => TextFormat::GREEN . "Aankoop> U hebt gekocht van de ",
		"ALREADY_PURCHASED" => TextFormat::RED . "U hebt gekocht heeft u dit item!",
		"GADGET_FOR_VIP" => "Dit artikel is alleen beschikbaar voor VIP's.",
		"WAITING" => "Wacht alstublieft...",
		"NOT_PURCHASED_ITEM" => TextFormat::RED . "U hebt gekocht nog niet dit item!\n" 
								. TextFormat::GRAY . "Om dit voorwerp te kopen, tik er opnieuw.",
		"PREP_FOR" => " for ", 
//		"COINS" => " coins",
		"CAN_BUY" => "Je hebt geen arg1!\n U kunt arg2 kopen " 
					. TextFormat::YELLOW . " voor arg3 coins\n" 
					. TextFormat::YELLOW . "door nogmaals op het scherm.",
		"SEND_POTATO" => "Je potatoed ",
		"GET_POTATO" => "Je hebt potatoed door ",
//		"NOT_WHITE_ERROR" => "U bent niet whitelist op deze server!",
//		"BANNED_ERROR" => "Je bent verbannen van deze server!",
		"IS_SPECTATOR" => "Je bent een toeschouwer.",
		"GAME_IN_PROGRESS" => "Dit spel is in volle gang.",
		"PLAYER_LIMIT_ERROR" => "Dit spel heeft bereikt is het maximum aantal spelers.",
		"NO_START_POSITION" => "Kan het niet vinden uitgangspositie!",
		"PLAYER_WAIT" => TextFormat::YELLOW . "Wachtend op spelers...",
		"YOU_WON" => "Je hebt het spel gewonnen!",
		"GAME_RESULTS" => Translate::PREFIX_SYSTEM_MESSAGE . "Resultaten:",
		"YOU_DIED" => TextFormat::RED . "Je stierf!",
		"TOTAL_RESULT" => "Totaal: ",
//		"WAS_KILLED" =>  " werd gedood",
		"PLAYER_WON" => "arg1 heeft een arg2 gewonnen!",
		"GAME_STARTED_BY" => "Game> Game werd gestart door arg1",
		"GAME_WAS_STARTED" => "Game> spel werd gestart.",
		"PLAYER_WAS_KILLED" => TextFormat::RED . "arg1 werd gedood door arg2",
		"START_POSITION_ERROR" => "Kan uw uitgangspositie niet te vinden!",
		"GAME_STARTED_GOOD_LUCK" => "Game> Het spel is begonnen! Veel geluk!",
		"STARTING_GAME_COUNTDOWN" => "Vanaf arg1 seconden...",
		"NO_GAME" => "Spel arg1 bestaat niet!",
		"ON_GAME" => "U bent al op arg1!",
		"IN_GAME" => "U bent nu in: arg1",

		"SPOON_ITEM" => "Lepel",
		"JUMP_BONUS" => "U kunt hoger te springen voor de komende 10 seconden!",
		"NAUSE_BONUS" => "Iedereen is misselijk gedurende 10 seconden!",
		"SHOVEL_ITEM" => "Spleef Shovel",
		"PIZZA_CUTTER" => "Pizza Cutter",
		"PEPPERONI_ITEM" => TextFormat::RED . TextFormat::BOLD . "Peperoni!" 
							. TextFormat::RESET . TextFormat::RED . TextFormat::ITALIC 
							. " U bent sneller voor de volgende 5 seconden!",
		"PEPPER_ITEM" => TextFormat::GREEN . TextFormat::BOLD . "Paprika!",		
		"ONION_ITEM" =>TextFormat::LIGHT_PURPLE . TextFormat::BOLD . "Ui",
		"GARLIC_ITEM" => TextFormat::WHITE . TextFormat::BOLD . "Knoflook!" 
						. TextFormat::RESET . TextFormat::WHITE . TextFormat::ITALIC 
						. " Je bent onzichtbaar voor de komende 10 seconden!",
		"SAUSAGE_ITEM" => TextFormat::RED . TextFormat::BOLD . "Worst!" 
						. TextFormat::RESET . TextFormat::RED . TextFormat::ITALIC 
						. " U ontvangt 3 explosieven!",
		"OLIVE_ITEM" =>  TextFormat::RED . TextFormat::BOLD . "Olijf!" 
						. TextFormat::RESET . TextFormat::RED . TextFormat::ITALIC 
						. " U ontvangt 3 langzaam bommen!",
		"BOMB_WORKS" => "Je vertraagd arg1 spelers 5 seconden!",
		"JUST_COINS" => " munten",
		"ACC_NOT_REGISTERED" => Translate::PREFIX_SYSTEM_MESSAGE . "Dit account is niet geregistreerd.",
		"PLACE_BLOCK_ERROR" => "Je kunt hier geen blokken te plaatsen.",
//		"BREAK_BLOCK_ERROR" => "Je kunt hier geen blokken breken.",
		"YOU_TELEPORTED" =>  "Je werd geteleporteerd naar: ",
		"BASE_ERROR" => "Er is een fout opgetreden."
	);
	
}
