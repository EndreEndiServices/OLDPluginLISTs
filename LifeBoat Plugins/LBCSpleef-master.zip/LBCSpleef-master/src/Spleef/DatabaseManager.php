<?php

namespace Spleef;

use Spleef\player\CustomPlayer;
use Spleef\Plugin;
use Spleef\task\AddProductTask;
use Spleef\task\AddCoinsTask;
use Spleef\task\RemoveProductTask;

/**
 * DatabaseManager send shopping tasks to db:
 * - handle coins balance,
 * - buy and remove products
 */
class DatabaseManager {

	const AUTH_STRING = 'bjPzxd84W99s3gsy5kX2f9Ww';

	private $plugin;

	public function __construct(Plugin $plugin) {
		$this->plugin = $plugin;
	}

	/**
	 * Adds coins to player
	 * 
	 * @param CustomPlayer $player
	 * @param int $amount
	 */
	public function addCoins(CustomPlayer $player, $amount) {
		//$this->plugin->getServer()->getScheduler()->scheduleAsyncTask(new AddCoinsTask($player->getName(), $amount));
	}

	/**
	 * Removes product from player
	 * 
	 * @param CustomPlayer $player
	 * @param int $productId
	 * @param int $amount
	 */
	public function removeProduct(CustomPlayer $player, $productId, $amount) {
		$this->plugin->getServer()->getScheduler()->scheduleAsyncTask(new RemoveProductTask($player->getName(), $productId, $amount));
	}

	/**
	 * Adds product to player (with decrease of player's coins)
	 * 
	 * @param CustomPlayer $player
	 * @param int $productId
	 * @param int $amount
	 */
	public function buyProduct(CustomPlayer $player, $productId, $amount) {
		$this->plugin->getServer()->getScheduler()->scheduleAsyncTask(new AddProductTask($player->getName(), true, $productId, $amount));
	}

}
