<?php

namespace Spleef\gadget;

use pocketmine\entity\Effect;
use pocketmine\entity\Entity;
use pocketmine\network\protocol\StartGamePacket;
use pocketmine\utils\TextFormat;
use pocketmine\utils\Utils;
use Spleef\player\CustomPlayer;
use Spleef\Plugin;
use pocketmine\item\Item;
use Spleef\gadget\NamedItem;
use Spleef\DatabaseManager;
use Spleef\gadget\ReturnToLobbyActionItem;

/**
 * Manages the gadgets
 *
 */
class GadgetManager {

	/** @var Plugin */
	private $plugin;
	private $gadgets = [];
	private $items = [];
	public static $morphProductIds = [
		15 => 10,
		10 => 3,
		14 => 4,
		38 => 5,
		36 => 6,
		33 => 11
	];
	public static $productNames = [];
	public static $productPrices = [];
	private static $mobHeights = [
		15 => 1.8,
		10 => 0.7,
		14 => 0.8,
		38 => 2.9,
		36 => 1.8,
		33 => 1.8
	];

	/**
	 * Base manager constructor, prepare list of available gadget objects
	 * 
	 * @param Plugin $plugin
	 */
	public function __construct(Plugin $plugin) {
		$this->plugin = $plugin;

		array_push($this->gadgets, new PotatoGun($plugin));
		array_push($this->gadgets, new TNTGadget($plugin));
		array_push($this->gadgets, new CoinBombGadget($plugin));
		array_push($this->gadgets, new Mine($plugin));

		$this->items[1] = new GadgetItem(Item::POTATO, 0, 1, PotatoGun::PRODUCT_ID, "Potato", TextFormat::GOLD);
		$this->items[2] = new GadgetItem(Item::TNT, 0, 1, TNTGadget::PRODUCT_ID, "TNT", TextFormat::RED);

		$this->items[10] = Item::get(Item::SPAWN_EGG, 15); // villager morph
		$this->items[11] = Item::get(Item::SPAWN_EGG, 10); // chicken morph
		$this->items[12] = Item::get(Item::SPAWN_EGG, 14); // wolf morph
		$this->items[13] = Item::get(Item::SPAWN_EGG, 38); // enderman morph
		$this->items[14] = Item::get(Item::SPAWN_EGG, 36); // zombie pigman morph
		$this->items[15] = Item::get(Item::SPAWN_EGG, 33); // creeper morph

		$products = array_merge(self::$morphProductIds, 
					[PotatoGun::PRODUCT_ID, 
					TNTGadget::PRODUCT_ID]);
		$iterator = 0;
		while ($iterator < 5) {
			$iterator++;
			$result = Utils::postURL('http://data.lbsg.net/apiv3/database2.php', array(
						'auth' => DatabaseManager::AUTH_STRING,
						'return' => true,
						'cmd' => "SELECT id,title,price FROM virtual_products WHERE id IN (" . implode(",", $products) . ")"
							), 1);
			if ($result && !stristr($result, "fail")) {
				$raw_data = json_decode($result, true);
				if ($raw_data && is_array($raw_data)) {
					foreach ($raw_data as $row) {
						self::$productPrices[$row["id"]] = intval($row["price"]);
						self::$productNames[$row["id"]] = str_replace("&", "§", $row["title"]);
					}
					break;
				}
			}
		}
	}

	/**
	 * Adds gadgets to inventory
	 * 
	 * @param CustomPlayer $player
	 */
	public function addGadgetsToInv(CustomPlayer $player) {
		$player->clearHotbar();
		foreach ($this->items as $id => $item) {
				$player->getInventory()->setItem($id, $item);
		}
		$player->getInventory()->setHotbarSlotIndex(1, 1);
		$player->getInventory()->setHotbarSlotIndex(2, 2);
		$player->getInventory()->setHeldItemIndex(0);
		$player->getInventory()->sendContents($player);
	}

	/**
	 * Returns true if player has bought this item or if player is VIP
	 * 
	 * @param CustomPlayer $player
	 * @param int $prodId
	 * @return boolean
	 */
	private function checkItem(CustomPlayer $player, $prodId) {
		if (!$player->hasBought($prodId)) {
			if (isset(self::$productPrices[$prodId]) && self::$productPrices[$prodId] <= 0) {
				if ($player->isVip()) {
					return true;
				}
				$player->sendPopup($player->getTranslatedString("GADGET_FOR_VIP", TextFormat::RED));
				return false;
			}

			if ($player->buyingItem === $prodId) {
				$player->sendPopup($player->getTranslatedString("WAITING", TextFormat::YELLOW));
				$player->buyProduct($prodId);
				$player->buyingItem = null;
				return false;
			}

			$name = "Unknown";
			$price = 0;

			if (isset(self::$productNames[$prodId])) {
				$name = self::$productNames[$prodId];
			}
			if (isset(self::$productPrices[$prodId])) {
				$price = self::$productPrices[$prodId];
			}
			$lines = TextFormat::GREEN . TextFormat::BOLD . $name . " " . TextFormat::RESET . TextFormat::GOLD . "[" . $price . " coins]" . TextFormat::RESET . "\n" . $player->getTranslatedString("NOT_PURCHASED_ITEM");
			$player->sendPopup($lines);
			$player->buyingItem = $prodId;
			return false;
		}
		$player->sendPopup(TextFormat::GREEN . TextFormat::BOLD . self::$productNames[$prodId]);
		return true;
	}
        
        /**
	 * Calls when player check item from inventory - set effects and other options
	 * 
	 * @param PlayerItemHeldEvent $event
	 * @return void
	 */
	public function switchItem(PlayerItemHeldEvent $event) {
		/** @var CustomPlayer $player */
		$player = $event->getPlayer();

		if (!$player->isAuthorized()) {
			$player->sendTip($player->getTranslatedString("NEEDS_LOGIN", TextFormat::RED));
			return;
		}
		//check if player is in lobby
		if ($player->currentArea === $this->plugin->lobbyArea) {
			if ($event->getInventorySlot() === $event->getPlayer()->getInventory()->getHeldItemSlot() &&
					$event->getItem()->getId() !== 0) {
				$player->buyingItem = -1;
				return;
			}

			$event->setCancelled(true);
			if ($event->getItem()->getId() === Item::SPAWN_EGG) {
				// morph effects
				$type = $event->getItem()->getDamage();

				$prodId = self::$morphProductIds[$type];
				if ($this->checkItem($player, $prodId)) {
					if ($player->getAllowFlight()) {
						$spawnPosition = $player->getSpawn();
						$pk = new StartGamePacket();
						$pk->seed = -1;
						$pk->x = $player->x;
						$pk->y = $player->y;
						$pk->z = $player->z;
						$pk->spawnX = (int) $spawnPosition->x;
						$pk->spawnY = (int) $spawnPosition->y;
						$pk->spawnZ = (int) $spawnPosition->z;
						$pk->generator = 1;
						$pk->gamemode = $player->gamemode & 0x01;
						$pk->eid = $player->getId();
						$player->dataPacket($pk);
					}

					$meta = [];

					if ($event->getPlayer()->getName() == "Sean_M") {
						$meta[12] = [Entity::DATA_TYPE_BYTE, 1];
					}
					if ($type != 10) { // chicken should have ai
						$meta[Entity::DATA_NO_AI] = [Entity::DATA_TYPE_BYTE, 1];
					}
					$player->morphInto($type, $meta, self::$mobHeights[$type]);
					$player->getInventory()->setItem($player->getInventory()->getSize() - 1, Item::get(Item::AIR));
					$player->removeAllEffects();
					$player->setAllowFlight(false);
					$player->setAutoJump(true);
					$this->applyEffects($player);
				}
			}
		}
	}

	// used for potatoes and TNT
	/**
	 * Handles buying item by player
	 * 
	 * @param CustomPlayer $player
	 * @param int $prodId
	 * @param int $amount
	 */
	public static function buyGadget(CustomPlayer $player, $prodId, $amount) {
		if ($player->buyingItem === $prodId) {
			$player->buyProduct($prodId, $amount);
			$player->buyingItem = -1;
		} elseif(isset(self::$productNames[$prodId]) && isset(self::$productPrices[$prodId])) {
			$buyDetails = array(self::$productNames[$prodId], ($amount . " " . self::$productNames[$prodId]), (self::$productPrices[$prodId] * $amount));
			$player->sendMessage($player->getTranslatedString("CAN_BUY", "", $buyDetails));
			$player->buyingItem = $prodId;
		}
	}

	/**
	 * Check if helditem is overriden by plugin class NamedItem
	 * 
	 * @param type $event
	 * @return type
	 */
	public function checkUseNamedItem($event) {
		$itm = $event->getItem();
		$player = $event->getPlayer();
		if ($event->getInventorySlot() === $player->getInventory()->getHeldItemSlot()) {
			if ($event->getSlot() === $player->previousHeldSlot) {
				return;
			}
			$player->previousHeldSlot = $event->getSlot();
		} else if ($event->getItem() instanceof NamedItem) {
			$event->setCancelled(true);
			return;
		}

		if ($itm instanceof NamedItem) {
			$itm->selected($player);
		} else {
			$hid = $player->getInventory()->getHeldItemIndex();
			if (isset($player->hotbarItems[$hid])) {
				$hitm = $player->hotbarItems[$hid];
				if ($hitm->getId() === $itm->getId() && $hitm instanceof NamedItem) {
					$hitm->selected($player);
				}
			}
		}
	}

	/**
	 * Check for using additional (gadget) item, call apply effects
	 * 
	 * @param type $event
	 * @return type
	 */
	public function checkAdditionalItem($event) {
		$player = $event->getPlayer();

		if (!$player->isAuthorized()) {
			$player->sendTip($player->getTranslatedString("NEEDS_LOGIN", TextFormat::RED));
			return;
		}

		if ($player->currentArea === $this->plugin->lobbyArea) {
			if ($event->getInventorySlot() === $event->getPlayer()->getInventory()->getHeldItemSlot() &&
					$event->getItem()->getId() !== 0) {
				$player->buyingItem = -1;
				return;
			}
			$event->setCancelled(true);
			if($event->getItem() instanceof ReturnToLobbyActionItem){
				return;
			}
			if ($event->getItem()->getId() === Item::SPAWN_EGG) {
				$type = $event->getItem()->getDamage();

				$prodId = self::$morphProductIds[$type];

				if ($this->checkItem($player, $prodId)) {
					if ($player->getAllowFlight()) {
						$spawnPosition = $player->getSpawn();
						$pk = new StartGamePacket();
						$pk->seed = -1;
						$pk->x = $player->x;
						$pk->y = $player->y;
						$pk->z = $player->z;
						$pk->spawnX = (int) $spawnPosition->x;
						$pk->spawnY = (int) $spawnPosition->y;
						$pk->spawnZ = (int) $spawnPosition->z;
						$pk->generator = 1;
						$pk->gamemode = $player->gamemode & 0x01;
						$pk->eid = $player->getId();
						$player->dataPacket($pk);
					}

					$meta = [];

					if ($event->getPlayer()->getName() == "Sean_M") {
						$meta[12] = [Entity::DATA_TYPE_BYTE, 1];
					}

					if ($type != 10) { // chicken should have ai
						$meta[Entity::DATA_NO_AI] = [Entity::DATA_TYPE_BYTE, 1];
					}

					$player->morphInto($type, $meta, self::$mobHeights[$type]);
					$player->getInventory()->setItem($player->getInventory()->getSize() - 1, Item::get(Item::AIR));
					$player->removeAllEffects();
					$player->setAllowFlight(false);
					$player->setAutoJump(true);
					$this->applyEffects($player);
				}
			}
		}
	}

	/**
	 * Adds effects related to specified spawn egg
	 * 
	 * @param CustomPlayer $player
	 */
	public function applyEffects(CustomPlayer $player) {
		$player->addEffect(Effect::getEffect(Effect::SPEED)->setVisible(false)->setAmplifier(0.5)->setDuration(0x7fffffff));

		if ($player->morphedInto === 14) { // wolf
			$player->addEffect(Effect::getEffect(Effect::SPEED)->setVisible(false)->setAmplifier(0.8)->setDuration(0x7fffffff));
			$player->addEffect(Effect::getEffect(Effect::JUMP)->setVisible(false)->setAmplifier(0)->setDuration(0x7fffffff));
		}
		if ($player->morphedInto === 10) { // chicken
			$player->addEffect(Effect::getEffect(Effect::JUMP)->setVisible(false)->setAmplifier(3)->setDuration(0x7fffffff));
			$player->setAllowFlight(true);
			$player->setAutoJump(false);
		}
		if ($player->morphedInto === 15) { // villager
			$player->getInventory()->setItem($player->getInventory()->getSize() - 1, new CoinBombItem());
		}
		if ($player->morphedInto === 38) { // enderman
			$player->getInventory()->setItem($player->getInventory()->getSize() - 1, new TeleportItem());
		}
		if ($player->morphedInto === 33) { // creeper
			$player->getInventory()->setItem($player->getInventory()->getSize() - 1, new ExplodeItem());
		}
		if ($player->morphedInto === 36) { // zombie pigman
			$player->addEffect(Effect::getEffect(Effect::SPEED)->setVisible(false)->setAmplifier(1)->setDuration(0x7fffffff));

			if ($player->getName() == "Sean_M") {
				$player->addEffect(Effect::getEffect(Effect::SPEED)->setVisible(false)->setAmplifier(1.5)->setDuration(0x7fffffff));
			}
		}
	}

}
