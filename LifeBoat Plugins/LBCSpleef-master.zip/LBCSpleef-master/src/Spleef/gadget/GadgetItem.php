<?php

namespace Spleef\gadget;

use Spleef\player\CustomPlayer;

/** Explains behavior of gadget item */
class GadgetItem extends NamedItem {

	/** @var string */
	private $color;
	/** @var int */
	private $prodId;

	/**
	 * Base constructor for all gadget items such as coin bomb, potato gun, teleport etc
	 * 
	 * @param int $id
	 * @param type $meta
	 * @param int $count
	 * @param int $prodId
	 * @param string $name
	 * @param string $color
	 */
	public function __construct($id, $meta, $count, $prodId, $name, $color = "") {
		parent::__construct($id, $meta, $count, $name);
		$this->prodId = $prodId;
		$this->color = $color;
	}

	/**
	 * Sends message with amount of specified product to player
	 * 
	 * @param CustomPlayer $player
	 */
	public function selected(CustomPlayer $player) {
		$player->sendPopup($this->color . $player->getProductAmount($this->prodId) . " " . $this->name);
	}

}
