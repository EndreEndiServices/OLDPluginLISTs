<?php

namespace Spleef\gadget;

use pocketmine\item\Item;
use Spleef\player\CustomPlayer;

/** Extends class Item */
class NamedItem extends Item {

	/**
	 * Base class constructor
	 * 
	 * @param int $id
	 * @param type $meta
	 * @param int $count
	 * @param string $name
	 */
	public function __construct($id, $meta, $count, $name) {
		parent::__construct($id, $meta, $count, $name);
		$this->name = $name;
	}

	/**
	 * Shows message with selected item's name
	 * 
	 * @param CustomPlayer $player
	 */
	public function selected(CustomPlayer $player) {
		$player->sendPopup($this->name);
	}

}
