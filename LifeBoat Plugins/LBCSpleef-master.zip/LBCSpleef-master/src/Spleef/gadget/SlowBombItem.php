<?php

namespace Spleef\gadget;

use pocketmine\entity\Effect;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\utils\TextFormat;
use Spleef\player\CustomPlayer;

/** This class manages Slow Bomb Item */
class SlowBombItem extends ActionItem {

	public $slot;

	/**
	 * Base constructor, set bomb (emerald) to specified slot
	 * 
	 * @param type $slot
	 * @param int $count
	 */
	public function __construct($slot, $count) {
		$this->slot = $slot;
		parent::__construct(Item::EMERALD, 0, $count, TextFormat::RED . "Slow Bomb", "Tap again to drop a slow bomb");
	}

	/**
	 * Manages the item use by specified player
	 * 
	 * @param CustomPlayer $player
	 */
	public function useItem(CustomPlayer $player) {
		parent::useItem($player);

		$affected = 0;
		$entities = $player->getLevel()->getNearbyEntities($player->getBoundingBox()->grow(2, 2, 2), $player);
		foreach ($entities as $entity) {
			if ($entity instanceof Player) {
				$affected++;
				$entity->addEffect(Effect::getEffect(Effect::SLOWNESS)->setAmplifier(1)->setDuration(20 * 5)->setVisible(false));
			}
		}

		$this->setCount($this->count - 1);
		$player->getInventory()->setItem($this->slot, $this);

		$player->sendMessage($player->getTranslatedString("BOMB_WORKS", TextFormat::RED, array($affected)));
	}

}
