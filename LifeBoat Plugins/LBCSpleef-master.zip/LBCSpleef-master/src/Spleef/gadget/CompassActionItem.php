<?php

namespace Spleef\gadget;

use pocketmine\item\Item;
use pocketmine\utils\TextFormat;
use Spleef\player\CustomPlayer;

/** This class describes the behavior of compass item */
class CompassActionItem extends ActionItem {

	public function __construct() {
		parent::__construct(Item::COMPASS, 0, 1, TextFormat::GREEN . "Compass", "Tap again to teleport to nearest player");
	}

	/**
	 * Teleports player 
	 * 
	 * @param CustomPlayer $player
	 */
	public function useItem(CustomPlayer $player) {
		$game = $player->currentGame;
		$tpPlayer = null;
		$tpDist = -1;
		foreach ($game->players as $p) {
			$d = $p->distance($player);
			if ($tpDist === -1 || $tpDist > $d) {
				$tpPlayer = $p;
				$tpDist = $d;
			}
		}
		if ($tpPlayer !== null) {
			$player->teleport($tpPlayer);
			$player->sendPopup($player->getTranslatedString("YOU_TELEPORTED", TextFormat::GREEN) . TextFormat::BOLD . $tpPlayer->getName());
		} else {
			$player->sendPopup($player->getTranslatedString("BASE_ERROR", TextFormat::RED));
		}
	}

}
