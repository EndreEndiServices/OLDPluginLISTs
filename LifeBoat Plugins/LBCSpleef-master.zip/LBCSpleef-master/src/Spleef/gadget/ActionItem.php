<?php

namespace Spleef\gadget;

use pocketmine\utils\TextFormat;
use Spleef\player\CustomPlayer;

/**
 * This is the base class for an action item.
 *
 * An action item is an item that can be touched twice (in hotbar or inventory) to execute an action.
 */
class ActionItem extends NamedItem {

	/** @var string */
	private $tip;

	/**
	 * 
	 * @param int $id
	 * @param type $meta
	 * @param int $count
	 * @param type $name
	 * @param string $tip
	 */
	public function __construct($id, $meta, $count, $name, $tip = "Tap again to use") {
		parent::__construct($id, $meta, $count, $name);
		$this->tip = $tip;
	}

	/**
	 * If item is not in action sends message with item tips and makes it activated
	 * 
	 * @param CustomPlayer $player
	 */
	public function selected(CustomPlayer $player) {
		if ($player->actionItem == $this) {
			$this->useItem($player);
			$player->actionItem = null;
		} else {
			$player->sendPopup(TextFormat::BOLD . $this->name . TextFormat::RESET . "\n" . TextFormat::GRAY . $this->tip);
			$player->actionItem = $this;
		}
		$player->getInventory()->setHeldItemIndex($player->getEmptyHotbarSlot());
		$player->previousHeldSlot = -1;
	}

	/**
	 * Sends message with item name
	 * 
	 * @param CustomPlayer $player
	 */
	public function useItem(CustomPlayer $player) {
		$player->sendPopup(TextFormat::BOLD . $this->name);
	}

}
