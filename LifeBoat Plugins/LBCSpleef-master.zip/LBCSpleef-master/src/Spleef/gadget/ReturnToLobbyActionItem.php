<?php

namespace Spleef\gadget;

use pocketmine\item\Item;
use pocketmine\utils\TextFormat;
use Spleef\player\CustomPlayer;

/** This class describes the behavior of return to lobby action */
class ReturnToLobbyActionItem extends ActionItem {

	public function __construct() {
		parent::__construct(Item::END_PORTAL, 0, 1, TextFormat::GOLD . "Return to lobby", "Tap again to return to lobby");
	}

	/**
	 * Returns player to lobby
	 * 
	 * @param CustomPlayer $player
	 */
	public function useItem(CustomPlayer $player) {
		parent::useItem($player);
		$player->returnToLobby();
	}

}
