<?php

namespace Spleef\player;

use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\network\protocol\AddEntityPacket;
use pocketmine\network\protocol\MoveEntityPacket;
use pocketmine\network\protocol\RemoveEntityPacket;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\utils\TextFormat;
use Spleef\Area;
use Spleef\game\Game;
use Spleef\gadget\CompassActionItem;
use Spleef\gadget\ReturnToLobbyActionItem;
use Spleef\Plugin;
use LbCore\player\LbPlayer;

/**
 * Custom Player class, extends base LbPlayer class
 * Contains methods related to Spleef plugin.
 */
class CustomPlayer extends LbPlayer {

	/* in lobby you can use bonuses without cooldown*/
	const COOLDOWN_LOBBY = 1;
	/* @var int*/
	public $morphedInto = -1;
	/* @var int */
	private $morphHeight = 0;
	/* @var array|null */
	private $morphMeta = null;
	/* @var int */
	public $coins = 0;
	/* @var \stdClass */
	public $virtualPurchases;
	/* @var Game */
	public $currentGame = null;
	/* @var int*/
	public $gameStartingPos = -1;
	/* @var Area */
	public $currentArea = null;
	/* @var bool */
	public $isSpectating = false;
	/* @var Item[] */
	public $hotbarItems = [];
	/* @var ActionItem|null */
	public $actionItem = null;
	/* @var int */
	private $hotbarActionEmptySlot = -1;
	/* @var int */
	public $previousHeldSlot = -1;
	/* @var int|null */
	public $buyingItem = null;
	/* @var bool */
	public $hasPurchaseTask = false;
	/* @var array|null*/
	public $particleEffectExtra = null;
	/* @var int */
	public $lastMove = -1;
	/* @var bool */
	public $hasNotification = false;
	/* @var int */
	public $notificationTime = -1;
	/* @var array */
	private $cooldown = [];
	/* @var int|null */
	public $tntBonusSlot = null;
	/* @var int|null */
	public $slowBombSlot = null;
        
	protected $particleHotbar = [3, 4, 5, 6];

	/**
	 * Increases player's coins amount
	 * 
	 * @param int $amount
	 * @return void
	 */
	public function addCoins($amount) {
		if ($this->isRegistered() && !$this->isAuthorized()) {
			return;
		}

		$this->coinsNum += $amount;
		Plugin::$instance->dbManager->addCoins($this, $amount);
	}

	/**
	 * Remove product or adds specified product ID to the remove queue
	 * 
	 * @param int $prodId
	 * @param int $amount
	 * @param bool $instant
	 * @return void
	 */
	public function removeProduct($prodId, $amount) {
		if ($this->isRegistered() && !$this->isAuthorized()) {
			return;
		}

		if (isset($this->virtualPurchases->$prodId)) {
			$this->virtualPurchases->$prodId -= $amount;
		} else {
			$this->virtualPurchases->$prodId = -$amount;
		}

		Plugin::$instance->dbManager->removeProduct($this, $prodId, $amount);
	}


	/**
	 * Buy product
	 * 
	 * @param int $prodId
	 * @param int $amount
	 * @return bool
	 */
	public function buyProduct($prodId, $amount = 1) {
		if ($this->isRegistered() && !$this->isAuthorized()) {
			return false;
		}
		if ($this->hasPurchaseTask) {
			return false;
		}
		$this->hasPurchaseTask = true;
		Plugin::$instance->dbManager->buyProduct($this, $prodId, $amount);
		return true;
	}

	/**
	 * Checks if specified product has been bought
	 * 
	 * @param int $productId
	 * @return bool
	 */
	public function hasBought($productId) {
		return isset($this->virtualPurchases->$productId);
	}

	/**
	 * Returns amount of specified product 
	 * 
	 * @param int $productId
	 * @return int
	 */
	public function getProductAmount($productId) {
		if (isset($this->virtualPurchases->$productId)) {
			return $this->virtualPurchases->$productId;
		}
		return 0;
	}

	/**
	 * Checks if player can break blocks
	 * 
	 * @return bool
	 */
	public function canPlaceBreakBlocks() {
		if ($this->isRegistered() && !$this->isAuthorized()) {
			return false;
		}
		if ($this->currentArea === null) {
			return false;
		}
		if ($this->isSpectating) {
			return false;
		}

		return $this->currentArea->canPlaceBreakBlocks();
	}

	/**
	 * Morphs player into the thing
	 * 
	 * @param int $eid
	 * @param string $meta
	 * @param int $h
	 */
	public function morphInto($eid, $meta = [], $h = 1) {
		$this->despawnFromAll();
		$this->morphedInto = $eid;
		$this->morphMeta = $meta;
		$this->morphMeta[self::DATA_NAMETAG] = [self::DATA_TYPE_STRING, $this->getDisplayName()];
		$this->morphMeta[self::DATA_SHOW_NAMETAG] = [self::DATA_TYPE_BYTE, 1];
		$this->morphHeight = $h;
		$this->spawnToAll();
	}

	/**
	 * Spawns to specified player
	 * 
	 * @param Player $player
	 * @return void
	 */
	public function spawnTo(Player $player) {
		if ($this->morphedInto !== -1) {
			if ($this->spawned and $player->spawned and $this->isAlive() and $player->isAlive() and $player->getLevel() === $this->level and $player->canSee($this) and ! $this->isSpectator() and
					$player !== $this and ! isset($this->hasSpawned[$player->getId()])) {
				$this->hasSpawned[$player->getId()] = $player;

				$pk = new AddEntityPacket();
				$pk->eid = $this->getId();
				$pk->type = $this->morphedInto;
				$pk->x = $this->getX();
				$pk->y = $this->getY();
				$pk->z = $this->getZ();
				$pk->yaw = 0;
				$pk->pitch = 0;
				$pk->metadata = $this->morphMeta;
				$player->dataPacket($pk);
			}
			return;
		}
		parent::spawnTo($player);
	}

	/**
	 * Desspawns from specified player
	 * 
	 * @param Player $player
	 * @return void
	 */
	public function despawnFrom(Player $player) {
		if ($this->morphedInto !== -1) {
			if (isset($this->hasSpawned[$player->getId()])) {
				unset($this->hasSpawned[$player->getId()]);
				$pk = new RemoveEntityPacket();
				$pk->eid = $this->id;
				$player->dataPacket($pk);
			}
			return;
		}
		parent::despawnFrom($player);
	}

	/**
	 * Sends position
	 * 
	 * @param Vector3 $pos
	 * @param string $yaw
	 * @param string $pitch
	 * @param int $mode
	 * @param array $targets
	 * @return type
	 */
	public function sendPosition(Vector3 $pos, $yaw = null, $pitch = null, $mode = 0, array $targets = null) {
		if ($this->morphedInto !== -1) {
			if ($targets === null) {
				parent::sendPosition($pos, $yaw, $pitch, $mode, $targets);
				return;
			}

			$yaw = $yaw === null ? $this->yaw : $yaw;
			$pitch = $pitch === null ? $this->pitch : $pitch;

			$pk = new MoveEntityPacket;
			$pk->entities = [[$this->getId(), $pos->x, $pos->y, $pos->z, $yaw, $yaw, $pitch]];
			Server::broadcastPacket($targets, $pk);
			return;
		}
		parent::sendPosition($pos, $yaw, $pitch, $mode, $targets);
	}

	/**
	 * Add a cooldown
	 * 
	 * @param string $type
	 * @param string $name
	 * @param int $ticks
	 * @param string $displayName
	 * @return boolean
	 */
	public function cooldown($type, $name, $ticks, $displayName = null) {
		if (isset($this->cooldown[$name])) {
			$this->sendTip($this->getTranslatedString("IS_SPECTATOR", TextFormat::GRAY, array(round($this->cooldown[$name][1] / 20))));
			return false;
		}

		$this->cooldown[$name] = [$type, $ticks, $displayName];
		return true;
	}

	/**
	 * Shows cooldown notification to current player
	 */
	public function cooldownTick() {
		foreach ($this->cooldown as $id => &$data) {
			$data[1] -= 10; // ticks
			if ($data[1] <= 0) {
				unset($this->cooldown[$id]);
			}
		}
	}

	/**
	 * Clear the hotbar inventory
	 */
	public function clearHotbar() {
		$this->hotbarItems = null;
		$this->getInventory()->setHotbarSlotIndex(0, -1);
		$this->getInventory()->setHotbarSlotIndex(1, -1);
		$this->getInventory()->setHotbarSlotIndex(2, -1);
		$this->getInventory()->setHotbarSlotIndex(3, -1);
		$this->getInventory()->setHotbarSlotIndex(4, -1);
		$this->getInventory()->setHotbarSlotIndex(5, -1);
		$this->getInventory()->setHotbarSlotIndex(6, -1);
		$this->getInventory()->setHotbarSlotIndex(7, -1);
	}

	/**
	 * Sets the hotbar action
	 * 
	 * @param int $slot
	 * @param Item $item
	 */
	public function setHotbarAction($slot, $item) {
		$this->getInventory()->setItem($slot, $item);
		$this->getInventory()->setHotbarSlotIndex($slot, $slot);
		$this->getInventory()->sendContents($this);
	}

	/**
	 * Set the hotbar actions
	 * 
	 * @param array $items
	 * @param int $resetSlot
	 */
	public function setHotbarActions($items, $resetSlot = -1) {
		$this->actionItem = null;
		$this->hotbarActionEmptySlot = $resetSlot;
		$this->getInventory()->clearAll();

		$this->clearHotbar();

		$this->hotbarItems = $items;

		foreach ($items as $slot => $item) {
			$this->getInventory()->setItem($slot, $item);
			$this->getInventory()->setHotbarSlotIndex($slot, $slot);
		}

		$this->getInventory()->sendContents($this);
		$this->getInventory()->sendArmorContents($this);
		$this->previousHeldSlot = -1;
		$this->getInventory()->setHeldItemIndex($this->getEmptyHotbarSlot());
	}

	/**
	 * Returns number of first empty hotbar slot
	 * 
	 * @return int
	 */
	public function getEmptyHotbarSlot() {
		if ($this->hotbarActionEmptySlot !== -1) {
			return $this->hotbarActionEmptySlot;
		}
		for ($i = 0; $i < 9; $i++) {
			if ($this->getInventory()->getHotbarSlotIndex($i) === -1) {
				return $i;
			}
		}
		return -1;
	}

	/**
	 * Set current player as spectator
	 * 
	 * @return type
	 */
	public function spectate() {
		$this->isSpectating = true;
		if ($this->currentGame === null){
			return;
		}
		$this->setGamemode(Player::SPECTATOR);
		$this->sendTip($this->getTranslatedString("IS_SPECTATOR", TextFormat::BOLD . TextFormat::GRAY));
		if (isset($this->currentGame->players[$this->getName()])) {
			unset($this->currentGame->players[$this->getName()]);
			$this->currentGame->spectators[$this->getName()] = $this;
		}

		// give spectator items
		$this->setHotbarActions([
			0 => new CompassActionItem(),
			1 => new ReturnToLobbyActionItem()
		]);

		$this->hideFromAll();
	}

	/**
	 * Shows notifications
	 * 
	 * @param string $str
	 * @param int $time
	 * @return void
	 */
	public function showNotification($str, $time = -1) {
		if ($this instanceof \webplay\WebPlayPlayer) {
			$this->showTitle(null, $str, $time, true, 0, 0, 0, 0, 1, 1, 1, 1);
			return;
		}

		if ($str != null) {
			$this->hasNotification = $str;
			$this->notificationTime = $time;
			$this->sendTip($str);
		} else {
			$this->hasNotification = false;
		}
	}

	/**
	 * Returns player to lobby and set default game kit
	 * 
	 * @param $setAreaDirect = false
	 * @param $initial = false
	 */
	public function returnToLobby() {
		$plugin = Plugin::$instance;
		$this->setGamemode(2);
		$this->removeAllEffects();
		$this->setAllowFlight(false);
		$this->setAutoJump(true);
		$this->setOnFire(0);
		$plugin->gadgetManager->applyEffects($this);
		$this->showNotification(null);
		$this->getInventory()->clearAll();
		$this->getInventory()->sendArmorContents($this);
		$plugin->gadgetManager->addGadgetsToInv($this);
		$this->setStateInLobby();
		if ($this->currentGame !== null) {
			$this->currentGame->leave($this);
			$this->currentGame = null;
		}
		$this->gameStartingPos = -1;
		$this->isSpectating = false;
		$plugin->lobbyArea->setAreaFor($this);
		
		$this->showToAll();
	}

	/**
	 * Initialised when player join game
	 * 
	 * @param type $gameType
	 * @return boolean
	 */
	public function joinGame($gameType) {
		$plugin = Plugin::$instance;
		foreach ($plugin->gameManager->games as $game) {
			if ($game::$type == $gameType && $game->maxPlayers >= count($game->players) + 1) {
				if (!$game->started || $game->countdown > 0) {
					$this->showToAll();
					$plugin->gameManager->joinGame($game->name, $this, true);
					return true;
				}
			}
		}
		$this->showToAll();
		$plugin->gameManager->joinGame($plugin->gameManager->createGame($gameType), $this, true);
		$this->setGamemode(0);
		return true;
	}

}
