<?php

namespace Spleef\game;

use pocketmine\math\Vector3;

/** This class stores map source information */
class GameMapSourceInfo {

	/** @var Vector3 */
	public $pos;
	public $size;
	public $kickSize;
	public $minPlayers = 6;
	public $maxPlayers = 8;
	public $time = 0;
	public $dayCycle = true;
	public $positions = [];
	public $chunks = [];

}
