<?php

namespace Spleef\game;

use pocketmine\utils\TextFormat;
use Spleef\Area;
use Spleef\game\modes\Spleef\CakeSpleefGame;
use Spleef\game\modes\Spleef\ClassicSpleefGame;
use Spleef\game\modes\Spleef\PizzaSpleefGame;
use Spleef\game\modes\Spleef\SpleefGame;
use Spleef\player\CustomPlayer;
use Spleef\Plugin;
use pocketmine\math\Vector3;

/**
 * Manages all gametypes process
 */
class GameManager {

	/** @var Plugin */
	private $plugin;
	/** @var Game[] */
	public $games = [];
	/* @var array */
	private static $gameTypes;
	/* @var array */
	public $gamePositions = [];
	/** @var GameMapSourceInfo[] */
	public $sourcePositions = [];

	/**
	 * Set game type
	 * 
	 * @param type $clazz
	 */
	static public function registerGameType($clazz) {
		$name = $clazz::$type;
		self::$gameTypes[$name] = $clazz;
	}

	/**
	 * Adds all game types to the gameTypes
	 */
	static public function registerGameTypes() {
		self::registerGameType(SpleefGame::class);
		self::registerGameType(ClassicSpleefGame::class);
		self::registerGameType(PizzaSpleefGame::class);
		self::registerGameType(CakeSpleefGame::class);
	}

	/**
	 * GameManager constructor, creates gameCountdownTask
	 * 
	 * @param Plugin $plugin
	 */
	public function __construct(Plugin $plugin) {
		$this->plugin = $plugin;
		self::registerGameTypes();
		$plugin->getServer()->getScheduler()->scheduleRepeatingTask(new GameCountdownTask($plugin, $this), 20);
	}

	/**
	 * Adds game to $this->games
	 * 
	 * @param \Spleef\game\Game $game
	 */
	public function addGame(Game $game) {
		$this->games[$game->name] = $game;
	}

	/**
	 * Creates and returns new game type
	 * 
	 * @param type $type
	 * @return \Spleef\game\gameType
	 */
	public function createGame($type) {
		$minPlayers = 2;
		$maxPlayers = 8;

		for ($id = 1; $id < 60; $id++) {
			if (isset($this->games["#" . $id])) {
				continue;
			}
			break;
		}
		$name = "#" . $id;

		foreach ($this->gamePositions as $id => $pos) {
			$sourcePos = $this->sourcePositions[$type];
			$sourcePos = $sourcePos[rand(0, count($sourcePos) - 1)];
			$gameType = self::$gameTypes[$type];
			$game = new $gameType($this->plugin, $this, $name, new Area($this->plugin, $pos->x, $pos->y, $pos->z, $sourcePos->size, $sourcePos->kickSize, true, $sourcePos->time, $sourcePos->dayCycle), $sourcePos, $minPlayers, $maxPlayers);
			$this->addGame($game);
			unset($this->gamePositions[$id]);

			return $name;
		}
	}

	/**
	 * Destroys game
	 * 
	 * @param \Spleef\game\Game $game
	 */
	public function destroy(Game $game) {
		unset($this->games[$game->name]);

		$this->gamePositions[] = new Vector3($game->area->centerX, $game->area->y, $game->area->centerZ);
	}

	/**
	 * Return game name
	 * 
	 * @param \Spleef\game\Game $game
	 * @return string
	 */
	public function getNameOf(Game $game) {
		return $game->name;
	}

	/**
	 * Joins specified player to the game
	 * 
	 * @param string $name
	 * @param CustomPlayer $player
	 * @param bool $notify
	 * @return boolean
	 */
	public function joinGame($name, CustomPlayer $player, $notify = false) {
		$this->plugin->getLogger()->info($player->getName() . " is attempting to join " . $name);
		if ($player->isRegistered() && !$player->isAuthorized()) {
			$player->sendMessage(TextFormat::RED . $player->getTranslatedString("GAME_PREFIX") . $player->getTranslatedString("NEEDS_LOGIN", TextFormat::BOLD));
			return false;
		}
		if (!array_key_exists($name, $this->games)) {
			$player->sendMessage(TextFormat::RED . $player->getTranslatedString("ERROR_PREFIX") . $player->getTranslatedString("NO_GAME", TextFormat::BOLD, array($name)));
			return false;
		}
		if ($player->currentGame === $this->games[$name]) {
			$player->sendMessage(TextFormat::GOLD . $player->getTranslatedString("GAME_PREFIX") . $player->getTranslatedString("ON_GAME", TextFormat::BOLD, array($name)));
			return false;
		}
		if ($player->currentGame !== null) {
			$player->currentGame->leave($player);
			$player->currentGame = null;
			$player->gameStartingPos = -1;
		}
		if ($this->games[$name]->join($player)) {
			$player->removeAllEffects();
			$player->setAllowFlight(false);
			$player->setAutoJump(true);
			$player->setOnFire(0);
			if ($notify) {
				$player->sendMessage(TextFormat::GREEN . $player->getTranslatedString("GAME_PREFIX") . $player->getTranslatedString("IN_GAME", TextFormat::BOLD, array($name)));
			}
			$player->currentGame = $this->games[$name];
			$player->setStateCountdown($name);

			return true;
		}
		return false;
	}

}
