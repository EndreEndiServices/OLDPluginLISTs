<?php

namespace Spleef\game\modes\Spleef;

use pocketmine\entity\Effect;
use pocketmine\item\Item;
use pocketmine\utils\TextFormat;
use Spleef\gadget\NamedItem;

/** This class manages Classic Spleef game type */
class ClassicSpleefGame extends SpleefGame {
	/** @var string */
	public static $type = "ClassicSpleef";

	/**
	 * Executes when countdown finished. 
	 * Adds iron shovel for all players
	 */
	public function countdownFinished() {
		parent::countdownFinished();
		foreach ($this->players as $player) {
			$player->addEffect(Effect::getEffect(Effect::HASTE)->setAmplifier(127)->setDuration(0x7fffffff)->setVisible(false));
			$player->addEffect(Effect::getEffect(Effect::JUMP)->setAmplifier(2.5)->setDuration(0x7fffffff)->setVisible(false));
			$player->addEffect(Effect::getEffect(Effect::SPEED)->setAmplifier(2.5)->setDuration(0x7fffffff)->setVisible(false));
			$player->setHotbarAction(
					0, new NamedItem(Item::IRON_SHOVEL, 0, 1, $player->getTranslatedString("SHOVEL_ITEM", TextFormat::GOLD))
			);
			$player->setStateInGame();
		}		
	}

}
