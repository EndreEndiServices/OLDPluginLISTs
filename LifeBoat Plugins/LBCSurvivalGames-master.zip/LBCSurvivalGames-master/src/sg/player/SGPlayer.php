<?php

namespace sg\player;

use LbCore\player\LbPlayer;
use pocketmine\item\Item;
use pocketmine\utils\TextFormat;
use Pets\Pets;

/**
 * Custom plugin player class, contains:
 * 1. Info about player's tournament and team
 * 2. Sets default options on spawn
 * 3. Setup VIP amd VIP+ inventory on arena
 */
class SGPlayer extends LbPlayer {
	
	/** @var $tournament contains arena id or false when player is in lobby*/
	private $tournament = false;
	/**@var string */
	private $team = self::DEFAULT_TEAM;
	
	protected $particleHotbar = [1, 2, 3, 4];

	const DEFAULT_TEAM = "NONE";
	
	/**
	 * @return int
	 */
	public function getTournamentId() {
		return $this->tournament;
	}
	
	/** 
	 * @param int $value
	 */
	public function updateTournamentId($value) {
		$this->tournament = $value;
	}
	
	/**
	 * @return int
	 */
	public function getTeam() {
		return $this->team;
	}
	
	/**
	 * @param string $value
	 */
	public function setTeam(string $value) {
		$this->team = $value;
	}
	
	/**
	 * set common player options on login and respawn
	 */
	public function setSpawnOptions() {
		$this->setFoodEnabled(false);
		$this->removeAllEffects();
		$this->setGamemode(0);
		$this->setHealth(20);
		$this->setFood(20);
	}
	
	/**
	 * setup player inventory before tournament starts (if he is VIP)
	 * calls in acceptPlayer method
	 */
	public function setupInventory() {
		$this->removeAllEffects();
		$this->getInventory()->clearAll();
		//set kits for vip players
//		if ($this->isVip()) {
//			if ($this->vipStatus === self::VIP_PLUS) {
//				$this->setVipPlusKit();
//			} else {
//				$this->setVipKit();
//			}
//		}
	}
	
	/**
	 * give VIP+ items to player before tournament starts
	 * calls in setupInventory method
	 */
//	private function setVipPlusKit() {
//		$weaponSlot = $this->getInventory()->firstEmpty();
//		$this->setHotbarItem($weaponSlot, Item::get(Item::DIAMOND_AXE, 0, 1));
//		$this->getInventory()->setHeldItemIndex($weaponSlot);
//		$this->getInventory()->setArmorItem(0, Item::get(Item::CHAIN_HELMET, 0, 1));
//		$this->getInventory()->setArmorItem(1, Item::get(Item::CHAIN_CHESTPLATE, 0, 1));
//		$this->getInventory()->setArmorItem(2, Item::get(Item::CHAIN_LEGGINGS, 0, 1));
//		$this->getInventory()->setArmorItem(3, Item::get(Item::CHAIN_BOOTS, 0, 1));
//		$this->getInventory()->sendArmorContents($this); //put on armor
//		$this->getInventory()->sendContents($this); //show inventory items
//	}
//
//	/**
//	 * give VIP items to player before tournament starts
//	 * calls in setupInventory method
//	 */
//	private function setVipKit() {
//		$weaponSlot = $this->getInventory()->firstEmpty();
//		$this->setHotbarItem($weaponSlot, Item::get(Item::IRON_AXE, 0, 1));
//		$this->getInventory()->setHeldItemIndex($weaponSlot);
//		$this->getInventory()->setArmorItem(0, Item::get(Item::GOLD_HELMET, 0, 1));
//		$this->getInventory()->setArmorItem(1, Item::get(Item::GOLD_CHESTPLATE, 0, 1));
//		$this->getInventory()->setArmorItem(2, Item::get(Item::LEATHER_PANTS, 0, 1));
//		$this->getInventory()->setArmorItem(3, Item::get(Item::LEATHER_BOOTS, 0, 1));
//		$this->getInventory()->sendArmorContents($this); //put on armor
//		$this->getInventory()->sendContents($this); //show inventory items
//	}	
	
	/**
	 * add team colors for player's name
	 */
	public function setColoredNameTag() {
		$rankPrefix = TextFormat::WHITE;
		if ($this->getTeam() !== self::DEFAULT_TEAM) {
			$teamColor = $this->getTeam();
			$rankPrefix = constant('pocketmine\utils\TextFormat::'.  strtoupper($teamColor));			
		}
		$this->updateDisplayedName($rankPrefix);
	}
	
	/**
	 * Overriden method for activating kits only on allowed maps 
 	 * (all maps except first sign)
	 * 
	 * @param int $arenaId
	 */
	public function setStateInGame($arenaId = null) {	
		//set options for no kits justice maps
		if ($arenaId === \sg\Tournament::MAP_OF_JUSTICE_ID) {
			$this->stateForAlertSystem = self::IN_GAME;
            if($this->needParticles){
                $this->getInventory()->remove(Item::get(Item::BUCKET));
                $this->getInventory()->remove(Item::get(Item::REDSTONE));
                $this->getInventory()->remove(Item::get(120));
                $this->getInventory()->remove(Item::get(378));
                $this->getInventory()->sendContents($this);
            }
            if (isset($this->pet) && $this->pet instanceof Pets) {
                $this->pet->close();
                $this->pet = null;
            }
			return;
		}
		parent::setStateInGame($arenaId);
	}
	
}
