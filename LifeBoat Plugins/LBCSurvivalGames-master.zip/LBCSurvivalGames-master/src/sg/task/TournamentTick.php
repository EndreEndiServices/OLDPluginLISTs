<?php

namespace sg\task;

use sg\Tournament;
use sg\player\SGPlayer;
use pocketmine\scheduler\PluginTask;
use pocketmine\utils\TextFormat;
use LbCore\LbCore;

/**
 * This class controls repeating plugin tasks depending on ticks
 */
class TournamentTick extends PluginTask {
	/** @var SurvivalGames*/
	private $plugin;
	/** @var int*/
	private $lastTick = 0;
	/** @var int*/
	private $arenaTick = 0;

	/**
	 * @param SurvivalGames $plugin
	 */
	public function __construct($plugin) {
		parent::__construct($plugin);
		$this->plugin = $plugin;
		$this->lastTick = time();
	}

	/**
	 * Run all cycled tasks
	 * @param $currentTick
	 */
	public function onRun($currentTick) {
		if ($this->plugin->useTeams) {
			//each 3 seconds
			if ($this->lastTick < time() && 
				$this->lastTick % 10 == 0) {
				foreach ($this->plugin->getServer()->getOnlinePlayers() as $player) {
					if ($player instanceof SGPlayer &&
						($player->isAuthorized() || !$player->isRegistered())) {
						$player->setColoredNameTag();
					}
				}
			}
			$this->setArenaStatusbar();
		}
		//run each second
		if (time() > $this->lastTick) {
			$this->lastTick = time();
			//run tick inside each running arena
			foreach ($this->plugin->tournaments as $i => $t) {
				if ($t instanceof Tournament) {
					$this->plugin->tournaments[$i]->tick();
				}
			}
			if($this->arenaTick < 750){
				$this->arenaTick++;		
				//run new tournament each 3 minutes (or 180 seconds)	
				switch (($this->arenaTick) / 180) {
					case 1:
						$this->plugin->tournaments[2] = new Tournament($this->plugin);
						break;
					case 2:
						$this->plugin->tournaments[3] = new Tournament($this->plugin);
						break;
					case 3:
						$this->plugin->tournaments[4] = new Tournament($this->plugin);
						break;
					case 4:
						$this->plugin->tournaments[5] = new Tournament($this->plugin);
						break;
				}
			}
			$lbCore = LbCore::getInstance();
			if(is_object($lbCore->playerCount)){
				$lbCore->getServer()->mainInterface->setCount($lbCore->playerCount->total_players, $lbCore->playerCount->total_slots);
			}
		}		
	}
	
	/**
	 * Creates status bar for every player on Teams arena
	 * collects statistics about every team (calls each 3 seconds)
	 */
	private function setArenaStatusbar() {
		foreach ($this->plugin->tournaments as $tournament) {
			//collect information about all teams
			$statusBar = "";
			$currentTeams = $tournament->getTeams();
			foreach ($currentTeams as $color => $team) {
				if ($statusBar != "") {
					$statusBar .= " " . TextFormat::DARK_GRAY . "- ";
				}
				$statusBar .= constant('pocketmine\utils\TextFormat::' . strtoupper($color)) . ucfirst($color) . " " . count($team);
			}
			//set popup information about teams for every player
			$currentPlayers = $tournament->getPlayers();
			foreach ($currentPlayers as $player) {
				$teamPrefix = null;
				if ($player->getTeam()) {
					$team = strtoupper($player->getTeam());
					if ($team != SGPlayer::DEFAULT_TEAM) {
						$teamPrefix = constant('pocketmine\utils\TextFormat::' . $team); //set color for current team
					}
				}
				$player->sendPopup($statusBar . ($teamPrefix ? (" " . TextFormat::DARK_GRAY . "-" . $teamPrefix . "T: " . $team) : ""));
			}
		}
	}

}
