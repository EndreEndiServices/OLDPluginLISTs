<?php

namespace sg;

use sg\data\PluginData;
use sg\player\SGPlayer;
use sg\Tournament;
use LbCore\LbCore;
use LbCore\LbEventListener;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\inventory\InventoryOpenEvent;
use pocketmine\event\player\PlayerCreationEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerItemConsumeEvent;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\event\server\QueryRegenerateEvent;
use pocketmine\inventory\ChestInventory;
use pocketmine\inventory\DoubleChestInventory;
use pocketmine\math\Vector3;
use pocketmine\block\Block;
use pocketmine\utils\TextFormat;
use pocketmine\event\entity\EntityExplodeEvent;
use LbCore\event\PlayerAuthEvent;

/**
 * base plugin EventListener, holding events like onPlayerLogin etc
 * 
 */
class EventListener extends LbEventListener {
	
    protected $plugin;


    /**
	 * base class constructor, declare LbCore here
	 * 
	 * @param SurvivalGames $plugin
	 */
	public function __construct(SurvivalGames $plugin) {
		parent::__construct($plugin);
                $this->plugin = $plugin;
	}
	
	/**
	 * Overwrite player class to custom SGPlayer
	 * 
	 * @param PlayerCreationEvent $event
	 */
	public function onPlayerCreation(PlayerCreationEvent $event) {
		$event->setPlayerClass(SGPlayer::class);
	}

	/**
	 * Calls when player comes into game
	 * Sets some specific spawn options
	 * 
	 * @param PlayerLoginEvent $event
	 */
	public function onPlayerLogin(PlayerLoginEvent $event) {
		parent::onPlayerLogin($event);
		$player = $event->getPlayer();
		$player->setSpawnOptions();
		$player->setStateInLobby();
	}
        
        public function onPlayerAuth(PlayerAuthEvent $event){
            $player = $event->getPlayer();
        }

	/**
	 * calls when player hit smb
	 * cancel damage in lobby, for teammates and in non-fighting mode
	 * 
	 * @param EntityDamageEvent $event
	 * @return boolean
	 */
	public function onEntityDamage(EntityDamageEvent $event) {
		$player = $event->getEntity();
		if (!$player instanceof SGPlayer) {
			return;
		}		
		//can't damage anyone in lobby
		if (!$player->getTournamentId()) {
			$event->setCancelled(true);
			return;
		}					
		//can't damage anyone while tournament is not started or it's in invincible mode
		$tournament = $this->plugin->tournaments[$player->getTournamentId()];
		if (!$tournament->isStarted() || $tournament->isInvincible()) {
			$event->setCancelled(true);
			return;
		}		
		//can't damage teammates
		if($this->plugin->useTeams && $event instanceof EntityDamageByEntityEvent){
			$attacker = $event->getDamager();
                        if($attacker instanceof SGPlayer){
                            if ($player->getTeam() == $attacker->getTeam()){
                                $event->setCancelled(true);
                                return;
                            }
                        }
		}
	}
	
	

	/**
	 * calls when player dies
	 * Can not die in lobby, if die in tournament - inform survivors
	 * 
	 * @param PlayerDeathEvent $event
	 * @return boolean
	 */
	public function onPlayerDeath(PlayerDeathEvent $event) {
		parent::onPlayerDeath($event);
		//can't die in lobby
		$player = $event->getEntity();
		if (!$player->getTournamentId()) {
			return false;
		}
		//when player died in tournament
		$tournament = $this->plugin->tournaments[$player->getTournamentId()];		
		if ($tournament instanceof Tournament) {
			$dm = $event->getDeathMessage();			
			$tournament->removeDeadMan($player, $dm);
		}
		$event->setDeathMessage("");
	}


	/**
	 * sets server name and number of players (current/allowed)
	 * 
	 * @param QueryRegenerateEvent $event
	 */
	public function onQuery(QueryRegenerateEvent $event) {
		$playerCount = 0;
		$maxCount = 0;
		$pluginName = "";
		$lbCore = LbCore::getInstance();
		if (isset($lbCore->playerCount->tm_players)) {
			if($this->plugin->useTeams){
				$playerCount = $lbCore->playerCount->tm_players;
				$maxCount = $lbCore->playerCount->tm_slots;
				$pluginName = "Teams";
			} else {
				$playerCount = $lbCore->playerCount->total_players;
				$maxCount = $lbCore->playerCount->total_players;
				$pluginName = "Survival Games";
			}
		}
		$event->setPlayerCount($playerCount);
		$event->setMaxPlayerCount($maxCount);
		$event->setServerName(
			'{-name-:-Lifeboat ' . $pluginName . '-,-node-:{-type-:-SG-,-ip-:-' . 
			LbCore::getInstance()->getDomainName() . '-,-players-:' . 
			count($this->plugin->getServer()->getOnlinePlayers()) . 
			',-maxplayers-:90,-tps-:' . 
			$this->plugin->getServer()->getTicksPerSecond() . '}}'
			);
	}

	
	/**
	 * controls chat messages on tournaments
	 * look for recipients inside the same arena as player,
	 * or everybody in lobby if player is in lobby
	 * 
	 * @param PlayerChatEvent $event
	 */
	public function onPlayerChat(PlayerChatEvent $event) {
		parent::onPlayerChat($event);
		if ($event->isCancelled()) {
			return;
		}
		$recipients = array();
		$initiator = $event->getPlayer();
		
		if (!($initiator instanceof SGPlayer)) {
			return;
		}		
		//get recipients
		if ($initiator->getState() === SGPlayer::IN_LOBBY) {
			$players = $event->getRecipients();
			foreach ($players as $player) {
				if (!($player instanceof SGPlayer) || 
						$player->getState() === SGPlayer::IN_LOBBY) {
					$recipients[] = $player;
				}
			}
		} else {
			$tournament = $this->plugin->tournaments[$initiator->getTournamentId()];
			if (!is_null($tournament)) {
				$players = $event->getRecipients();
				$tournamentPlayers = $tournament->getPlayers();
				foreach ($players as $recipient) {
					if (!($recipient instanceof SGPlayer) || 
							isset($tournamentPlayers[$recipient->getId()])) {
						$recipients[] = $recipient;
					}
				}
			}
		}
		$event->setRecipients($recipients);
		//overwrite chat message for non-team mode
		if (!($this->plugin->useTeams) || 
				($initiator->getState() === SGPlayer::IN_LOBBY &&
				$initiator->getTeam() == SGPlayer::DEFAULT_TEAM)) {
			$event->setCancelled(true);
			$message = $event->getMessage();
			foreach ($recipients as $recipient) {
				$recipient->sendMessage(
						TextFormat::YELLOW . str_replace(TextFormat::WHITE, TextFormat::YELLOW, $initiator->getDisplayName()) 
						. "§b: " . TextFormat::WHITE . $message);
			}
		}
	}
	
	

	/**
	 * Calls when player respawn, set default plugin spawn options
	 * 
	 * @param PlayerRespawnEvent $event
	 */
	public function onPlayerRespawn(PlayerRespawnEvent $event) {
		$player = $event->getPlayer();
		$player->setSpawnOptions();
	}

	/**
	 * calls in lobby to:
	 * 1. stay on pedestal while tournament is not started
	 * 2. Fast move from red tiles
	 * 
	 * @param PlayerMoveEvent $event
	 */
	public function onPlayerMove(PlayerMoveEvent $event) {
		$player = $event->getPlayer();
		//tournament movings
		if ($player->getTournamentId()) {
			$this->stayOnPedestal($event);
		} else {//lobby movings
			$this->pushFromArenaSigns($player);
			$this->flyOnRedTile($player);
		}
	}
	
	/**
	 * Glued to pedestal while tournament is not startes
	 * 
	 * @param PlayerMoveEvent $event
	 */
	private function stayOnPedestal(PlayerMoveEvent $event) {
		$player = $event->getPlayer();
		$tournament = $this->plugin->tournaments[$player->getTournamentId()];
		if (!$tournament->isStarted()) {
			$from = $event->getFrom();
			$to = $event->getTo();
			if ($from->getX() != $to->getX() ||
				$from->getZ() != $to->getZ()) {
				$event->setCancelled(true);
			}
		}
	}
	
	/**
	 * Keep players at distance from arena signs
	 * 
	 * @param BHPlayer $player
	 * @return void
	 */
	private function pushFromArenaSigns($player) {
		if ($player->getX() >= PluginData::$mapSignCoords[5][0] &&
				$player->getX() <= (PluginData::$mapSignCoords[1][0] + 1) &&
				$player->getZ() >= PluginData::$mapSignCoords[1][2] &&
				$player->getZ() <= (PluginData::$mapSignCoords[1][2] + 5)) {
			$player->setMotion(new Vector3(0, 0.2, -0.4));
			return;
		}
		
	}
	
	/**
	 * Move like a bullet from red tiles in lobby
	 * 
	 * @param SGPlayer $player
	 */
	private function flyOnRedTile(SGPlayer $player) {
		//front tile
		if ($player->getX() > (PluginData::$redTiles[1]["x"] -1) &&
			$player->getX() < (PluginData::$redTiles[1]["x"] + 1) &&
			$player->getZ() > (PluginData::$redTiles[1]["z"] - 1) &&
			$player->getZ() < (PluginData::$redTiles[1]["z"] + 1)) {
			
			$player->setMotion(new Vector3(0, 0.2, 1.6));
			return;
		}
		if ($player->getZ() > (PluginData::$redTiles[2]["z"] - 1) &&
			$player->getZ() < (PluginData::$redTiles[2]["z"] + 1)) {
			//right tile
			if ($player->getX() > (PluginData::$redTiles[2]["x"] - 1) &&
				$player->getX() < (PluginData::$redTiles[2]["x"] + 1)) {
				$player->setMotion(new Vector3(1.6, 0.2, 0));
				return;
			}
			//left tile
			if ($player->getX() > (PluginData::$redTiles[3]["x"] - 1) &&
				$player->getX() < (PluginData::$redTiles[3]["x"] + 1)) {
				$player->setMotion(new Vector3(-1.6, 0.2, 0));
				return;
			}
		}
	}

	/**
	 * interaction with tournament and team signs
	 * 
	 * @param PlayerInteractEvent $event
	 */
	public function onPlayerInteract(PlayerInteractEvent $event) {
		$block = $event->getBlock();
		if($block->getId() == Block::BED_BLOCK){
            return;
        }
		if($block->getId() == Block::SIGN_POST || $block->getId() == Block::WALL_SIGN){
			$player = $event->getPlayer();
			if (!$player->getTournamentId()) {
				$x = $block->getX();
				$y = $block->getY();
				$z = $block->getZ();
				if(!$this->interactWithTournamentSign($player, $x, $y, $z)){
					$this->interactWithTeamTiles($player, $x, $y, $z);
				}				
			}		
			$event->setCancelled(true);
		}
	}
	
	/**
	 * Look if player interacts with tournament tiles
	 * 
	 * @param SGPlayer $player
	 * @param int $x
	 * @param int $y
	 * @param int $z
	 */
	private function interactWithTournamentSign(SGPlayer $player, $x, $y, $z) {
		if (PluginData::isTournamentSign($x, $y, $z)) {
			$signId = $this->coordToSignId($x);
			if (!isset($this->plugin->tournaments[$signId])) {
				$player->sendLocalizedMessage("TOURNAMENT_STOPPED");
			} else {
				$this->plugin->tournaments[$signId]->addPlayer($player);
			}
			return true;
		}
		return false;
	}
	
	
	/**
	 * Moved here to easily algorythm update
	 * 
	 * @param int $x
	 * @return int
	 */
	private function coordToSignId($x) {
		$signId = 0;
		if ($x && is_numeric($x)) {
			$signId = (-1) * $x -7;
		}
		return $signId;
	}
	

	/**
	 * Look if player interacts with team tiles
	 * 
	 * @param SGPlayer $player
	 * @param int $x
	 * @param int $y
	 * @param int $z
	 */
	private function interactWithTeamTiles(SGPlayer $player, $x, $y, $z) {
		if (PluginData::isTeamTile($x, $y, $z)) {
			if (!$player->isAuthorized()) {
				$player->sendLocalizedMessage("NEEDS_LOGIN");
				return;
			}
			if (!$player->isVip()) {
				$player->sendLocalizedMessage("ONLY_FOR_VIP");
				return;
			}
			//set team						
			$teamColor = PluginData::getTeamByCoord($y);
			$player->setTeam($teamColor);
			$teamColouredName = constant('pocketmine\utils\TextFormat::'.  strtoupper($teamColor)) . ucfirst($teamColor);
			$player->sendLocalizedMessage("TEAM_CHANGED", array($teamColouredName));
		}
	}

	/**
	 * calls when player quit game, unsets playerdata
	 * 
	 * @param PlayerQuitEvent $event
	 */
	public function onPlayerQuit(PlayerQuitEvent $event) {
		$player = $event->getPlayer();
		if ($player->getTournamentId()) {
			$player->kill();
		}
	}

	/**
	 * calls when player try to break block, 
	 * cancel everything except whitelisted blocks
	 * 
	 * @param BlockBreakEvent $event
	 */
	public function onBlockBreak(BlockBreakEvent $event) {
		$player = $event->getPlayer();
		if ($player->getTournamentId()) {
			$t = $this->plugin->tournaments[$player->getTournamentId()];
			if ($t->isStarted() && !$t->isDeathMatch()) {
				if (isset(PluginData::$whitelistedBlocks[$event->getBlock()->getID()])) {
					return;
				}
			}
		}
		$event->setCancelled(true);
	}

	
	/**
	 * calls when player open chest, 
	 * chest is filled by items
	 * 
	 * @param InventoryOpenEvent $event
	 */
	public function onInventoryOpen(InventoryOpenEvent $event) {
		$inventory = $event->getInventory();	
		if ($inventory instanceof ChestInventory) {
			$player = $event->getPlayer();
			//check if player's tournament started
			$tournament = $this->plugin->tournaments[$player->getTournamentId()];
			if ($tournament && $tournament->isStarted()) {
				//get inventory type, fill chest
				$isDoubleInventory = ($inventory instanceof DoubleChestInventory) ? true : false;
				$tournament->fillChest($event, $isDoubleInventory);
			} else {			
				$event->setCancelled(true);
			}
		}
	}
	

	/**
	 * calls when player try to set block, allow only on tournament area
	 * 
	 * @param BlockPlaceEvent $event
	 */
	public function onBlockPlace(BlockPlaceEvent $event) {
		$this->allowAfterMatchStart($event->getPlayer(), $event);
//		$event->setCancelled(true);
	}

	/**
	 * calls when player try to consume item,
	 * cancel in lobby or when tournament is not started
	 * 
	 * @param PlayerItemConsumeEvent $event
	 */
	public function onPlayerItemConsume(PlayerItemConsumeEvent $event) {
		$this->allowAfterMatchStart($event->getPlayer(), $event);
	}

	/**
	 * calls when player try to drop item,
	 * cancel in lobby and before tournament start
	 * 
	 * @param PlayerDropItemEvent $event
	 */
	public function onDropItem(PlayerDropItemEvent $event) {
		$this->allowAfterMatchStart($event->getPlayer(), $event);
	}
	
	
	/**
	 * check permissions for base player actions (drop items, break blocks etc),
	 * as a rule these actions are not allowed anywhere except fighting mode
	 * 
	 * @param SGPlayer $player
	 * @param object $event
	 */
	private function allowAfterMatchStart(SGPlayer $player, $event) {
		if (!$player->getTournamentId() || 
			!$this->plugin->tournaments[$player->getTournamentId()]->isStarted()) {
			$event->setCancelled(true);
		}
	}

    public function onEntityExplode(EntityExplodeEvent $event){
        $event->setBlockList([]);
    }
}
