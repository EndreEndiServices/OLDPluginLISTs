<?php
namespace sg\language;

use pocketmine\utils\TextFormat;
use LbCore\language\core\English as LbEnglish;

/**
 * Class contains specific plugin translates, 
 * add them into parent LbCore array $translates
 */
class English extends LbEnglish {

	public function __construct() {
		/*Tournament signs*/
		$this->translates["ALREADY_STARTED"] = "§dThat tournament has already started.";
		$this->translates["TOURNAMENT_STOPPED"] = "§1- §dThat server isn't running.";
		$this->translates["ALMOST_FULL"] = "§1- §7 That tournament is restricted to §6VIP§7s only,\n§1- §7it's almost full.";
		$this->translates["FULL"] = "§dThat tournament is full.";
		/* Tournament */
		$this->translates["WON_MATCH"] = "§9> §farg1 §6won the match.\n§9> §7Returning to the lobby...";
		$this->translates["WON_MATCH_BROADCAST"] = "§aarg1 won the match on arena SG-arg2.";
		$this->translates["PLAYER_DEATH"] = "§barg1 §3killed by §farg2§3. §barg3 §3survivors left.";
		$this->translates["GOOD_LUCK_MSG"] = "Two players remain, good luck!";
		$this->translates["FIRST_KILL"] = "§aarg1 §5got the first kill!";
		$this->translates["SUCCESS_MSG_1"] = "§aarg1 is cleaning up!";
		$this->translates["SUCCESS_MSG_2"] = "§aarg1 §r§ais §9#winning§a!";
		$this->translates["SUCCESS_MSG_3"] = "§aarg1 is on a killing spree!";
		$this->translates["SUCCESS_MSG_4"] = "§aarg1 is on a roll!";
		$this->translates["MATCH_RESTARTING"] = "§9>§7 Tournament ended. Thanks for playing!\n> Restarting the server...";
		$this->translates["STARTING_IN"] = "§9> §7Game will start in: §farg1§7.";
		$this->translates["TOURNAMENT_START"] = "§9> §6Tournament has started!";
		$this->translates["USING_MAP"] = "§9> §bUsing map: arg1";
		$this->translates["USING_MAP_CREATOR"] = "§9>§7 Using map: arg1 by arg2";
		$this->translates["INVINCIBILITY_30"] = "§9> §3You have §ethirty§3 seconds of invincibility left.";
		$this->translates["INVINCIBILITY_15"] = "§9> §3You have §efifteen§3 seconds of invincibility left.";
		$this->translates["INVINCIBILITY_END"] = "§9> §3You are no longer invincible.";
		$this->translates["CHEST_REFILL"] = "§9> §eAll chests have been refilled!";
		$this->translates["DEATHMATCH_START"] = "§9>§7 Welcome to the deathmatch. May the best player win!";
		$this->translates["STARTING"] = "§9> §3Starting in §earg1§3...";
		$this->translates["DEATHMATCH"] = "§9> §3Deathmatch starting in §earg1§3 minutearg2.";
		$this->translates["DM_COUNTDOWN"] = "§9> §3Deathmatch starting in §earg1§3...";
		$this->translates["ENDING"] = "§9> §3Tournament ending in §earg1§3 minutearg2.";
		$this->translates["JOINING"] = "§bJoining the match...";
		$this->translates["TOURNAMENT_WELCOME"] = "§bWelcome to the tournament!\n§bIt will start in §3arg1§b.";
		$this->translates["ON_JOIN"] = "§9>§f arg1 §ejoined the match.";
		$this->translates["PLAYERS_REMAIN"] = "arg1 players remain.";
		$this->translates["JUSTICE_MAP_WELCOME"] = TextFormat::GOLD . "Kits are disabled on this map.\n" 
				. TextFormat::GOLD . "So, you do not get any weapon, armor, or special abilities.\n"
				. TextFormat::GOLD . "Scary!";
		/*Commands*/
		$this->translates["RETURN_TO_LOBBY"] = "§1- §7Returning to the lobby.";
		$this->translates["LBTIME_ERROR"] = "§1- §7Join a tournament first.";
		$this->translates["SHOW_LBTIME"] = "§1- §7The tournament will start in arg1.";
		/*VIP team signs*/
		$this->translates["ONLY_FOR_VIP"] = 
				TextFormat::RED . "This action is available only for VIP players.\n" . 
				TextFormat::RED . "You can buy VIP rank in the Lifeboat+ app.";
		$this->translates["TEAM_CHANGED"] = 
				TextFormat::GOLD . "Team is successfully changed!\n" . 
				TextFormat::GOLD . "Your current Team is arg1";
	}

}