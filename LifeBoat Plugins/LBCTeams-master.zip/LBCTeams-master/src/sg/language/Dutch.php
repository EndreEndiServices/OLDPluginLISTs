<?php
namespace sg\language;

use pocketmine\utils\TextFormat;
use LbCore\language\core\Dutch as LbDutch;

/**
 * Class contains specific plugin translates, 
 * add them into parent LbCore array $translates
 */
class Dutch extends LbDutch {

	public function __construct() {
		/*Tournament signs*/
		$this->translates["ALREADY_STARTED"] = "§dDat tournament is al begonnen.";
		$this->translates["TOURNAMENT_STOPPED"] = "§1- §dDie server staat niet aan.";
		$this->translates["ALMOST_FULL"] = "- Dat tournament is alleen voor VIPs bestemd;\n- Hij zit bijna vol.";
		$this->translates["FULL"] = "§dDat tournament zit vol.";		
		/* Tournament */
		$this->translates["WON_MATCH"] = "§9> §farg1 §6heeft de match gewonnen.\n§9> §7Terug naar de lobby...";		
		$this->translates["WON_MATCH_BROADCAST"] = "§aarg1 heeft de match in arena SG-arg2 gewonnen.";
		$this->translates["PLAYER_DEATH"] = "§barg1 §3is vermoord door §farg2§3. §barg3 §3overlevers over.";
		$this->translates["GOOD_LUCK_MSG"] = "Twee spelers over; succes!";		
		$this->translates["FIRST_KILL"] = "§aarg1 §5heeft als eerste een speler vermoord!";
		$this->translates["SUCCESS_MSG_1"] = "§aarg1 is op aan het ruimen";
		$this->translates["SUCCESS_MSG_2"] = "§aarg1 is aan het #winnen";
		$this->translates["SUCCESS_MSG_3"] = "§aarg1 zit op een killing spree";
		$this->translates["SUCCESS_MSG_4"] = "§aarg1 is lekker bezig";
		$this->translates["SUCCESS_MSG"] = "arg1 arg2!";
		$this->translates["MATCH_RESTARTING"] = "§9>§7 Het tournament is over. Bedankt voor het spelen!\n> Server aan het herstarten...";
		$this->translates["STARTING_IN"] = "§9>§7 Het tournament zal beginnen in: §farg1§7.";
		$this->translates["TOURNAMENT_START"] = "§9> §6Het tournament is begonnen!";
		$this->translates["USING_MAP"] = "§9> §bWe gebruiken map: arg1";
		$this->translates["USING_MAP_CREATOR"] = "§9>§7 We gebruiken map: arg1 door arg2";
		$this->translates["INVINCIBILITY_30"] = "§9>§7 Je bent nog §e30§3 seconden dertig.";
		$this->translates["INVINCIBILITY_15"] = "§9>§7 Je bent nog §e15§3 seconden veilig.";
		$this->translates["INVINCIBILITY_END"] = "§9> §3Je kunt nu schade van andere spelers krijgen.";
		$this->translates["CHEST_REFILL"] = "§9> §eAlle kisten zijn opnieuw gevuld!";
		$this->translates["DEATHMATCH_START"] = "§9>§7 Welkom bij de deathmatch. Moge de beste speler winnen!";
		$this->translates["STARTING"] = "§9> §3We beginnen over §earg1§3...";
		$this->translates["DEATHMATCH"] = "§9> §3Deathmatch begint over §earg1§3 minuten.";
		$this->translates["DM_COUNTDOWN"] = "§9> §3Deathmatch begint over §earg1§3...";
		$this->translates["ENDING"] = "§9> §3Tournament eindigt in §earg1§3 minuten.";
		$this->translates["JOINING"] = "§bMatch aan het joinen...";
		$this->translates["ON_JOIN"] = "§9>§f arg1 §elid geworden van de wedstrijd.";
		$this->translates["TOURNAMENT_WELCOME"] = "§bWelkom in het tournament!\n§bHet begint over §3arg1§b.";
		$this->translates["PLAYERS_REMAIN"] = "arg1 spelers blijven.";
		$this->translates["JUSTICE_MAP_WELCOME"] = TextFormat::GOLD . "Kits zijn uitgeschakeld op deze kaart.\n" 
				. TextFormat::GOLD . "Dus, heb je geen wapens, armor, of speciale vaardigheden te krijgen.\n"
				. TextFormat::GOLD . "Eng!";
		/*Commands*/
		$this->translates["RETURN_TO_LOBBY"] = "§1- §7Terugkerend naar de lobby.";
		$this->translates["LBTIME_ERROR"] = "§1- §7Deelnemen aan een toernooi eerste.";
		$this->translates["SHOW_LBTIME"] = "§1- §7Het toernooi zal beginnen in arg1.";
		/*VIP team signs*/
		$this->translates["ONLY_FOR_VIP"] = 
				TextFormat::RED . "Deze actie is alleen beschikbaar voor VIP-spelers.\n" . 
				TextFormat::RED . "U kunt VIP rang kopen in de Reddingsboot + app.";
		$this->translates["TEAM_CHANGED"] = 
				TextFormat::GOLD . "Team is met succes gewijzigd!\n" . 
				TextFormat::GOLD . "Uw huidige team is arg1";
    
	}
}