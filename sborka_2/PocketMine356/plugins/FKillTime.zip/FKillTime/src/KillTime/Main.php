<?php
//Плагин написан FIRERO (https://vk.com/hvladich) и flabberfish (Nolik) (vk.com/flabberfish)
namespace KillTime;

use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\player\PlayerDeathEvent;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\entity\Entity;

class Main extends PluginBase implements Listener {
    
    public $config, $victim;
    
    
    public function onEnable () {
    	$dir = $this->getDataFolder();
		if(!is_dir($dir)){
			@mkdir($dir);
        }
        $this->saveDefaultConfig();
        $this->config = (new Config($dir.'config.yml', Config::YAML));
        
        $pManager = $this->getServer()->getPluginManager();
		$this->economyapi = $pManager->getPlugin("EconomyAPI") ?? null;
		unset($pManager);
		if($this->economyapi === null) {
			$this->getLogger()->warning('Плагин на экономику отсутствует');
        } else {
			$this->getLogger()->info('§aПлагин на экономику найден!');
        }
		
        $this->getServer()->getScheduler()->scheduleRepeatingTask( new Timer ($this), 20);
		$this->victim = "no";
        
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }
    
    
    public function onCommand (CommandSender $s, Command $cmd, $label, array $args) {
        if($cmd->getName() == "kt") {
            $s->sendMessage($this->victim);
            $s->sendMessage($this->config->get("findplayer"));
        }
        
        
    }
    
    public function findplayer () {
        $pls = $this->getServer()->getOnlinePlayers();
        
		if(count($pls) > 1) {
		    $rand = $pls[array_rand($pls)];
        
            if($rand instanceof Player) {
                $nrand = $rand->getName();
                $this->victim = $nrand;
				$this->rp = $rand;
                $this->brdmsg($pls, str_replace(["{victim}", "{time}"], [$nrand, $this->config->get("time")], $this->config->get("findplayer")), $rand);
            }
        
        }
	}
    
    function brdmsg ($players, string $message, Player $except = null) { 
        $players = $players instanceof Player ? [$players] : $players; 
        foreach($players as $player) { 
            if($player !== $except) $player->sendMessage($message); 
        }
    }
    
	public function onPlayerDeathEvent (PlayerDeathEvent $e) {
		$p = $e->getEntity();
		if($p instanceof Player) {
            $victim = $p->getName();
			$c = $p->getLastDamageCause();
			if($c instanceof EntityDamageByEntityEvent) {
				$d = $c->getDamager();
				if($d instanceof Player) {
                    $killer = $d->getName();
                    if($victim == $this->victim) {
                        $this->victim = "no";
                        $this->getServer()->broadcastMessage(str_replace(["{killer}", "{victim}", "{money}"], [$killer, $victim, $this->config->get("money")], $this->config->get("msgendtoall")));
                        $d->sendMessage(str_replace(["{victim}", "{money}"], [$victim, $this->config->get("money")], $this->config->get("msgendtokiller")));
                        $this->economyapi->addMoney($killer, $this->config->get("money"));
                    }
				}
			}
		}
	}
    

}

use pocketmine\scheduler\PluginTask;

class Timer extends PluginTask {

    public function __construct (Main $plugin) {
        parent::__construct($plugin);
        $this->p = $plugin;
        $this->time = $this->p->config->get("time"); 
		$this->yes = 0;
    }

    public function onRun ($currentTick) {
        if($this->p->victim == "no") {
			if($this->yes == 0) {
				$this->p->getServer()->broadcastMessage($this->p->config->get("looking"));
				$this->yes = 1;
			} else {
                $this->p->findplayer();
                $this->time = $this->p->config->get("time");
            }
			
        }
		
		if($this->p->victim !== "no") {
			if($this->p->rp->isOnline()) {
			$this->time--;
            
            } else {
			    $this->p->getServer()->broadcastMessage(str_replace("{victim}", $this->p->victim, $this->p->config->get("exit")));
                $this->time = $this->p->config->get("time");
			    $this->p->victim = "no";
			    $this->p->findplayer();
			    $this->yes = 0;
			}
		}
        
		if($this->time == $this->p->config->get("time") - 60) {
			$this->p->getServer()->broadcastMessage($this->p->config->get("minute"));
		}
        
		if($this->time == 0) {
            $this->p->getServer()->broadcastMessage(str_replace("{victim}", $this->p->victim, $this->p->config->get("time0")) );
            $this->time = $this->p->config->get("time");
			$this->p->victim = "no";
			$this->p->findplayer();
			$this->yes = 0;
            $this->time--;
        }
    }
}

?>