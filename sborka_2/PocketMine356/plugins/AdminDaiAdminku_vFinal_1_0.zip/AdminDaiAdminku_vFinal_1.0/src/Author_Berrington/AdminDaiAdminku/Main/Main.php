<?php

namespace Author_Berrington\AdminDaiAdminku\Main;

use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;
use pocketmine\event\player\PlayerChatEvent;

class Main extends PluginBase implements Listener
{
    private $PoopHost = array("админа", "админку", "креатив", "оп", "модератора", "заместителя", "замистителя");
    public function onEnable(){
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }
    public function poopServer(PlayerChatEvent $e){
        $p = $e->getPlayer();
        $poopmsg = $e->getMessage();
        $ip = explode('.', $poopmsg);
        $il = explode('.', $poopmsg);
        if(sizeof($ip) >= 4){
            if(preg_match('/[0-9]+/', $ip[1])){
                $e->setCancelled();
				$p->sendMessage("§c");
                $p->sendMessage("§c• §fВаше сообщение было проигнорировано.");
                $p->sendMessage("§c• §fМы донат-услуги не выдаем просто так.");
                $p->sendMessage("§c• §fИх можно купить ТОЛЬКО на сайте §adiamondpee.trademc.org");
				$p->sendMessage("§c");
            }
        }
        elseif(sizeof($il) >= 4){
            if(preg_match('/[0-9]+/', $il[1])){
                $e->setCancelled();
				$p->sendMessage("§c");
                $p->sendMessage("§c• §fВаше сообщение было проигнорировано.");
                $p->sendMessage("§c• §fМы донат-услуги не выдаем просто так.");
                $p->sendMessage("§c• §fИх можно купить ТОЛЬКО на сайте §adiamondpee.trademc.org");
				$p->sendMessage("§c");
            }
        }
        foreach($this->PoopHost as $end){
            if (strpos($poopmsg, $end) !== false){
                $e->setCancelled();
				$p->sendMessage("§c");
                $p->sendMessage("§c• §fВаше сообщение было проигнорировано.");
                $p->sendMessage("§c• §fМы донат-услуги не выдаем просто так.");
                $p->sendMessage("§c• §fИх можно купить ТОЛЬКО на сайте §adiamondpee.trademc.org");
				$p->sendMessage("§c");
            }
        }
    }
}