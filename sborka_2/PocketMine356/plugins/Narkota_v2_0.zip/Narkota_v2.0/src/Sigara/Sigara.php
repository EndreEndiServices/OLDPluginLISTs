<?php 

namespace Sigara;

use pocketmine\Server;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\entity\Effect;
use pocketmine\item\Item;
use pocketmine\utils\Config;
use pocketmine\player\Inventory;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\item\enchantment\Enchantment;

class Sigara extends PluginBase Implements Listener{

public $eco; 

public function onEnable(){
       $this->getServer()->getPluginManager()->registerEvents($this, $this);
       $this->saveDefaultConfig();
       $config = $this->getConfig();
       $this->getLogger()->info("Наркотики работают");
       $this->eco = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI"); 
}

public function onCrateTap(PlayerInteractEvent $event){
       $config = $this->getConfig();
       $player = $event->getPlayer();
       $item = $event->getItem();
       $LDTap = $this->getConfig()->get("LDTap");
       $MarlboroTap = $this->getConfig()->get("MarlboroTap");
       $KentTap = $this->getConfig()->get("KentTap");

    if($item->getId() == 352 && $item->getCustomName() == "§r§l§eLD"){
      $money = $this->eco->myMoney($player); 
if($money >= $LDTap){
     $this->eco->reduceMoney($player, $LDTap);
$player->addEffect(Effect::getEffect(Effect::REGENERATION)->setAmplifier(2)->setDuration(20 *9));
$player->sendMessage("§f[§aSmoke§f]Вы курили §aLD\n§f[§aSmoke§f]Цена: $LDTap §2$");
     }else{
$player->sendMessage("§4[§eError§4]§fУ вас недостаточно денег");
}
}

    if($item->getId() == 369 && $item->getCustomName() == "§r§l§4Marlboro"){
      $money = $this->eco->myMoney($player); 
if($money >= $MarlboroTap){
     $this->eco->reduceMoney($player, $MarlboroTap);
$player->addEffect(Effect::getEffect(Effect::REGENERATION)->setAmplifier(2)->setDuration(20 *9));
$player->sendMessage("§f[§aSmoke§f]Вы курили §4Marlboro\n§f[§aSmoke§f]Цена: $MarlboroTap §2$");
     }else{
$player->sendMessage("§4[§eError§4]§fУ вас недостаточно денег");
}
}

    if($item->getId() == 280 && $item->getCustomName() == "§r§l§5Kent"){
      $money = $this->eco->myMoney($player); 
if($money >= $KentTap){
     $this->eco->reduceMoney($player, $KentTap);
$player->addEffect(Effect::getEffect(Effect::REGENERATION)->setAmplifier(2)->setDuration(20 *9));
$player->sendMessage("§f[§aSmoke§f]Вы курили §5Kent\n§f[§aSmoke§f]Цена: $KentTap §2$");
     }else{
$player->sendMessage("§4[§eError§4]§fУ вас недостаточно денег");
}
}
}

	public function  onCommand(CommandSender $sender, Command $command, $label, array $args){
    $config = $this->getConfig();
    $LD = $this->getConfig()->get("LD");
    $Marlboro = $this->getConfig()->get("Marlboro");
    $Kent = $this->getConfig()->get("Kent");
            switch($command->getName()){
      case "smoke": 
if(count($args) == 0)
{
$sender->sendMessage("§f[§6Smoke§f]§eИспользование: §7/smoke help");
}
      switch($args [0])
{

                       case "help":
$sender->sendMessage($this->getConfig()->get("sigara"));
                              break;

                       case "help2":
$sender->sendMessage("§fСтраница §9<§e2/2§9>\n§7§l•••••••••••••••\n§c/smoke shopLD - §fполучить сигареты §eLD\n§c/smoke shopMarlboro - §fполучить сигареты §4Marlboro\n§c/smoke shopKent - §fполучить сигареты §5Kent\n§7§l•••••••••••••••");
                       break;

                       case "LD":
     $money = $this->eco->myMoney($sender); 
if($money >= $LD){
    $this->eco->reduceMoney($sender, $LD);
$sender->addEffect(Effect::getEffect(Effect::REGENERATION)->setAmplifier(2)->setDuration(20 *2));
$sender->sendMessage($this->getConfig()->get("LDmsg"));
     }else{
$sender->sendMessage("§4[§eError§4]§fУ вас недостаточно денег");
}
                              break;

                        case "Marlboro":
    $money = $this->eco->myMoney($sender);
if($money >= $Marlboro){
     $this->eco->reduceMoney($sender, $Marlboro);
$sender->addEffect(Effect::getEffect(Effect::REGENERATION)->setAmplifier(3)->setDuration(20 *2));
$sender->sendMessage($this->getConfig()->get("Mrlmsg"));
     }else{
$sender->sendMessage("§4[§eError§4]§fУ вас недостаточно денег");
}
                              break;

                        case "Kent":
    $money = $this->eco->myMoney($sender);
if($money >= $Kent){
     $this->eco->reduceMoney($sender, $Kent);
$sender->addEffect(Effect::getEffect(Effect::REGENERATION)->setAmplifier(4)->setDuration(20 *2));
$sender->sendMessage($this->getConfig()->get("Kentmsg"));
     }else{
$sender->sendMessage("§4[§eError§4]§fУ вас недостаточно денег");
}
                              break;

                        case "shopKent":
    $item = Item::get(280, 0, 1);
    $item->setCustomName("§r§l§5Kent");
    $item->addEnchantment((Enchantment::getEnchantment(35))->setLevel(3));
    $sender->getInventory()->addItem($item);
$sender->sendMessage("§f[§aSmoke§f]Вы получили сигареты §5Kent");
                        break;

                        case "shopMarlboro":
    $item = Item::get(369, 0, 1);
    $item->setCustomName("§r§l§4Marlboro");
    $item->addEnchantment((Enchantment::getEnchantment(35))->setLevel(3));

    $sender->getInventory()->addItem($item);
$sender->sendMessage("§f[§aSmoke§f]Вы получили сигареты §4Marlboro");
                        break;

                        case "shopLD":
    $item = Item::get(352, 0, 1);
    $item->setCustomName("§r§l§eLD");
    $item->addEnchantment((Enchantment::getEnchantment(35))->setLevel(3));
    $sender->getInventory()->addItem($item);
$sender->sendMessage("§f[§aSmoke§f]Вы получили сигареты §eLD");
                        break;
     default:
$sender->sendMessage("§f[§6Smoke§f]§6Использование: §7/smoke help<страница>");
      }
    }
  }
}
