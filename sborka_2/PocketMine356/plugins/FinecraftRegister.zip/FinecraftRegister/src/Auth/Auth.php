<?php

namespace Auth;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\entity\Entity;
use pocketmine\event\block\SignChangeEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\item\Item;
use pocketmine\level\particle\FlameParticle;
use pocketmine\level\particle\DustParticle;
use pocketmine\level\particle\HeartParticle;
use pocketmine\level\particle\LavaParticle;
use pocketmine\level\particle\PortalParticle;
use pocketmine\level\sound\ClickSound;
use pocketmine\level\sound\AnvilUseSound;
use pocketmine\level\sound\BatSound;
use pocketmine\math\Vector3;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\tile\Sign;
use pocketmine\block\Block;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\utils\Config;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\entity\EntityRegainHealthEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\player\PlayerToggleSprintEvent;

class Auth extends PluginBase implements Listener {
	
	private $authSession;
	
	public function onEnable() {
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$time = 20;
	}
	
	public function onPlayerJoinEvent(PlayerJoinEvent $event) {
		$player = $event->getPlayer();
        if(!is_file($this->getDataFolder()."players/".$event->getPlayer()->getName().".yml")){
            @mkdir($this->getDataFolder() . "players/");
		    $data = new Config($this->getDataFolder() . "players/".$event->getPlayer()->getName().".yml", Config::YAML);
		    $data->set("password", null);
		    $data->save();
			$this->openSession($player);
		} else {
			$this->openSession($player);
		}
	}
	
	public function closeSession($player){
		$this->authSession[$player->getName()] = false;
	}
	
	public function openSession($player){
		$this->authSession[$player->getName()] = true;
	}
	
	public function JoinSession(PlayerJoinEvent $e) {
		$player = $e->getPlayer();
		if($this->authSession[$player->getName()]) {
			if($this->getData($player->getName(), "password") == null) {
				$player->sendMessage("§fПриветствуем на сервере §aFinecraft §bNetwork§f!");
                                $player->sendMessage("§fВведите свой новый пароль в чат.
§c(Не используйте символы отличные от латинских букв или цифр!)");
			} else {
                                $player->sendMessage("§fПриветствуем на сервере §aFinecraft §bNetwork §fснова!");
                                $player->sendMessage("§fВведите свой пароль в чат.");
			}
		}
	}
	
	public function LogAndReg(PlayerChatEvent $e) {
		$player = $e->getPlayer();
		$msg = $e->getMessage();
		if($this->authSession[$player->getName()]) {
			if($this->getData($player->getName(), "password") == null) {
				if(strlen($msg) >= 5) {
    				$this->saveData($player->getName(), "password", $msg);
					$this->closeSession($player);
					$e->setCancelled();
					$player->sendMessage("§aВы успешно зарегестрировали свой аккаунт!");
				} else {
					$player->sendMessage("§aВы успешно вошли в свой аккаунт!");
					$e->setCancelled();
				}
			} elseif($msg == $this->getData($player->getName(), "password")) {
				$this->closeSession($player);
				$e->setCancelled();
				$player->sendMessage("§aВы успешно вошли в свой аккаунт!");
			} else {
				$e->setCancelled();
				$player->sendMessage("");
			}
		}
	}
	
	public function Move(PlayerMoveEvent $e) {
		$player = $e->getPlayer();
		if($this->authSession[$player->getName()]) {
			if($this->getData($player->getName(), "password") == null) {
				$e->setCancelled();
			} else {
				$e->setCancelled();
			}
		}
	}
	
	public function CMD(PlayerCommandPreprocessEvent $e) {
		$player = $e->getPlayer();
		$msg = $e->getMessage();
		if($this->authSession[$player->getName()]) {
			if($msg{0} == "/") {
				$e->setCancelled();
				if($this->getData($player->getName(), "password") == null) {
					$player->sendMessage("");
				} else {
					$player->sendMessage("");
				}
			}
		}
	}
	
	public function Interact(PlayerInteractEvent $e) {
		$player = $e->getPlayer();
		if($this->authSession[$player->getName()]) {
			$e->setCancelled();
			if($this->getData($player->getName(), "password") == null) {
				$player->sendMessage("");
			} else {
				$player->sendMessage("");
			}
		}
	}
	
	public function BreakBlock(BlockBreakEvent $e) {
		$player = $e->getPlayer();
		if($this->authSession[$player->getName()]) {
			$e->setCancelled();
			if($this->getData($player->getName(), "password") == null) {
				$player->sendMessage("");
			} else {
				$player->sendMessage("");
			}
		}
	}
	
	public function Sprint(PlayerToggleSprintEvent $e) {
		$player = $e->getPlayer();
		if($this->authSession[$player->getName()]) {
			$e->setCancelled();
			if($this->getData($player->getName(), "password") == null) {
				$player->sendMessage("");
			} else {
				$player->sendMessage(");
			}
"		}
	}
	
	
	
    public function saveData($playerName, $tip, $data) {
      	$sFile = (new Config($this->getDataFolder() . "players/".$playerName.".yml", Config::YAML))->getAll();
        $sFile[$tip] = $data;
      	$fFile = new Config($this->getDataFolder() . "players/".$playerName.".yml", Config::YAML);
        $fFile->setAll($sFile);
     	$fFile->save();
    }

    public function getData($playerName, $tip){
        $sFile = (new Config($this->getDataFolder() . "players/".$playerName.".yml", Config::YAML))->getAll();
        return $sFile[$tip];
    }

    public function addData($playerName, $tip, $data){
        $sFile = (new Config($this->getDataFolder() . "players/".$playerName.".yml", Config::YAML))->getAll();
        $sFile[$tip] = $sFile[$tip] += $data;
      	$fFile = new Config($this->getDataFolder() . "players/".$playerName.".yml", Config::YAML);
	    $fFile->setAll($sFile);
        $fFile->save();
    }
}