<?php 

namespace AddEf;

use pocketmine\Server;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\entity\Effect;
use pocketmine\utils\Config;

class AddEf extends PluginBase Implements Listener{

public $eco; 

public function onEnable(){
       $this->getServer()->getPluginManager()->registerEvents($this, $this);
       $this->saveDefaultConfig();
       $config = $this->getConfig();
       $this->getLogger()->info("Еффекты работают");
       $this->eco = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI"); 
}

	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
    $config = $this->getConfig();
    $regen = $this->getConfig()->get("regen");
    $force = $this->getConfig()->get("force");
    $invisible = $this->getConfig()->get("invisible");
    $jump = $this->getConfig()->get("jump");
    $absorp = $this->getConfig()->get("absorp");
            switch($command->getName()){
                       case "effectl":
$sender->sendMessage("§4§l-------§8[§eEffect§8]§4-------\n§c/regen - §eрегенерация §b {$regen} $\n§c/force - §eсила §b {$force} $\n§c/invisible - §eневидимость §b {$invisible} $\n§c/jump - §eсупер-прыжок §b {$jump} $\n§c/absorp - §eпоглощение §b {$absorp} $\n§4§l-------§8[§eEffect§8]§4-------");
                              break;

                       case "regen":
     $money = $this->eco->myMoney($sender); 
if($money >= $regen){
    $this->eco->reduceMoney($sender, $regen);
$sender->addEffect(Effect::getEffect(Effect::REGENERATION)->setAmplifier(1)->setDuration(20 *60));
$sender->sendMessage("§8[§eEffect§8]§fВы купили эффект §bРегенерации §fза §2 {$regen} $");
     }else{
$sender->sendMessage("§8[§cError§8]§6>§bНедостаточно денег");
}
                              break; 

                       case "force":
     $money = $this->eco->myMoney($sender); 
if($money >= $force){
    $this->eco->reduceMoney($sender, $force);
$sender->addEffect(Effect::getEffect(Effect::STRENGTH)->setAmplifier(2)->setDuration(20 *60));
$sender->sendMessage("§8[§eEffect§8]§fВы купили эффект §eСилы §fза §2 {$force} $");
     }else{
$sender->sendMessage("§8[§cError§8]§6>§bНедостаточно денег");
}
                              break;

                        case "invisible":
     $money = $this->eco->myMoney($sender); 
if($money >= $invisible){
    $this->eco->reduceMoney($sender, $invisible);
$sender->addEffect(Effect::getEffect(Effect::INVISIBILITY)->setAmplifier(14)->setDuration(20 *120));
$sender->sendMessage("§8[§eEffect§8]§fВы купили эффект §eНевидимости §fза §2 {$invisible} $");
     }else{
$sender->sendMessage("§8[§cError§8]§6>§bНедостаточно денег");
}
                              break;

                        case "jump":
     $money = $this->eco->myMoney($sender); 
if($money >= $jump){
    $this->eco->reduceMoney($sender, $jump);
$sender->addEffect(Effect::getEffect(Effect::JUMP)->setAmplifier(8)->setDuration(20 *60));
$sender->sendMessage("§8[§eEffect§8]§fВы купили эффект §6Супер-прыжок §fза §2 {$jump} $");
     }else{
$sender->sendMessage("§8[§cError§8]§6>§bНедостаточно денег");
}
                              break;

                        case "absorp":
     $money = $this->eco->myMoney($sender); 
if($money >= $absorp){
    $this->eco->reduceMoney($sender, $absorp);
$sender->addEffect(Effect::getEffect(Effect::ABSORPTION)->setAmplifier(22)->setDuration(20 *120));
$sender->sendMessage("§8[§eEffect§8]§fВы купили эффект §7Поглощения §fза §2 {$absorp} $");
     }else{
$sender->sendMessage("§8[§cError§8]§6>§bНедостаточно денег");
}
                              break;
       }
   }
}

