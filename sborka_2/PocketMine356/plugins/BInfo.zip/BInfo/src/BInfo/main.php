<?php
namespace BInfo;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\Player;
use pocketmine\event\player\PlayerJoinEvent;

class main extends PluginBase implements Listener{

public function onEnable(){
$this->getLogger()->info("создаано для vk.com\free_plugs_mcpe");
$this->getServer()->getPluginManager()->registerEvents($this,$this);
$this->eco = $this->getServer()->getPluginManager()->getPlugin("EconomyApi");
}

public function onJoin(PlayerJoinEvent $e){
$p = $e->getPlayer();
$name = $p->getPlayer();
$hp = $p->getHealth();
$deaths = $p->getPlayerDeaths();
$x = $p->getX();
$y = $p->getY();
$z = $p->getZ();
$pMoney = $this->eco->mymoney($p);
		   $p->sendMessage("§aСтатус Игрока §6$name\n§fЗдоровья: §e$hp/20\n§fТвои координаты: §e$x§f, §e$y§f,§e $z\n§fМонеты: §e$pMoney\n§fСмертей: §e$deaths");
}

}