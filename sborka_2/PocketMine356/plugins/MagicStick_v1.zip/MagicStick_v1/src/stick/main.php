<?php

namespace stick;

use pocketmine\plugin\PluginBase;

use pocketmine\Player;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;

use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerItemHeldEvent;

use pocketmine\utils\TextFormat as C;

use pocketmine\item\Item;

use pocketmine\entity\Entity;
use pocketmine\entity\Effect;

use onebone\economyapi\EconomyAPI;
use onebone\economyapi\commands\TakeMoney;

class main extends PluginBase implements Listener {

private $EconomyS;
public $moimani;
public $eco;
public $money;
public $player;

public function onEnable(){
$this->getLogger()->info("Создатель плагина BodyaChannel");
$this->getServer()->getPluginManager()->registerEvents($this,$this);
$this->EconomyS = $this->getServer()->getPluginManager()->getPlugin("EconomyApi");
}

public function onCommand(CommandSender $sender,Command $command,$label,array $args){
        if($command == "mi"){
            if($sender instanceof Player){
            
                $sender->sendMessage("§4(§fMagicStick§4)§e Магические палки :");
                $sender->sendMessage("§7Палка §fУрона §e- 20000$ §6(/mi 1)");
                $sender->sendMessage("§7Палка §fПоджога §e- 15000$ §6(/mi 2)");
                $sender->sendMessage("§7Палка §fОткидывания §e- 10000$ §6(/mi 3)");
                $sender->sendMessage("§7Палка §fCлепоты §e- 25000$ §6(/mi 4)");
               
               
               switch(strtolower($args[0])) {
             
          case "1":
          
           $player = $this->getServer()->getPlayer($args[0]);
           
if ($money > 20000){

$sender->sendMessage("У Вас недостаточно денежных средств.");
$event->setcancelled();
return;
}
$moimani = EconomyAPI:: getInstance()->myMoney($player);
  $eco = \onebone\economyapi\EconomyAPI ::getInstance();
$money = $eco->myMoney($player);
$take = ($money - 20000);
$eco->setMoney($player,  $take);
           $this->EconomyS->setMoney($sender, 20000);
          
          $item = Item::get(378,0,1); 
        $sender->getPlayer()->getInventory()->setItem(35,$item); 
        $sender->getPlayer()->getInventory()->setHotbarSlotIndex(0, 35);        
  
     
     
    }   
     switch(strtolower($args[0])) {
             
          case "2":
           $player = $this->getServer()->getPlayer($args[0]);
           
if($moimani = 15000){
  $eco = \onebone\economyapi\EconomyAPI ::getInstance();
$money = $eco->myMoney($player);
$take = ($money - 15000);
$eco->setMoney($player,  $take);
           $this->EconomyS->$ecoMoney($sender, 15000);
          
          $item = Item::get(370,0,1); 
        $sender->getPlayer()->getInventory()->setItem(35,$item); 
        $sender->getPlayer()->getInventory()->setHotbarSlotIndex(0, 35);    
              }else{
     $sender->sendMessage("§4Не достаточно денег");
     }
                 }
                
                 
                 
     switch(strtolower($args[0])) {
             
          case "3":
           $player = $this->getServer()->getPlayer($args[0]);
           
if($moimani = 10000){
  $eco = \onebone\economyapi\EconomyAPI ::getInstance();
$money = $eco->myMoney($player);
$take = ($money - 10000);
$eco->setMoney($player,  $take);
           $this->EconomyS->$ecoMoney($sender, 10000);
          
          $item = Item::get(369,0,1); 
        $sender->getPlayer()->getInventory()->setItem(35,$item); 
        $sender->getPlayer()->getInventory()->setHotbarSlotIndex(0, 35);    
          }else{
     $sender->sendMessage("§4Не достаточно денег");
     }
      }
      
         switch(strtolower($args[0])) {
             
          case "4":
           $player = $this->getServer()->getPlayer($args[0]);
         $moimani = EconomyAPI:: getInstance()->myMoney($player);
if($moimani >= 2500){
  $eco = \onebone\economyapi\EconomyAPI ::getInstance();
$money = $eco->myMoney($player);
$take = ($money - 25000);
$eco->setMoney($player,  $take);
           $this->EconomyS->$ecoMoney($sender, 25000);
          
          $item = Item::get(351,0,1); 
        $sender->getPlayer()->getInventory()->setItem(35,$item); 
        $sender->getPlayer()->getInventory()->setHotbarSlotIndex(0, 35);    
        }else{
     $sender->sendMessage("§4Не достаточно денег");
     }
        
    }
   } 
  }
 }
      public function pizda(EntityDamageEvent $event){
$player = $event->getEntity();
if($event instanceof EntityDamageByEntityEvent){
$damager = $event->getDamager();
if($damager instanceof Player){
if($damager->getInventory()->getItemInHand()->getId() === 369){
$event->getEntity()->setHealth(10);
$event->setKnockBack(2);
}
}
}
}

public function held(PlayerItemHeldEvent $event){
$player = $event->getPlayer();
$item = $event->getItem()->getId();
if($item == 369){
$player->sendPopup("§l§eПалка откидывания");
}
}

public function pizda1(EntityDamageEvent $event){
$player = $event->getEntity();
if($event instanceof EntityDamageByEntityEvent){
$damager = $event->getDamager();
if($damager instanceof Player){
if($damager->getInventory()->getItemInHand()->getId() === 370){
$player->setOnFire(20);
}
}
}
}

public function held1(PlayerItemHeldEvent $event){
$player = $event->getPlayer();
$item = $event->getItem()->getId();
if($item == 370){
$player->sendPopup("§l§eПалка поджога");
}
}
public function pizda2(EntityDamageEvent $event){
$player = $event->getEntity();
if($event instanceof EntityDamageByEntityEvent){
$damager = $event->getDamager();
if($damager instanceof Player){
if($damager->getInventory()->getItemInHand()->getId() === 378){
$event->setDamage(8);
}
}
}
}

public function held2(PlayerItemHeldEvent $event){
$player = $event->getPlayer();
$item = $event->getItem()->getId();
if($item == 378){
$player->sendPopup("§l§eПалка урона");
}
}
public function pizda3(EntityDamageEvent $event){
$player = $event->getEntity();
if($event instanceof EntityDamageByEntityEvent){
$damager = $event->getDamager();
if($damager instanceof Player){
if($damager->getInventory()->getItemInHand()->getId() === 351){
$player->addEffect(Effect::getEffect(15)->setDuration(228)->setVisible(true));
}
}
}
}

public function held3(PlayerItemHeldEvent $event){
$player = $event->getPlayer();
$item = $event->getItem()->getId();
if($item == 351){
$player->sendPopup("§l§eПалка слепоты");
}
}    
  }