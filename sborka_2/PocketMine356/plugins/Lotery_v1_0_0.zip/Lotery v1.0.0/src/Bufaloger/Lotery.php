<?php

namespace McGo;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\Player;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\utils\Color;
use onebone\economyapi\EconomyAPI;
use pocketmine\item\Item;
use pocketmine\inventory\Inventory;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\entity\Entity;
use pocketmine\Server;

class Lotery extends PluginBase implements Listener {
	
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getLogger()->info("§aПлагин Lotery Включён!");
		$this->EconomyAPI = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
	}
	
	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
		$name = $sender->getName();
		$inv = $sender->getInventory();
		if(strtolower($command) == "lotery"){
			if(isset($args[0])){
				if(strtolower($args[0]) == "help"){
					if($sender->hasPermission("lotery.help")){
		     	$sender->sendMessage("§8(§aЛотерея§8)  §bМеню ^");
                    $sender->sendMessage("§7>§6 Купить простую лотерею за §7300р §6(Выиграш от §a100р§7-§a500р§6)");
                    $sender->sendMessage("§7>§6 Купить элитную лотерею за §71000р §6(Выиграш от §a500р§7-§a1500р§6)");
                    $sender->sendMessage("§bПокупка простой лотереи (§7/lotery prosta§b)");
                    $sender->sendMessage("§bПокупка элитной лотереи (§7/lotery elita§b)");
					}else{
						$sender->sendMessage("§8(§aЛотерея§8) §fУ Вас недостаточно прав чтобы посмотреть инфотрацию!");
					}
				}
				elseif(strtolower($args[0]) == "prosta"){
					if($sender->hasPermission("lotery.prosta")){
                        $money = $this->EconomyAPI->myMoney($sender);
                                  if($money > 299){
                       $this->EconomyAPI->reduceMoney($sender, 300);
                                  $inv = $sender->getInventory();
                                   $bymaga = Item::get(339, 0, 1);
							$inv->addItem($bymaga);
                               $sender->sendMessage("§7(§aЛотерея§7) §bВы купили простую лотерею за 300р");
                     }else{
			$sender->sendMessage("§8(§aЛотерея§8) §cУ тебя недостаточно денег на счету чтобы купить простую лотерею\n §e● §cПроверь свой баланс командой §f/mymoney");
               }    
					}else{
						$sender->sendMessage("§8(§aЛотерея§8) §fУ Вас недостаточно прав чтобы купить простую лотерею!");
					}
				}
				elseif(strtolower($args[0]) == "elita"){
					if($sender->hasPermission("lotery.elita")){
                    $money = $this->EconomyAPI->myMoney($sender);
						 if($money > 999){
                       $this->EconomyAPI->reduceMoney($sender, 1000);
                                  $inv = $sender->getInventory();
                                   $magma = Item::get(378, 0, 1);
							$inv->addItem($magma);
                                  $sender->sendMessage("§7(§aЛотерея§7) §bВы купили элитную лотерею за 1000р");
                                   }else{
                          $sender->sendMessage("§8(§aЛотерея§8) §cУ тебя недостаточно денег на счету чтобы купить элитную лотерею\n §e● §cПроверь свой баланс командой §f/mymoney");
                         }         
                                 }else{
						$sender->sendMessage("§8(§aЛотерея§8) §fУ Вас недостаточно прав чтобы купить элитную лотерею!");
					}
				}else{
					$sender->sendMessage("§8(§aЛотерея§8) §fИнформация: /lotery help");
				}
			}else{
				$sender->sendMessage("§8(§aЛотерея§8) §fИнформация: /lotery help");
			}
		}
	}
	
	public function onTap(PlayerInteractEvent $event){
     $sender = $event->getPlayer();
    $item = $event->getPlayer()->getInventory()->getItemInHand();
    if($item->getID() == 339){
              $sender->getInventory()->removeItem(Item::get(339,0,1));
               $name = $sender->getName();
			$moneyg = mt_rand(100,500);
			$this->EconomyAPI->addMoney($sender,$moneyg);
			$this->getServer()->broadcastMessage("§8(§aЛотерея§8) §fИгрок§a ".$name." §fвыиграл(а)§a ".$moneyg."р §fв простой лотерее");
}
            elseif($item->getID() == 378){ 
          $sender->getInventory()->removeItem(Item::get(378,0,1));
           $name = $sender->getName();
			$moneyl = mt_rand(500,1500);
			$this->EconomyAPI->addMoney($sender,$moneyl);
			 $this->getServer()->broadcastMessage("§8(§aЛотерея§8) §fИгрок§a ".$name." §fвыиграл(а)§a ".$moneyl."р §fв элитной лотерее");
	}
}
}