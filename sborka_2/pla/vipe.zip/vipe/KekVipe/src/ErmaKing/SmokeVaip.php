<?php

namespace ErmaKing;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\scheduler\CallbackTask;
use pocketmine\Player;
use pocketmine\level\particle\ExplodeParticle;
use pocketmine\level\particle\SmokeParticle;
use pocketmine\level\Level;
use pocketmine\math\Vector3;
use pocketmine\utils\Config;
use pocketmine\entity\Effect;
use pocketmine\item\Item;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerItemHeldEvent;
use pocketmine\Server;

class SmokeVaip extends PluginBase implements Listener {
	public $using = 0;
	public $count;
	public $buy = 0;
	public $nobuy = 0;
	public $saved = 0;
	public $thfirst = 0;
	public $auto = 0;
	public $firstActivate = 0;
	
	public function onEnable(){
		@mkdir($this->getDataFolder());
	$this->config = (new Config($this->getDataFolder() . "config.yml",  Config::YAML, 
	array(
	"Максимальный заряд" => 150,
	"Таймер заряжения" => 150,
	"Текст разряжения" => "§7Вейп разряжен, можно использовать когда §6зарядится!",
	"Текст выполнения заряда" => "§7Вейп успешно заряжен!",
	"Цена вейпа" => 75,
	"Покупка" => "§7Вы успешно купили вейп  егошку , за §a750 рублей! ",
	"Недостаточно" => "§7У вас недостаточно денег. Заработать можно, с помощью §6/tm",
	"Длительность эффекта" => 20,
	"Уровень эффекта" => 3,
	"В процессе" => "§7Ваш вейп уже в процессе §cзаряжения!",
	"Заряд" => "§6★§7Заряд батареи:",
	"Для начала купить" => "§cНапиши: §6/smoke §a, чтобы получить всю инормацию о вейпе.",
	"Автономный" => "§aАвто вейп включен!",
	"Не автономный" => "§cАвто вейп выключен!"
	)
	))->getAll();
	$this->getLogger()->info("§bВейп от §fErmaKing §aвключен §bvk.com/ermaking");
	$this->getServer()->getPluginManager()->registerEvents($this, $this);
	}
	
	public function onCommand(CommandSender $sender, Command $cmd, $label, array $args){
	 if(strtolower($cmd->getName() == ("smoke" || "vaip" || "vipe"))){ 
		  if(!isset($args[0])){
			  $count_money = $this->config["Цена вейпа"];
			   $sender->sendMessage("§7(§aСигареты§7) Плагин сделал: §aНиколай Машаров ");
			   $sender->sendMessage("§7(§cСигареты§7) Напишите: §f/$cmd buy §7, чтобы купить электронную сигарету за §f" . (int)$count_money . "§750руб!");
		} 
		 else if($args[0] == "buy"){     	
						 $economy = \onebone\economyapi\EconomyAPI::getInstance();
						 if(((int)$economy->myMoney($sender) > (int)$this->config["Цена вейпа"]) && $this->buy == 0){			 
					   $count = $this->config["Цена вейпа"];
					    $full = 	($economy->myMoney($sender) - $count);
					     $economy->setMoney($sender, $full);
					    $sender->sendMessage($this->config["Покупка"]);
					    $sender->getPlayer()->getInventory()->addItem(Item::get(369, 0, 1));
					   $this->nobuy = 1;
					   $this->buy = 1;
					   $this->thfirst = 1;
					   $this->firstActivate = 1;
					     }					   
					  else if(((int)$economy->myMoney($sender) < (int)$this->config["Цена вейпа"])){
						     $sender->sendMessage($this->config["Недостаточно"]);
						    }						 
					 else if($this->buy == 1 || $sender->getPlayer()->getItemInHand()->getId() === 369){
						   $sender->sendMessage($this->config["В процессе"]);
	     	} 
	   }
  }
}
	
	public function onTap(PlayerInteractEvent $event){
		$battery = $this->config["Максимальный заряд"];
		$timer = $this->config["Таймер заряжения"];
		 if($event->getPlayer()->getInventory()->getItemInHand()->getId() == 369 && $this->using < $battery || $this->using == 0 && $this->thfirst == 1)
			   {
				 if($this->firstActivate == 1){
				    $p = $event->getPlayer();
				    $x = $p->getX(); $y = 	$p->getY(); $z = $p->getZ();
				     	$p->addEffect(Effect::getEffect(1)->setAmplifier((int)$this->config["Уровень эффекта"])->setDuration((int)$this->config["Длительность эффекта"] * 20)->setVisible(false));
				     	$p->addEffect(Effect::getEffect(8)->setAmplifier((int)$this->config["Уровень эффекта"])->setDuration((int)$this->config["Длительность эффекта"] * 20)->setVisible(false));
				  $p->getLevel()->addParticle(new ExplodeParticle(new Vector3($x, $y + 1, $z)));
		    $p->getLevel()->addParticle(new ExplodeParticle(new Vector3($x - 1, $y + 1, $z)));
		    $p->getLevel()->addParticle(new ExplodeParticle(new Vector3($x + 1, $y + 1, $z)));
		    $p->getLevel()->addParticle(new ExplodeParticle(new Vector3($x, $y + 1, $z - 1)));
		    $p->getLevel()->addParticle(new ExplodeParticle(new Vector3($x, $y + 1, $z + 1)));
		    $p->getLevel()->addParticle(new ExplodeParticle(new Vector3($x, $y + 2, $z)));
		    $p->getLevel()->addParticle(new ExplodeParticle(new Vector3($x + 1, $y + 2, $z)));
		    $p->getLevel()->addParticle(new ExplodeParticle(new Vector3($x - 1, $y + 2, $z)));
		    $p->getLevel()->addParticle(new ExplodeParticle(new Vector3($x, $y + 2, $z - 1)));
		    $p->getLevel()->addParticle(new ExplodeParticle(new Vector3($x, $y + 2, $z + 1)));
		    $p->getLevel()->addParticle(new ExplodeParticle(new Vector3($x, $y + 1, $z)));
		    $p->getLevel()->addParticle(new ExplodeParticle(new Vector3($x - 1, $y + 1, $z - 1)));
		    $p->getLevel()->addParticle(new ExplodeParticle(new Vector3($x + 1, $y + 1, $z + 1)));
		    $p->getLevel()->addParticle(new ExplodeParticle(new Vector3($x - 1, $y + 1, $z - 1)));
		    $p->getLevel()->addParticle(new ExplodeParticle(new Vector3($x + 1, $y + 1, $z + 1)));
		    $p->getLevel()->addParticle(new ExplodeParticle(new Vector3($x, $y + 2, $z)));
		    $p->getLevel()->addParticle(new ExplodeParticle(new Vector3($x + 1, $y + 2, $z + 1)));
		    $p->getLevel()->addParticle(new ExplodeParticle(new Vector3($x - 1, $y + 2, $z - 1)));
		    $p->getLevel()->addParticle(new ExplodeParticle(new Vector3($x + 1, $y + 2, $z - 1)));
		    $p->getLevel()->addParticle(new ExplodeParticle(new Vector3($x - 1, $y + 2, $z + 1)));			
		       	 $this->count = $this->using++;
			         $event->getPlayer()->sendPopup("§7(§aСигареты§7) §6Разряжено: §f$this->count §9из §f$battery");  
                   $event->getPlayer()->sendMessage("§7Вы курите §6электронную сигарету§7, дымлю, где §cхочу§7!");
			    } 
		 	}
	  if($this->using == $battery || $this->count == $battery && $this->buy == 0)
		   {      
			       $p->getInventory()->removeItem(Item::get(369, 0, 64));
		         $event->getPlayer()->sendMessage($this->config["Текст разряжения"]);
		          $epta = new CallbackTask([$this, "full"], [$p]);	       	       
		           $this->getServer()->getScheduler()->scheduleDelayedTask($epta, 20 * $timer);
		            $this->buy = 1; 
		             $this->saved = 0;
		        }
		     }
	
	  public function full(Player $p){
		 $this->saved = 1;   
		  $this->buy = 0;
		  unset($this->count);
		  unset($this->using);
		if($p->isOnline || $p->isOnline()){
		  $p->getInventory()->addItem(Item::get(369, 0, 1));
		  $p->sendMessage($this->config["Текст выполнения заряда"]);		  
		   }
	  } 
	
	public function joinsaved(PlayerJoinEvent $e){	
		 $e->getPlayer()->getInventory()->addItem(Item::get(369, 0, 1));
	}
	
	public function onFirstUse(PlayerItemHeldEvent $e){
	if($e->getItem()->getId() == 369){
		if($this->thfirst == 0){
			 $e->getPlayer()->sendPopup($this->config["Для начала купить"]);
			}
		}
	}
	
	public function onDisable(){
		 $this->config->save;
	 	$this->getLogger()->info("§bВейп §cвыключен");
	}
      }
	
	