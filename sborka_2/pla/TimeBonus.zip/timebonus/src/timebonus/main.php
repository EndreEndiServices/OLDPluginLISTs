<?php #Скачано с https://vk.com/mpe_plagins

namespace timebonus;

use pocketmine\plugin\PluginBase;
use pocketmine\scheduler\CallbackTask;

class main extends PluginBase{
	public function onEnable(){
		$this->getServer()->getScheduler()->scheduleRepeatingTask(new CallbackTask(array($this, "bonus")), 10 * 20 * 60);
	}
	public function bonus(){
		foreach ($this->getServer()->getOnlinePlayers() as $p) {
			$p->sendMessage("§2(§dБонус§2) §eСпасибо, что играете на нашем сервере! §a•\n§2(§dБонус§2) §eВам выдано §6100\$");
			$this->getServer()->getPluginManager()->getPlugin("EconomyAPI")->addmoney($p,100);
		}
	}
}