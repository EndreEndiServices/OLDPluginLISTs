# sPonGeBoBmEMe
a pLugIn fOr pOckETMiNe-mP tO maKe aLL ChaT mEssAgeS lOoK liKe thIs
